% No images or downloads required. Saves local software and function checks.
projectRoot=fileparts(mfilename('fullpath'));addpath(projectRoot);
folder=fullfile(projectRoot,'local_validation');if ~isfolder(folder),mkdir(folder);end
functions=["dlnetwork","dlarray","trainNetwork","trainingOptions","activations", ...
    "dlconv","pagemtimes","adamupdate","imbinarize","adapthisteq","imwarp", ...
    "fitcecoc","fitcknn","fitctree","savefig","exportgraphics","readtable"];
available=false(numel(functions),1);location=strings(numel(functions),1);
for j=1:numel(functions)
    location(j)=string(which(char(functions(j))));available(j)=strlength(location(j))>0;
    if ~available(j)&&functions(j)=="dlconv"
        try
            if any(strcmp(methods('dlarray'),'dlconv')),available(j)=true;location(j)="dlarray method: dlconv";end
        catch
        end
    end
end
T=table(functions(:),available,location,'VariableNames',{'function_name','available','location'});
writetable(T,fullfile(folder,'function_availability.csv'));disp(T);
gpu=false;gpuDescription='Not selected';
try
    gpu=canUseGPU;if gpu,q=gpuDevice;gpuDescription=q.Name;end
catch err,gpuDescription=err.message;
end
nimeq.write_json(fullfile(folder,'environment.json'),struct('matlab',version,'release',version('-release'), ...
    'computer',computer,'JVM',usejava('jvm'),'toolboxes',ver,'GPU_usable',gpu,'GPU_description',gpuDescription));
for profile=["quick","workstation","full"]
    cfg=nimeq_config(char(profile));B=nimeq.budget_estimate(cfg);
    nimeq.write_json(fullfile(folder,char(profile+"_budget.json")),B);
    fprintf('%s: up to %d CV SACNet fits (%d epochs each), %d CNN fits, %d final SACNet fits.\n', ...
        profile,B.inner_SAC_fits_upper_bound,B.epochs_per_inner_fit,B.CNN_fits,B.final_SAC_fits);
end
cfg=nimeq_config('quick');nimeq.preflight(cfg);
disp('Environment checks finished. Run RUN_SELF_TEST next.');
