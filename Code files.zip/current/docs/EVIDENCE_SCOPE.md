# New experiments and the journal's concerns

This project can produce traceable **new** numerical/graphical records after successful local testing and training. It cannot determine the journal's decision or recover data that was never supplied. Keep historical material and new experiments dated and identified.

| Concern | What this code supplies | What remains necessary |
|---|---|---|
| Tables6-10: F1 | F1 from integer TP/FN/FP, per-case predictions and automatic recalculation. Printed-table checks use rounding intervals and preserve malformed text. | Original predictions/counts are needed to identify authentic historical F1. New measurements do not establish the cause of old discrepancies. |
| Tables6-10: accuracy | Explicit class one-versus-rest accuracy and separate overall trace(C)/N. Binary class accuracies consequently agree. | Establish the definition/population used for published numbers, using original code/logs if available. |
| Tables6-10: error rate | Table5 balanced error, separate ordinary error, actual counts and printed arithmetic checks. | Explain/correct the original scale or formula only to the extent supported by records. |
| Table4: mean | All trials, best-state files, arithmetic mean and histories. Workstation/full run ten trials; quick runs one. Printed ten values average.0483, whereas.0553 is printed. | Original logs, task, CV membership and settings are needed to authenticate the ten published values. Correct arithmetic alone does not authenticate them. |
| Table11: comparators | Preserved printed rows, qualified source-review CSV, separate new-model summary and identified dataset/metric issues. | Verify source locations. Correct reference88's three model accuracies, reference89's APTOS assignment and reference91's training/testing assignment. Do not call unverified values specificity or IDRiD results. |
| Raw data, graphics and software | New manifests, splits, ancestry, raw features, predictions, counts, histories, models, qubits, FIGs, PNGs, hashes and actual MATLAB/toolbox versions. | Provide authentic original unprocessed files where available. Identify unavailable historical records explicitly; do not rename new files as old records. |
| References9,17,19,88,89,91 | Topic/source-review notes with verification limits. | Authors must supply actual reasons for each addition, relevant manuscript claims and available revision/history evidence. Code cannot establish that history. |
| Whole-method explanation | Executable stages, coverage ledger, explicit EWT/architecture choices, normalized/literal optimizers and optional sensitivity comparisons. | Unspecified original details remain unknown. Distinguish reported paper settings from later reconstruction choices and disclose departures. |

Keep the whole successful `results/<experimentName>/` folder and `local_validation/`. Configuration must show the actual profile/settings. Retain all variants, exclusions, failures and measured differences, including lower results. Verify metrics before using them and explain score/class definitions, including no-DR-versus-any-DR binary labels.

Use source labels and recorded membership. Do not change labels, choose favorable test cases or select an architecture based on matching printed test scores. The sensitivity runner reports every fixed variant and does not automatically select by held-out accuracy.

Numerical verification establishes consistency of a new run, not historical authenticity or an explanation for old errors. The letter requests the corresponding author's response on behalf of all authors after agreement. No message is sent by this project.
