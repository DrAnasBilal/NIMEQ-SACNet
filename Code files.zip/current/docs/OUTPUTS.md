# Output map

All experimental outputs are newly measured on the user's machine. The project does not include completed scientific results. CSVs contain actual numerical records; MAT files preserve MATLAB arrays and model state; FIG files are native MATLAB figures. The software release and installed toolbox versions are recorded in `software.json`.

Paths below are relative to `results/<experimentName>/`.

| Output | Contents and provenance |
|---|---|
| `configuration.mat`, `configuration.json` | Resolved settings, including CPU/GPU selection. MAT preserves Inf; JSON serializes nonfinite numeric values as null. |
| `run_identity.json`, `authored_code_sha256.csv` | Signature of the resolved configuration, source membership/hashes and authored MATLAB code. Changed inputs require a new experiment name. |
| `paper_method_coverage.csv`, `computation_budget.json` | Specified/assumed stage coverage and actual configured fit counts; these distinguish a reconstruction from original historical records. |
| `source_manifest.csv`, `processed_manifest.csv` | Original image membership, grades, patient/group IDs, SHA256 and processed image/mask paths. |
| `source_splits.csv` | Outer train/test membership and inner validation fold. Only original source records are split. |
| `console.log`, `status.json`, `software.json` | Runtime progress, failure stack or completion, timestamps and actual MATLAB/toolbox versions. |
| `image_cache/native_segmentation_features.csv` | Ten descriptors from native-resolution masks for every accepted source image. |
| `image_cache/image_cache/` | Quantized preprocessed image, resized red/bright masks, native descriptors; cache keyed by dataset/image hash within this fixed run. |
| `examples/Figure7_augmentation.fig/.png` | All augmentation operations demonstrated on a training image. This grid illustrates operations; actual randomly chosen training augmentations are logged separately. |
| `examples/Figure8_segmentation.fig/.png`, `example_segmentation.mat` | Source image, enhancement, raw candidates, final masks and numerical segmentation output. |
| `examples/NEW_ewt_raw.mat`, `NEW_ewt_spectrum.csv`, `NEW_ewt_boundaries.csv`, `NEW_ewt_decomposition.fig/.png` | Actual EWT bands, filters, descriptors, boundaries and reconstruction diagnostics. The procedure is explicitly chosen, not recovered. |
| `examples/NEW_implemented_method.fig/.png`, `NEW_method_graph_edges.csv` | Data-flow graph and its raw edge list for the implemented configuration. |
| `examples/Figure12_*_training_samples.fig/.png` | Representative original training images per native grade. |
| `<task>/task_definition.json`, `source_splits.csv` | Exact class order, native-grade mapping and task membership. |
| `<task>/inner_features/fold_XX/` | CNN, SVD and features fitted only on this inner fold's training sources. Validation sources are not augmented or used for fitting. |
| `<task>/final_features/` | CNN/SVD fitted on all outer training sources after search selection; original held-out feature vectors and labels retained for evaluation. |
| `.../training_images/augmentation_ancestry.csv` | Every training observation, parent source ID, group, mapped label, selected augmentation and physical image path. Identity records point to preprocessed cache images. |
| `.../cnn_feature_model.mat`, `cnn_training_history.csv` | Trained CNN, trainNetwork information and per-iteration training loss/accuracy. |
| `.../fold_features.mat`, `svd_values.csv`, `fit_metadata.json` | Raw transformed training/validation features, original membership, lesion descriptors, fitted SVD statistics/loadings, singular values and seeds. |
| `.../raw_training_features.csv`, `raw_evaluation_features.csv`, `feature_schema.csv` | Raw fused columns before SVD, with ancestry/evaluation membership and exact column names; MAT also preserves these matrices. |
| `.../training_ewt_diagnostics.csv`, `evaluation_ewt_diagnostics.csv` | Per-image EWT tight-frame/reconstruction errors, energy differences and peak-detection fallback. |
| `<task>/final_features/Figure9_implemented_CNN.fig/.png` | Layer graph of the implemented CNN, with explicit reconstruction dimensions. |
| `<task>/final_features/NEW_training_SVD.fig/.png` | Actual training singular values and cumulative variance. |
| `<task>/candidate_fitness/<hash>/` | Candidate parameters, pooled CV counts/error/fitness, fold-level models and per-case CV validation predictions. Candidate identity is SHA256 of its decoded parameters. |
| `<task>/optimization/<model>/trial_XX/` | Search trace of every evaluated wolf, seed, alpha/chi, selected-feature count, objective, cache use and elapsed time. Convergence CSV/FIG/PNG and full raw optimizer checkpoint/result. |
| `.../search_checkpoint.mat` | Positions, amplitudes QA/QB, measured thresholds, rotation angles, leaders/best state, random stream and next iteration. |
| `.../best_qubit_coordinates.csv` | Every coordinate of the best NIMEQ state per trial: amplitudes, norm squared, amplitude-one squared, sigmoid threshold, chromosome value and rotation role. |
| `.../all_trial_best_fitness.csv`, `fitness_statistics.csv` | All trial optima and arithmetic mean, sample standard deviation, min/max. Trial selection uses inner CV only. |
| `<Table4 task>/Table4_NEW_trials.csv`, `Table4_NEW_mean.csv`, `Table4_NEW_best_state.mat` | Actual ten-trial results in full/workstation, including optimal iteration; one trial in quick. All qubit states remain in per-trial MAT/CSV outputs. |
| `<task>/<model>/sac_model.mat`, `training_checkpoint.mat` | Trained discriminator and generator, chosen mask/parameters, seed, Adam moments, spectral-state estimates, RNG state and epoch history. |
| `<task>/<model>/case_predictions.csv` | Original held-out source file, hash, native grade, true/predicted task label, class score/length, partition, run and model. |
| `<task>/<model>/confusion_counts.csv/.mat` | Integer multiclass counts, rows true and columns predicted; full class order retained even for zero-support classes. |
| `<task>/<model>/class_metrics.csv` | TP/FN/FP/TN/support and all per-class metrics calculated from those counts. |
| `<task>/<model>/overall_metrics.csv` | Overall accuracy and ordinary error, macro/micro/weighted metrics and multiclass MCC. Class OVR accuracy is never called overall accuracy. |
| `<task>/<model>/class_order.json` | Numeric label indices and the score definition. Normalized capsule lengths are not calibrated probabilities. |
| `<task>/<model>/roc_class_*.csv`, `auc.csv`, `ROC.fig/.png` | Threshold-level ROC data, tie-aware AUC and native figure. Undefined-class AUC is NaN, not silently replaced. |
| `<task>/<model>/training_history.csv`, `Training_history.fig/.png` | Actual epoch-level discriminator/generator/capsule losses and training accuracy. |
| `<task>/<model>/NEW_feature_attention_and_capsules.mat`, `NEW_feature_attention.fig/.png` | Raw 64x64 attention and class capsules on the first held-out case. These are SVD feature attention, not retinal pixel attribution. |
| `<task>/<model>/NEW_generated_feature_grids.mat/.fig/.png` | One conditional generator output per class in feature space. These are not synthetic fundus photographs. |
| `<task>/<model>/inference_bundle.mat` | Discriminator/generator, class mapping, preprocessing configuration, SVD and relative path to the final CNN. Move the whole task folder together for inference. |
| `<task>/<model>/network_parameter_shapes.csv` | Actual discriminator/generator parameter names, tensor dimensions and counts. |
| `<task>/Table6_NEW_class_metrics.csv` through `Table10_NEW_class_metrics.csv` | Concatenated measured per-class tables for the corresponding task/model variants. |
| `<task>/NEW_overall_metrics.csv`, `task_results.mat` | Aggregate measured task results and raw plotting arrays. |
| `<task>/Figure13_*.fig/.png` through `Figure16_*.fig/.png` | New heatmap, class metric comparison, radar chart and confusion-matrix graphics from the exported counts. Figure numbers indicate comparable output types, not copies of original publication graphics. |
| `<task>/additional_majority_vote/` | Clearly separated additional voting experiment; its scores are averaged variant scores and no class capsule lengths exist for the ensemble (NaN). |
| `<task>/legacy_classifiers/` | Optional held-out red/bright/fused SVM/KNN/tree/voting experiments, models, per-case predictions, threshold metrics and new F1 curves. |
| `Table11_NEW_experiment_summary.csv` | All newly measured tasks/model variants, using overall accuracy and explicit macro metrics. It is not an invented re-execution of the literature comparators. |
| `NEW_vs_published_values.csv` | Post-experiment differences against printed Tables6–10. Printed error fractions are multiplied by100 before comparison to new balanced-error percentages. |
| `printed_table_arithmetic_diagnostics.csv` | F1 from printed precision/recall, accuracy interval tests and Table5 error formula. Arithmetic diagnostics do not establish the authentic corrected historical performance. |
| `printed_table4_arithmetic.json` | Mean of printed ten values=.0483; published mean=.0553; difference=.0070. This is arithmetic on printed text, not original optimizer data. |
| `output_sha256.csv` | Relative path, bytes and SHA256 of output files after completion. The actively written console log and inventory itself are excluded. |
| `verification/<unique-check-directory>/verification_checks.csv`, `verification_summary.json` | Metrics rederived from case labels, source/group/ancestry checks and native-figure existence. Optional deep CV/source-byte checks are identified. Verification folders are excluded from output_sha256 so repeating checks does not change old inventories. |

Input-quality reports are written under `data/quality_reports/` and copied into each run's `input_quality/`: contradictory labels for identical image bytes, accepted manifest and known-patient coverage. Their hashes also enter the run signature. Accepted membership and source hashes are preserved in the run manifests.

Figures1–6,10–11 in the paper illustrate background concepts and method topology; they do not provide numerical experimental targets. Their implemented relationships are described in `METHOD_MAPPING.md` and the actual layer graph. No figure is supplied as an alleged original software output.

Local environment and self-test reports are under `local_validation/`. Version2 run names are `quick_v2_seed41`, `workstation_v2_seed41` and `full_v2_seed41`. Workstation/full retain ten Table4 trials with different declared CV/training/search budgets. Quick has one trial.

## External tables and citations

`published_reference/` preserves the 84 rows of Tables6–10, ten Table4 fitness values and20 printed Table11 rows, plus qualified citation-review notes. References88,89,91 require metric/dataset corrections; not all comparator reports have been verified in full. Reference-addition history remains information the authors must supply. New model training cannot resolve the historical reason a citation was added.
