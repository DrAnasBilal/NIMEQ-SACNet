# EWT option added in version 2

The article claims empirical wavelet feature extraction but does not specify an operative algorithm, location, settings or historical code. Version1 left this unresolved. Version2 supplies a **new, explicit reconstruction option**, enabled by `cfg.ewt.enabled=true`. Adding it does not establish which EWT, if any, produced the original results.

## Implemented procedure

For each quantized enhanced/augmented image, convert RGB to grayscale, compute the centered 2-D FFT and average spectral magnitude in128 Cartesian radial bins. Smooth its log magnitude with a nine-bin Gaussian kernel. Select up to three separated spectral peaks plus the zero-frequency mode, then use adjacent-peak midpoints as radial boundaries. If fewer peaks exist, subdivide the widest intervals until four bands exist; flag that fallback for each observation.

Construct one radial lowpass and three annular detail filters with complementary sine/cosine Meyer transitions. The last band includes Fourier-plane corners. Transition half-width is the smaller of `.25*boundary` and `.45*adjacent minimum gap`, preventing overlap. The smooth step is `x^4*(35-84*x+70*x^2-20*x^3)` on clipped[0,1]. Analysis filters operate in the Fourier domain; corresponding synthesis filters reconstruct the image.

The radial tight-frame concept is based on [Gilles, Tran and Osher, *2D Empirical Transforms*, DOI 10.1137/130923774](https://doi.org/10.1137/130923774), Section5. The reference detector uses a pseudo-polar spectrum; **this implementation deliberately uses Cartesian radial averages**, with its fixed-band fallback and descriptors specified here. Code is newly written and needs no external EWT toolbox.

## Features and placement

Each band contributes energy fraction, mean absolute coefficient, sample standard deviation and normalized coefficient-energy entropy. Three boundary frequencies normalized to the Fourier-corner radius complete a **19-column vector**. Zero-energy bands receive zero fraction/entropy. Default fusion is CNN256 + lesion10 + EWT19 =285 raw columns, followed by training-fitted normalization/SVD to64 components.

Per-image frequency detection uses no class labels or other evaluation images. EWT runs on the same saved quantized image that feeds the CNN. Training/inference share feature assembly and column schema. Published metrics are never an EWT target.

## Checks and outputs

- `examples/NEW_ewt_raw.mat`: enhanced image, bands, filters, features and diagnostics.
- `examples/NEW_ewt_spectrum.csv`, `NEW_ewt_boundaries.csv` and `NEW_ewt_decomposition.fig/.png`.
- `training_ewt_diagnostics.csv` and `evaluation_ewt_diagnostics.csv`: tight-frame/reconstruction errors, energy difference and fallback for every observation.
- `feature_schema.csv`, raw feature CSVs and `fold_features.mat`: the actual EWT columns.

MATLAB tests check zero/constant/random inputs, odd/rectangular sizes, inverse synthesis, energy and feature dimensions; run them locally. Independent NumPy algebra checks passed36 cases with two/four/six bands. This does not validate MATLAB execution.

Use `cfg.ewt.enabled=false` with a new name to omit this branch. `RUN_SENSITIVITY` reports fixed EWT-on/off comparisons. Disclose the choice in new experiments; do not describe it as recovered historical methodology.
