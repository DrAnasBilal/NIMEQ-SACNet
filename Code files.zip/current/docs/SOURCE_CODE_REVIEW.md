# Supplied code review

All20 user-supplied files are preserved under `reference_inputs/`, with original filenames except the paper's safe filename `paper.pdf`. `inventory.json` records original names, byte counts and SHA256. These files are reference material and must not be recursively added to the executable MATLAB path.

| Supplied material | Review and treatment |
|---|---|
| `DR_feats_fcn(2).m` | Main source of YCbCr enhancement, red/bright morphology and five descriptors per lesion. Fixed the uncommented `Preprocessing step` text; perform adaptive thresholding per2-D channel; handle empty connected regions; remove plotting/training-side effects. The actual bright polarity `dark` is preserved, configurable and documented as uncertain. |
| `DR_Starter_Code(2).m`, `newstarter.m`, `DR_Classification*.m`, `Algo(2).m`, `Bright_Lesions_only(2).m`, `mG.m`, `OD.m` | Overlapping demonstrations of lesion processing, image-folder loops, classifiers and optic-disc/morphology experiments. Useful lesion logic consolidated into namespaced functions; inconsistent feature counts, bright properties taken from red masks in one version, fixed paths and resubstitution-style evaluation are not propagated. No complete paper CNN/SACNet/quantum training implementation exists in these files. |
| `aug(1).m`, `auggtr(1).m` | Reused the demonstrated rotation/scale ideas in addition to the Figure7 operation bank. All augmentation now occurs only after source split; mask geometry and ancestry are retained. |
| `KNNPO.m` | Legacy KNN-related baseline, not evidence of a SACNet fitness function. New main-model search trains actual SACNet in inner CV. Optional KNN remains a separately labeled held-out legacy baseline. |
| `calculate_performance_metrics(2).m`, `calculate_results(2).m` | Confusion-matrix orientation/FP/FN naming needs correction. New metrics derive explicitly from true-row/predicted-column counts. Swapping precision and recall would leave harmonic-mean F1 unchanged; it cannot by itself explain arbitrary printed F1 discrepancies. |
| `curves(1).m` | Hardcoded plotting values. Preserved for provenance, not used to generate measured results. |
| `curveskhan(1).m` | Toy/random plotting material and invalid network syntax. Preserved; not used as experiment evidence or a paper-model implementation. |
| `Old_mat_file_4_feats.mat` | MATLAB5 header dated15Dec2019; low-level inspection finds `Fused_Feats`8x413 and legacy four-descriptor arrays. Contains opaque MATLAB object content; no verified source-ID/label/prediction join. Not silently imported for training or treated as original paper results. Header dates do not establish provenance. |
| `F1 score.fig` | MATLAB5 header dated10Dec2021. Contains four legacy series over indices1..4: SVM, KNN, Trees, Mixture. Not SACNet runs. Preserved as supplied, not relabeled as newly trained network output. |

## Inspected legacy figure values

These values came from the FIG structure and are not used by the new code:

| Series | Four stored Y values |
|---|---|
| SVM | .93922652, .93822394, .88789238, .87356322 |
| KNN | .88311688, .87450980, .65137615, .50602410 |
| Trees | .93406593, .93023256, .86440678, .77777778 |
| Mixture | .96539162, .97109827, .94915254, .91111111 |

Source-file inspection identifies reusable implementation ideas. It does not authenticate which historical experiment generated the article's tables. New code and new runs should be dated and described as such.
