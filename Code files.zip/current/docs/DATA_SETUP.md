# Dataset setup and troubleshooting

## Normal directories

`RUN_ALL.m` expects the official IDRiD **Disease Grading** image/label tree under `data/IDRiD`. It recursively finds one training-label CSV and one testing-label CSV, reads the image-name and retinopathy-grade columns, and joins images by filename stem and training/testing path. The official grading split has413training and103testing records before any integrity exclusions. Keep the official structure; the segmentation subset alone does not supply the whole grading experiment.

DR7 version0.2 is [record4647952](https://zenodo.org/records/4647952), with757records and grades0..6 in its annotation workbook. The downloader uses the record's published archive checksum. Extract manually if your MATLAB installation cannot access Zenodo. Automatic import expects the workbook columns `Image` and `Status`; the quoted paper version uses zero-based labels. If you intentionally use another version, provide its exact labels/provenance and a new experiment name rather than relabeling it as the cited version.

The code hashes every source file. Conflicting grades attached to identical image bytes quarantine every conflicting member. Resulting sample counts may therefore differ from the archive's nominal counts. Inspect `data/quality_reports` and the saved run copy under `input_quality/`. Do not delete inconvenient records solely to improve accuracy.

## Explicit manifest for renamed folders

If the standard importer cannot unambiguously join your directory tree, create a UTF-8CSV with these columns and set `cfg.data.manifestCSV` in a custom runner:

| Column | Meaning |
|---|---|
| `dataset` | Exactly `IDRiD` or `DR7`. |
| `sample_id` | Unique nonempty ID within that dataset. |
| `image_path` | Full image path, or a path relative to the manifest directory. |
| `grade` | Native integer grade:IDRiD0..4;DR7zero-based0..6. |
| `source_split` | `training` or `testing` for official IDRiD mode; optional for DR7/resplit. |
| `patient_id` | Optional verified patient identifier. Blank means unknown, not an independent patient. |

Example record structure (replace paths and IDs with actual source records):

```csv
dataset,sample_id,image_path,grade,source_split,patient_id
IDRiD,training/IDRiD_001,images/training/IDRiD_001.jpg,3,training,
```

This line is a schema illustration, not a supplied label annotation. Do not copy its grade as ground truth.

Patient identifiers can alternatively be supplied as a separate CSV with `dataset,sample_id,patient_id` columns via `cfg.data.patientCSV`. Known patients and exact duplicate bytes become connected source groups. An official split crossing such a group stops with an error. Investigate the record; `cfg.split.idridMode='resplit'` explicitly requests a new grouped split if appropriate and must be reported as such.

## Custom runner

```matlab
projectRoot=fileparts(mfilename('fullpath'));
addpath(projectRoot);
cfg=nimeq_config('full');
cfg.data.idridRoot='D:\datasets\IDRiD';
cfg.data.dr7Root='D:\datasets\DR7';
cfg.data.downloadDR7=false;
cfg.execution='auto';
cfg.experimentName='my_measured_run_seed41';
nimeq.run_all(cfg);
```

Save a custom runner in the project folder so `projectRoot` resolves correctly. Changing tasks, epochs, fold counts, quantum mode or segmentation polarity requires a new experiment name. If changing folds, set both `cfg.search.folds` and `cfg.split.folds` consistently.

The project needs write access to its data checks, augmentation cache, results and checkpoint directories. No synthetic dataset stands in for the real data in `RUN_QUICK` or `RUN_ALL`.
