% Verify a COMPLETED run by recalculating metrics from the individual cases.
projectRoot=fileparts(mfilename('fullpath'));addpath(projectRoot);
runRoot=fullfile(projectRoot,'results','workstation_v2_seed41');
rehashSourceImages=false; % true: also reread all original images and SHA256.
deepCV=false; % true: also rederive every cached candidate's pooled CV fitness.
nimeq.verify_run(runRoot,rehashSourceImages,deepCV,true);
