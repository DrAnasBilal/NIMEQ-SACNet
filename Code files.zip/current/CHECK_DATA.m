% Check actual dataset membership, labels, duplicates and grouped splits.
projectRoot=fileparts(mfilename('fullpath')); addpath(projectRoot);
cfg=nimeq_config('full');
cfg.data.downloadDR7=true;
M=nimeq.prepare_manifest(cfg);
out=fullfile(projectRoot,'data_check'); if ~isfolder(out),mkdir(out);end
writetable(M,fullfile(out,'manifest.csv'));
for dataset=["IDRiD","DR7"]
    D=M(M.dataset==dataset,:);
    S=nimeq.make_splits(D,cfg);
    writetable(S,fullfile(out,char(dataset+"_split.csv")));
end
disp('Data checks completed. Inspect data_check and data/quality_reports.');
