% Exercise the complete workflow with a reduced budget on REAL DR7 images.
% This profile is for checking installation and execution, not paper results.
projectRoot = fileparts(mfilename('fullpath'));
addpath(projectRoot);
cfg = nimeq_config('quick');
cfg.data.dr7Root = fullfile(projectRoot,'data','DR7');
cfg.data.downloadDR7 = true;
nimeq.run_all(cfg);
