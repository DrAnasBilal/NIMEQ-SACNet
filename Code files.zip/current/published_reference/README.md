# Published reference data only

The CSV files in this directory are transcriptions/reviews, not training targets and not raw experiment data.

- `tables6_10_as_printed.csv`: all84 printed rows, preserving malformed F1 `9.3.73`, error1.0765, specificity8.25 and error`.01035` exactly as printed.
- `table4_as_printed.csv`: ten printed fitness values; arithmetic mean.0483, distinct from the published.0553.
- `table11_as_printed_rows.csv`: twenty printed rows, including fifteen external comparator rows and five proposed-method rows. Its heading's dataset assignment is not accepted as verified for every source.
- `citation_review.csv`: relevance, source correction and verification limitations for references9,17,19,88,89,91. The reason and history of adding a citation must come from the authors and manuscript records, not inference.

Only `compare_published` and `audit_published` read these numbers, after new training/evaluation. Literature claims cannot be repaired by training this model; check the original comparator publications and issue source-specific corrections.
