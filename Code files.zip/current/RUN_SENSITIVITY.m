% OPTIONAL declared sensitivity experiments, not historical method recovery.
% Runs DR7 binary / NIMEQ only at the workstation budget. Reports every variant.
projectRoot=fileparts(mfilename('fullpath'));addpath(projectRoot);
base=nimeq_config('workstation');base.tasks="DR7_binary";
base.models="NIMEQ-SACNet";base.legacyBaselines=false;base.data.downloadDR7=true;
names=["declared_EWT","without_EWT","literal_quantum","bright_polarity"];
summary=table;
for j=1:numel(names)
    cfg=base;cfg.experimentName=char("sensitivity_v2_"+names(j)+"_seed41");
    if j==2,cfg.ewt.enabled=false;end
    if j==3,cfg.search.quantumMode='literal';end
    if j==4,cfg.seg.brightPolarity='bright';end
    root=nimeq.run_all(cfg);
    Q=readtable(fullfile(root,'Table11_NEW_experiment_summary.csv'),'TextType','string');
    Q.sensitivity_variant=repmat(names(j),height(Q),1);
    if isempty(summary),summary=Q;else,summary=[summary;Q];end %#ok<AGROW>
end
writetable(summary,fullfile(base.outputRoot,'sensitivity_v2_all_variants.csv'));
disp('All variants reported; no variant was selected by held-out accuracy.');
