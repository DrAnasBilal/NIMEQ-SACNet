"""Independent NumPy checks. These DO NOT execute or validate MATLAB APIs.

Run: python validation/check_math.py (requires NumPy).
No fabricated scientific performance is exported by this validation.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import re
from decimal import Decimal
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def metric_identities():
    rng = np.random.default_rng(7281)
    count = 0
    for k in (2, 5, 7):
        for _ in range(300):
            c = rng.integers(1, 1000, (k, k))
            n = c.sum()
            tp = np.diag(c)
            fn = c.sum(axis=1) - tp
            fp = c.sum(axis=0) - tp
            tn = n - tp - fn - fp
            recall, spec = tp / (tp + fn), tn / (tn + fp)
            precision = tp / (tp + fp)
            f1 = 2 * tp / (2 * tp + fp + fn)
            np.testing.assert_allclose(f1, 2 * precision * recall / (precision + recall))
            accuracy = (tp + tn) / n
            prevalence = (tp + fn) / n
            np.testing.assert_allclose(accuracy, prevalence * recall + (1 - prevalence) * spec)
            assert np.all(accuracy >= np.minimum(recall, spec) - 1e-12)
            assert np.all(accuracy <= np.maximum(recall, spec) + 1e-12)
            np.testing.assert_allclose(1 - (recall + spec) / 2, (fn / (tp + fn) + fp / (tn + fp)) / 2)
            micro_f1 = 2 * tp.sum() / (2 * tp.sum() + fp.sum() + fn.sum())
            np.testing.assert_allclose(micro_f1, np.trace(c) / n)
            if k == 2:
                np.testing.assert_allclose(accuracy[0], accuracy[1])
            count += 1
    return count


def squash(x, axis):
    norm2 = np.sum(x*x, axis=axis, keepdims=True)
    return norm2 / (1 + norm2) * x / np.sqrt(norm2 + 1e-8)


def sac_shape_reference():
    """Independent forward algebra after the convolution, batch-first notation."""
    rng = np.random.default_rng(373)
    checked = []
    for k in (2, 5, 7):
        for batch in (1, 3, 32):
            h = rng.normal(size=(batch, 32, 64))
            q = rng.normal(size=(4, 32)) @ h
            key = rng.normal(size=(4, 32)) @ h
            v = rng.normal(size=(32, 32)) @ h
            similarity = key.transpose(0, 2, 1) @ q
            e = np.exp(similarity - similarity.max(axis=1, keepdims=True))
            attention = e / e.sum(axis=1, keepdims=True)
            np.testing.assert_allclose(attention.sum(axis=1), 1, atol=1e-12)
            context = v @ attention
            h = h + .7 * context
            primary_w = rng.normal(scale=.03, size=(128, 2048))
            # The shape test is independent of MATLAB's column-major flatten order.
            primary = (h.reshape(batch, 2048) @ primary_w.T).reshape(batch, 16, 8)
            primary = squash(primary, 2)
            weights = rng.normal(scale=.1, size=(16, k, 16, 8))
            votes = np.einsum('pkdi,bpi->bpkd', weights, primary)
            logits = np.zeros((batch, 16, k, 1))
            for routing in range(3):
                e = np.exp(logits - logits.max(axis=2, keepdims=True))
                coupling = e / e.sum(axis=2, keepdims=True)
                capsule = squash((coupling * votes).sum(axis=1, keepdims=True), 3)
                if routing < 2:
                    logits += (votes * capsule).sum(axis=3, keepdims=True)
            lengths = np.sqrt((capsule**2).sum(axis=3) + 1e-8).reshape(batch, k)
            assert lengths.shape == (batch, k)
            assert np.isfinite(lengths).all()
            assert np.all(lengths <= 1 + 1e-7)
            scores = lengths / lengths.sum(axis=1, keepdims=True)
            np.testing.assert_allclose(scores.sum(axis=1), 1, atol=1e-12)
            checked.append({'classes': k, 'batch': batch, 'lengths_shape': list(lengths.shape)})
    return checked


def quantum_rotation_reference():
    rng = np.random.default_rng(819)
    a = np.ones((8, 80, 3)) / math.sqrt(2)
    b = a.copy()
    for _ in range(100):
        angle = rng.normal(size=(8, 1, 3)) * 25
        aa = np.cos(angle) * a - np.sin(angle) * b
        bb = np.sin(angle) * a + np.cos(angle) * b
        norm = np.sqrt(aa*aa + bb*bb)
        a, b = aa / norm, bb / norm
        np.testing.assert_allclose(a*a + b*b, 1, atol=1e-12)
    return {'states': 8*80*3, 'rotations_per_state': 100, 'normalization': 'passed'}


def reference_integrity():
    inventory = json.loads((ROOT/'reference_inputs/inventory.json').read_text())
    for item in inventory:
        path = ROOT/item['preserved_path']
        assert path.stat().st_size == item['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
    rows = list(csv.DictReader((ROOT/'published_reference/tables6_10_as_printed.csv').open()))
    assert len(rows) == 84
    assert sum(r['f1'] == '9.3.73' for r in rows) == 1
    assert sum(r['error_rate'] == '1.0765' for r in rows) == 1
    assert sum(r['specificity'] == '8.25' for r in rows) == 1
    assert sum(r['error_rate'] == '.01035' for r in rows) == 1
    trials = list(csv.DictReader((ROOT/'published_reference/table4_as_printed.csv').open()))
    mean = sum(Decimal(r['best_fitness']) for r in trials) / len(trials)
    assert mean == Decimal('.0483')
    return {'unchanged_source_files': len(inventory), 'printed_metric_rows': len(rows), 'mean_printed_table4': str(mean)}


def ewt_reference():
    """Independent NumPy implementation of the declared radial filter algebra.

    This verifies energy, inverse synthesis and descriptors, not MATLAB APIs.
    """
    rng = np.random.default_rng(2210)
    cases = []
    for h, w in ((32, 32), (31, 45), (64, 48)):
        yy, xx = np.meshgrid(np.arange(h), np.arange(w), indexing='ij')
        images = {'zero': np.zeros((h,w)), 'constant': np.ones((h,w)),
                  'noise': rng.random((h,w)),
                  'sinusoids': .5 + .2*np.sin(2*np.pi*xx/w*7) + .2*np.sin(2*np.pi*yy/h*3)}
        for label, image in images.items():
            for n in (2, 4, 6):
                radius_max = np.sqrt(2)*np.pi
                fx = np.arange(-(w//2), math.ceil(w/2))*2*np.pi/w
                fy = np.arange(-(h//2), math.ceil(h/2))*2*np.pi/h
                gx, gy = np.meshgrid(fx, fy)
                radius = np.sqrt(gx*gx+gy*gy)
                spectrum = np.fft.fftshift(np.fft.fft2(image))
                index = np.minimum(127, np.floor(radius/radius_max*128).astype(int))
                count = np.bincount(index.ravel(), minlength=128)
                profile = np.bincount(index.ravel(), weights=np.abs(spectrum).ravel(), minlength=128)/np.maximum(count,1)
                frequency = (np.arange(128)+.5)/128*radius_max
                q = np.arange(-4,5);kernel=np.exp(-.5*(q/(9/4))**2);kernel/=kernel.sum()
                smooth=np.convolve(np.pad(np.log1p(profile),4,mode='edge'),kernel,mode='valid')
                candidates=np.where((smooth[1:-1]>smooth[:-2])&(smooth[1:-1]>=smooth[2:]))[0]+1
                candidates=candidates[candidates+1>4]
                chosen=[]
                for k in candidates[np.argsort(-smooth[candidates],kind='stable')]:
                    if not chosen or all(abs(k-z)>=4 for z in chosen):chosen.append(int(k))
                    if len(chosen)==n-1:break
                peaks=np.sort(np.r_[0,frequency[chosen]])
                boundary=(peaks[:-1]+peaks[1:])/2
                while len(boundary)<n-1:
                    edges=np.r_[0,boundary,radius_max];j=np.argmax(np.diff(edges))
                    boundary=np.sort(np.r_[boundary,(edges[j]+edges[j+1])/2])
                gaps=np.diff(np.r_[0,boundary,radius_max])
                tau=np.minimum(.25*boundary,.45*np.minimum(gaps[:-1],gaps[1:]))
                masks=[];bands=[]
                def beta(v):
                    v=np.clip(v,0,1)
                    return np.clip(v**4*(35-84*v+70*v*v-20*v**3),0,1)
                for b in range(n):
                    mask=np.ones((h,w))
                    if b>0:mask*=np.sin(np.pi/2*beta((radius-(boundary[b-1]-tau[b-1]))/(2*tau[b-1])))
                    if b<n-1:mask*=np.cos(np.pi/2*beta((radius-(boundary[b]-tau[b]))/(2*tau[b])))
                    masks.append(mask);bands.append(np.fft.ifft2(np.fft.ifftshift(spectrum*mask)).real)
                masks=np.stack(masks);bands=np.stack(bands)
                np.testing.assert_allclose((masks*masks).sum(axis=0),1,atol=1e-12)
                restored=sum(np.fft.ifft2(np.fft.ifftshift(np.fft.fftshift(np.fft.fft2(c))*f)).real for c,f in zip(bands,masks))
                error=float(np.max(np.abs(restored-image)))
                assert error<1e-12
                np.testing.assert_allclose((bands*bands).sum(),(image*image).sum(),atol=1e-10,rtol=1e-12)
                energy=(bands*bands).sum(axis=(1,2));features=[]
                for b,c in enumerate(bands):
                    mass=c.ravel()**2;normalizer=mass.sum();entropy=0
                    if normalizer>np.finfo(float).eps:
                        p=mass/normalizer;p=p[p>0];entropy=-(p*np.log(p)).sum()/np.log(c.size)
                    features.extend([energy[b]/max(energy.sum(),np.finfo(float).eps),np.abs(c).mean(),c.std(ddof=1),entropy])
                features.extend(boundary/radius_max)
                assert len(features)==5*n-1 and np.isfinite(features).all()
                cases.append({'shape':[h,w],'input':label,'bands':n,'inverse_max_error':error})
    return {'cases':len(cases),'max_inverse_error':max(c['inverse_max_error'] for c in cases),
            'zero_constant_noise_sinusoids':True,'band_counts':[2,4,6]}


def dependency_and_target_separation():
    files = list((ROOT/'+nimeq').glob('*.m')) + list(ROOT.glob('*.m'))
    defined = {p.stem for p in (ROOT/'+nimeq').glob('*.m')}
    called = set()
    reference_readers = []
    for p in files:
        code = p.read_text()
        called.update(re.findall(r'nimeq\.(\w+)', code))
        if re.search(r'fullfile\([^;\n]*[\'\"]published_reference[\'\"]',code):
            reference_readers.append(p.stem)
    assert called <= defined, sorted(called - defined)
    assert set(reference_readers) == {'compare_published', 'audit_published'}
    return {'namespace_calls_resolved': len(called), 'reference_number_readers': sorted(reference_readers)}


if __name__ == '__main__':
    result = {
        'scope': 'Independent Python/NumPy mathematics and file checks; MATLAB execution was NOT performed.',
        'random_confusion_matrices': metric_identities(),
        'sac_algebra_shapes': sac_shape_reference(),
        'quantum_reference': quantum_rotation_reference(),
        'ewt_reference': ewt_reference(),
        'reference_integrity': reference_integrity(),
        'dependency_scan': dependency_and_target_separation(),
    }
    print(json.dumps(result, indent=2))
