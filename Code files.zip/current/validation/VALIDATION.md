# Validation status

Version2 development checks were performed on21October2026. **MATLAB and Octave are not installed in the development environment. No MATLAB unit test, training experiment, dataset import, generated MATLAB figure or numerical performance result has been executed or verified here.** The following completed checks must not be mistaken for MATLAB execution.

| Check | Actual status | Scope |
|---|---|---|
| Read attached paper and scripts | Completed | All24PDF pages and all17MATLAB source scripts were read; key method/table pages visually inspected. MAT/FIG structures inspected with available non-MATLAB readers, with opaque content limitations documented. |
| MATLAB static parser | Passed | MISS_HIT0.9.44 parses all authored MATLAB functions, runners and tests. It does not verify toolbox API calls, gradients, data import, memory, numerical convergence or performance. Preserved legacy input scripts are intentionally excluded. See `matlab_static_parser_log.txt`. |
| Independent metric identities | Passed | Python/NumPy checks900positive integer confusion matrices across2,5,7classes. Harmonic F1, prevalence-weighted class accuracy, balanced error and micro-F1/overall-accuracy identities checked. This independently checks mathematics, not MATLAB implementation execution. |
| Independent SAC algebra shapes | Passed | Nine class/batch cases:K2/5/7withbatch1/3/32. Attention normalization, primary/class capsule dimensions, routing, bounded capsule lengths and normalized scores. This omits the MATLAB convolution/generator API and does not verify MATLAB differentiation. |
| Independent normalized qubits | Passed | 1920amplitude pairs rotated/normalized100times each; norm²remains1. Does not establish that the reconstructed optimizer matches the original experiment. |
| Independent EWT algebra | Passed | 36NumPy cases across zero/constant/noise/sinusoidal inputs, odd/rectangular shapes and2/4/6bands. Tight-frame sum, energy preservation, descriptor size and inverse synthesis checked. Maximum inverse error below1e-12. This is not MATLAB execution. |
| Source integrity | Passed | SHA256 and byte count match for all20preserved supplied files;84printed metric rows and the malformed strings are preserved. |
| MATLAB namespace dependency scan | Passed | All `nimeq.*` calls resolve to included namespace files. Only the post-experiment reference-comparison/audit functions access printed metric CSVs. |
| Actual MATLAB unit/gradient smoke tests | **Not run** | Run `RUN_SELF_TEST` locally. Covers metrics/undefined cases, ROC ties, segmentation, descriptors, augmentation, label-conflict quarantine, grouped splits, training-fitted SVD, seeded search/qubits, SAC shapes/gradients/train/predict/resume, EWT inverse/energy and detection of an intentionally altered metric in a synthetic verification fixture. |
| Full workflow on real datasets | **Not run** | Execute `RUN_QUICK`, inspect output, then use workstation/full as appropriate. No original or new performance claim is made. |

`independent_math_log.json` contains the executed Python check results. Run `python validation/check_math.py` to repeat them if NumPy is installed; Python is not a dependency of the MATLAB experiment pipeline.

## What to establish locally

1. Run `RUN_ENVIRONMENT_CHECK` and `RUN_SELF_TEST` on your MATLAB/toolbox release. Environment, console and test results are saved under `local_validation/`. If a test fails, retain the error and fix the implementation before training.
2. Dataset joins, class counts, exclusions and group membership match the intended task. Inspect the raw manifests and `class_membership_counts.csv`. Missing training classes stop a fit; do not fill them with copied test images or invented labels.
3. The quick profile completes all four real-data model variants and outputs finite loss/feature arrays, case predictions, counts, figures and checkpoints. A completed quick run says nothing about full-profile performance.
4. The chosen workstation/full/custom run completes and automatic verification passes. `VERIFY_RESULTS` can repeat the numerical/membership checks and optionally rehash sources or inspect all CV candidates. These checks have not been executed here. Disclose settings, exclusions, uncertainty and differences from the original publication.

GPU/CPU arithmetic, release differences and nondeterministic GPU kernels may produce differences even with a fixed seed. This project does not claim bitwise reproducibility across hardware. Checkpointing preserves recorded model/search state within one fixed run configuration.

No runtime or accuracy guarantee, pretrained paper weights, original raw predictions, or journal-outcome assurance is included.
