% All five tasks/four variants with a declared, reduced local-computer budget.
% Produces new results with these settings; it is not the full paper budget.
projectRoot=fileparts(mfilename('fullpath'));addpath(projectRoot);
cfg=nimeq_config('workstation');
cfg.data.idridRoot=fullfile(projectRoot,'data','IDRiD');
cfg.data.dr7Root=fullfile(projectRoot,'data','DR7');
cfg.data.downloadDR7=true;
% Reduce batch sizes for memory limits, use a NEW experimentName if changed.
nimeq.run_all(cfg);
