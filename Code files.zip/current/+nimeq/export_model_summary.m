function export_model_summary(model,folder)
rows=cell(0,4);
for field=fieldnames(model.D).'
    value=model.D.(field{1});rows(end+1,:)={'discriminator',field{1},mat2str(size(value)),numel(value)}; %#ok<AGROW>
end
T=model.G.Learnables;
for j=1:height(T)
    value=T.Value{j};rows(end+1,:)={'generator',char(string(T.Layer(j))+"/"+string(T.Parameter(j))),mat2str(size(value)),numel(value)}; %#ok<AGROW>
end
P=cell2table(rows,'VariableNames',{'component','parameter','tensor_shape','num_parameters'});
writetable(P,fullfile(folder,'network_parameter_shapes.csv'));
end
