function cfg=preflight(cfg)
% Old inference bundles keep their original feature contract (EWT disabled).
if ~isfield(cfg,'ewt')
    cfg.ewt=struct('enabled',false,'bands',4,'radialBins',128,'smoothingBins',9, ...
        'peakSeparationBins',4,'transitionFraction',.25);
end
if ~isfield(cfg.cnn,'verbose'),cfg.cnn.verbose=false;end
if ~isfield(cfg,'export'),cfg.export=struct('rawFeatureCSV',true);end
if ~isfield(cfg,'verification'),cfg.verification=struct('rehashSources',false,'deepCV',false);end
assert(~verLessThan('matlab','9.15'),'nimeq:Version','Target release is MATLAB R2023b or newer.');
for name={'imageInputLayer','dlnetwork','dlarray','trainNetwork','imbinarize','adapthisteq'}
    assert(exist(name{1},'file')~=0 || exist(name{1},'class')~=0,'nimeq:Dependency','Missing %s. Install Deep Learning and Image Processing Toolboxes.',name{1});
end
if cfg.legacyBaselines
    assert(exist('fitcecoc','file')~=0,'nimeq:Statistics','Legacy SVM/KNN/tree comparisons need Statistics and Machine Learning Toolbox, or set legacyBaselines=false.');
end
gpu=false;
try,gpu=canUseGPU;catch,end
if strcmpi(cfg.execution,'gpu'),assert(gpu,'nimeq:GPU','A supported GPU and Parallel Computing Toolbox are required.');end
if strcmpi(cfg.execution,'auto')
    if gpu,cfg.execution='gpu';else,cfg.execution='cpu';end
end
assert(ismember(cfg.execution,{'cpu','gpu'}),'nimeq:Execution','Execution must be auto, cpu or gpu.');
assert(cfg.search.population>=3 && cfg.search.iterations>=1,'nimeq:Search','Need at least three wolves and one iteration.');
assert(cfg.search.folds>=2 && cfg.search.folds==cfg.split.folds,'nimeq:CV','Set search.folds and split.folds to the same integer, at least two.');
assert(cfg.features.svdRank==64 && cfg.sac.gridSize==8,'nimeq:Grid','The supplied generator and feature grid use rank 64 and an 8x8 grid.');
assert(all([cfg.cnn.epochs,cfg.sac.epochs,cfg.search.fitnessEpochs,cfg.search.table4Trials,cfg.search.otherTrials]>=1), ...
    'nimeq:Budget','Epoch and trial budgets must be positive.');
integers=[cfg.cnn.epochs,cfg.cnn.batchSize,cfg.sac.epochs,cfg.sac.batchSize, ...
    cfg.search.population,cfg.search.iterations,cfg.search.folds,cfg.search.fitnessEpochs, ...
    cfg.search.table4Trials,cfg.search.otherTrials];
assert(all(isfinite(integers)&integers>=1&integers==fix(integers)),'nimeq:IntegerSettings','Epochs, batches, folds, population and trial counts must be positive integers.');
e=cfg.ewt;
assert(e.bands>=2&&e.bands<=8&&e.bands==fix(e.bands)&&e.radialBins>=32&&e.radialBins==fix(e.radialBins), ...
    'nimeq:EWTSettings','EWT uses 2..8 integer bands and at least 32 radial bins.');
assert(e.smoothingBins>=1&&e.smoothingBins==fix(e.smoothingBins)&&mod(e.smoothingBins,2)==1&&e.smoothingBins<e.radialBins, ...
    'nimeq:EWTSettings','EWT smoothing must be an odd positive integer below radialBins.');
assert(e.peakSeparationBins>=1&&e.peakSeparationBins==fix(e.peakSeparationBins)&&e.transitionFraction>0&&e.transitionFraction<.5, ...
    'nimeq:EWTSettings','Invalid EWT separation or transition fraction.');
assert(ismember(cfg.search.quantumMode,{'normalized','literal'})&&ismember(cfg.search.gwoUpdate,{'standard','literal'}), ...
    'nimeq:UpdateMode','Use the documented normalized/literal quantum and standard/literal GWO modes.');
assert(ismember(cfg.split.idridMode,{'official','resplit'}),'nimeq:SplitMode','IDRiD mode must be official or resplit.');
assert(isfinite(cfg.features.scoreScale)&&cfg.features.scoreScale>0,'nimeq:FeatureScale','SVD scoreScale must be positive and finite.');
assert(isfinite(cfg.augmentation.targetMultiplier)&&cfg.augmentation.targetMultiplier>0,'nimeq:AugmentationBudget','targetMultiplier must be positive and finite.');
cap=cfg.augmentation.maxPerOriginal;
assert((isinf(cap)&&cap>0)||(isfinite(cap)&&cap>=0&&cap==fix(cap)),'nimeq:AugmentationBudget','maxPerOriginal must be a nonnegative integer or positive Inf.');
assert(cfg.data.hashImages,'nimeq:SourceHashes','Source SHA256 hashes are required for this implementation.');
assert(~isempty(cfg.tasks)&&numel(unique(cfg.tasks))==numel(cfg.tasks)&&~isempty(cfg.models), ...
    'nimeq:Tasks','Choose nonempty, distinct tasks and model variants.');
assert(numel(unique(cfg.models))==numel(cfg.models) && all(ismember(cfg.models,["SACNet","GWO-SACNet","BGWO-SACNet","NIMEQ-SACNet"])), ...
    'nimeq:Models','Choose distinct supported model names.');
for name=cfg.tasks(:).',nimeq.task_info(name);end
fprintf('NIMEQ method implementation | profile %s | %s\n',cfg.profile,cfg.execution);
fprintf('Actual predictions determine all new metrics. No target table values are used by training.\n');
fprintf('Per optimized trial: up to %d candidate evaluations x %d CV folds x %d SACNet epochs.\n', ...
    cfg.search.population*cfg.search.iterations,cfg.search.folds,cfg.search.fitnessEpochs);
end
