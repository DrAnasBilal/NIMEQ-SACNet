function audit_published(cfg,folder)
% Arithmetic check of printed entries, independent of any newly trained model.
root=fullfile(cfg.projectRoot,'published_reference');
P=nimeq.read_csv_text(fullfile(root,'tables6_10_as_printed.csv'));
precision=str2double(P.precision);sensitivity=str2double(P.sensitivity);specificity=str2double(P.specificity);
accuracy=str2double(P.accuracy);f1=str2double(P.f1);errorRate=str2double(P.error_rate);
expectedF1=2*precision.*sensitivity./(precision+sensitivity);
expectedError=1-(sensitivity+specificity)/200;
T=P(:,{'table_number','task','model','class_label'});
T.printed_f1=P.f1;T.f1_from_printed_precision_recall_pct=expectedF1;
T.f1_difference_pct=f1-expectedF1;
T.f1_is_nonnumeric=~isfinite(f1);
[p0,p1]=interval(P.precision,0,100);[s0,s1]=interval(P.sensitivity,0,100);
[c0,c1]=interval(P.specificity,0,100);[a0,a1]=interval(P.accuracy,0,100);
[f0,f1high]=interval(P.f1,0,100);[e0,e1]=interval(P.error_rate,-Inf,Inf);
lowF=2*p0.*s0./(p0+s0);highF=2*p1.*s1./(p1+s1);
T.minimum_f1_compatible_with_printed_rounding_pct=lowF;
T.maximum_f1_compatible_with_printed_rounding_pct=highF;
T.f1_incompatible_with_printed_rounding=f1high<lowF-1e-10 | f0>highF+1e-10;
T.accuracy_below_min_recall_specificity_pct=min(sensitivity,specificity)-accuracy;
T.accuracy_above_max_recall_specificity_pct=accuracy-max(sensitivity,specificity);
T.accuracy_incompatible_with_any_prevalence_and_printed_rounding=a1<min(s0,c0)-1e-10 | a0>max(s1,c1)+1e-10;
T.printed_error_rate=errorRate;T.table5_error_from_printed_sensitivity_specificity=expectedError;
T.error_difference=errorRate-expectedError;
T.error_incompatible_with_table5_and_printed_rounding=e1<1-(s1+c1)/200-1e-10 | e0>1-(s0+c0)/200+1e-10;
writetable(T,fullfile(folder,'printed_table_arithmetic_diagnostics.csv'));
Q=readtable(fullfile(root,'table4_as_printed.csv'),'TextType','string');
values=Q.best_fitness;
nimeq.write_json(fullfile(folder,'printed_table4_arithmetic.json'),struct('n',numel(values), ...
    'arithmetic_mean_of_printed_trials',mean(values),'printed_mean',.0553, ...
    'printed_mean_minus_arithmetic_mean',.0553-mean(values), ...
    'meaning','Arithmetic on published text only; not recovered original optimization data'));
end

function [low,high]=interval(text,minimum,maximum)
v=str2double(text);half=nan(size(v));
for j=1:numel(text)
    raw=char(text(j));point=strfind(raw,'.');
    if isempty(point),digits=0;else,digits=numel(raw)-point(end);end
    half(j)=.5*10^(-digits);
end
low=max(minimum,v-half);high=min(maximum,v+half);
end
