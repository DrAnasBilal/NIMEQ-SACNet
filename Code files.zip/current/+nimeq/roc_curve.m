function [x,y,threshold,area]=roc_curve(truth,score)
truth=logical(truth(:));score=double(score(:));
assert(numel(truth)==numel(score) && all(isfinite(score)),'nimeq:ROC','ROC inputs must be matched and finite.');
P=sum(truth);N=sum(~truth);
if P==0 || N==0,x=[];y=[];threshold=[];area=NaN;return;end
[v,order]=sort(score,'descend');truth=truth(order);
tp=cumsum(truth);fp=cumsum(~truth);last=[find(diff(v)~=0);numel(v)];
x=[0;fp(last)/N];y=[0;tp(last)/P];threshold=[Inf;v(last)];area=trapz(x,y);
end
