function [X,diagnostics]=ewt_batch(paths,cfg,folder,prefix)
if nargin<4,prefix='images';end
N=numel(paths);X=zeros(N,5*cfg.ewt.bands-1,'single');values=zeros(N,4);
for j=1:N
    [X(j,:),info]=nimeq.ewt_features(imread(paths(j)),cfg);
    values(j,:)=[info.tight_frame_max_error,info.reconstruction_max_error,info.energy_difference,double(info.used_interval_subdivision)];
end
diagnostics=array2table(values,'VariableNames',{'tight_frame_max_error','reconstruction_max_error','energy_difference','used_interval_subdivision'});
diagnostics=addvars(diagnostics,string(paths(:)),'Before',1,'NewVariableNames','image_path');
if nargin>=3&&~isempty(folder)
    if ~isfolder(folder),mkdir(folder);end
    writetable(diagnostics,fullfile(folder,[prefix '_ewt_diagnostics.csv']));
end
end
