function T=output_inventory(root)
files=dir(fullfile(root,'**','*'));files=files(~[files.isdir]);
relative=strings(0,1);bytes=zeros(0,1);sha256=strings(0,1);
for j=1:numel(files)
    if ismember(files(j).name,{'console.log','output_sha256.csv'}),continue;end
    file=fullfile(files(j).folder,files(j).name);
    rel=string(strrep(file,[root filesep],''));
    if startsWith(rel,"verification"+string(filesep)),continue;end
    relative(end+1,1)=string(strrep(file,[root filesep],''));bytes(end+1,1)=files(j).bytes; %#ok<AGROW>
    sha256(end+1,1)=string(nimeq.hash_file(file)); %#ok<AGROW>
end
T=table(relative,bytes,sha256);
end
