function T=code_inventory(root)
files=[dir(fullfile(root,'*.m'));dir(fullfile(root,'+nimeq','*.m'));dir(fullfile(root,'tests','*.m'))];
relative=strings(numel(files),1);sha256=relative;
for j=1:numel(files)
    file=fullfile(files(j).folder,files(j).name);
    relative(j)=string(strrep(file,[root filesep],''));sha256(j)=string(nimeq.hash_file(file));
end
T=sortrows(table(relative,sha256),'relative');
end
