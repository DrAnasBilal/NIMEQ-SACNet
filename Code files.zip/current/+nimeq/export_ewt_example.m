function export_ewt_example(I,cfg,folder)
if ~cfg.ewt.enabled,return;end
I=im2single(im2uint8(I));[features,info,bands,filters]=nimeq.ewt_features(I,cfg);
save(fullfile(folder,'NEW_ewt_raw.mat'),'I','features','info','bands','filters','-v7.3');
profile=table(info.radial_frequency,info.radial_magnitude,info.smoothed_log_magnitude, ...
    'VariableNames',{'radial_frequency_radians','radial_magnitude','smoothed_log_magnitude'});
writetable(profile,fullfile(folder,'NEW_ewt_spectrum.csv'));
writetable(table(info.boundaries_radians(:),info.normalized_boundaries(:), ...
    'VariableNames',{'boundary_radians','boundary_normalized_to_corner_radius'}),fullfile(folder,'NEW_ewt_boundaries.csv'));
fig=figure('Visible',cfg.figures.visible,'Color','w','Position',[60 60 1350 600]);tiledlayout(2,cfg.ewt.bands);
for b=1:cfg.ewt.bands
    nexttile;imagesc(bands(:,:,b));axis image off;colorbar;title(sprintf('EWT coefficient band %d',b));
end
nexttile;plot(info.radial_frequency,info.smoothed_log_magnitude);hold on;
for boundary=info.boundaries_radians,xline(boundary,'--');end
xlabel('Radial angular frequency');ylabel('Smoothed log magnitude');grid on;
nexttile;imagesc(sum(filters.^2,3),[0 1]);axis image off;colorbar;title('Sum of squared filters');
sgtitle('Declared EWT reconstruction option; original paper settings unspecified');
nimeq.save_figure(fig,fullfile(folder,'NEW_ewt_decomposition'),cfg);
end
