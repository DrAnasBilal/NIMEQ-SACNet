function export_network_outputs(model,x,cfg,folder)
% A feature-space attention map is not an attribution map on retinal pixels.
nimeq.export_model_summary(model,folder);
D=nimeq.move(model.D,cfg.execution);h=model.h;s=cfg.sac;
X=dlarray(nimeq.move(reshape(single(x(:)).*single(h.mask(:)),s.gridSize,s.gridSize,1,1),cfg.execution),'SSCB');
[a,b,attention,capsules]=nimeq.sac_forward(D,X,h,cfg,model.K);
attention=nimeq.host(attention);capsules=nimeq.host(capsules);lengths=nimeq.host(a);realLogit=nimeq.host(b);
save(fullfile(folder,'NEW_feature_attention_and_capsules.mat'),'attention','capsules','lengths','realLogit','h');
fig=figure('Visible',cfg.figures.visible,'Color','w');imagesc(attention);colorbar;
xlabel('Query feature position');ylabel('Key feature position');title('Learned attention on SVD features; first held-out case');
nimeq.save_figure(fig,fullfile(folder,'NEW_feature_attention'),cfg);
rng(model.seed+700,'twister');K=model.K;
labels=eye(K,'single');noise=randn(1,1,s.noiseDimension,K,'single');
z=dlarray(nimeq.move(cat(3,noise,reshape(labels,1,1,K,K)),cfg.execution),'SSCB');
G=nimeq.move(model.G,cfg.execution);generated=nimeq.host(predict(G,z));
generated=generated.*reshape(single(h.mask),s.gridSize,s.gridSize,1,1);
save(fullfile(folder,'NEW_generated_feature_grids.mat'),'generated','labels');
fig=figure('Visible',cfg.figures.visible,'Color','w');tiledlayout(1,K);
for j=1:K,nexttile;imagesc(generated(:,:,1,j),[-1 1]);axis image;colorbar;title(sprintf('Condition %d',j));end
sgtitle('Generated SVD feature grids; these are not retinal images');
nimeq.save_figure(fig,fullfile(folder,'NEW_generator_feature_grids'),cfg);
end
