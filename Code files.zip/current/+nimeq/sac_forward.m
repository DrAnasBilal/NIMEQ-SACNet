function [lengths,realLogit,attention,capsules]=sac_forward(D,X,h,cfg,K)
% Differentiable conv, dot-product self attention and dynamic capsule routing.
s=cfg.sac;B=size(X,4);L=s.gridSize^2;C=s.channels;
H=leakyrelu(dlconv(X,D.convW,D.convB,'Padding','same'),.2);
H=reshape(permute(stripdims(H),[3 1 2 4]),C,L,B);
flat=reshape(H,C,[]);
Q=reshape(D.Q*flat,size(D.Q,1),L,B);
Key=reshape(D.K*flat,size(D.K,1),L,B);
Value=reshape(D.V*flat,C,L,B);
similarity=pagemtimes(permute(Key,[2 1 3]),Q);
E=exp(similarity-max(similarity,[],1));attention=E./sum(E,1);
context=pagemtimes(Value,attention);
H=H+h.alpha*context;
primary=reshape(D.primaryW*reshape(H,C*L,B)+D.primaryB,s.primaryDimension,s.primaryCapsules,B);
primary=nimeq.squash(primary,1);
votes=cell(1,s.primaryCapsules);
for j=1:s.primaryCapsules
    v=D.voteW(:,:,j)*reshape(primary(:,j,:),s.primaryDimension,B);
    votes{j}=reshape(v,s.classDimension,K,1,B);
end
U=cat(3,votes{:});
logits=dlarray(zeros(1,K,s.primaryCapsules,B,'like',extractdata(U)));
for routing=1:s.routingIterations
    E=exp(logits-max(logits,[],2));coupling=E./sum(E,2);
    capsules=nimeq.squash(sum(coupling.*U,3),1);
    if routing<s.routingIterations,logits=logits+sum(U.*capsules,1);end
end
lengths=reshape(sqrt(sum(capsules.^2,1)+1e-8),K,B);
realLogit=D.advW*reshape(capsules,s.classDimension*K,B)+D.advB;
end
