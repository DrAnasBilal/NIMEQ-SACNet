function h=hash_file(path,algorithm)
if nargin<2,algorithm='SHA-256';end
assert(usejava('jvm'),'nimeq:JVM','Run MATLAB with its JVM for evidence checksums.');
fid=fopen(path,'rb');assert(fid>=0,'nimeq:Read','Cannot open %s',path);
guard=onCleanup(@()fclose(fid)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance(algorithm);
while true
    x=fread(fid,1048576,'*uint8');if isempty(x),break;end
    md.update(typecast(x,'int8'));
end
h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
