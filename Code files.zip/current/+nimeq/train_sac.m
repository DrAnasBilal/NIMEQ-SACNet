function model=train_sac(X,y,K,h,cfg,folder,seed,epochs)
% Actual conditional adversarial/capsule training, with resumable Adam state.
if ~isfolder(folder),mkdir(folder);end
modelPath=fullfile(folder,'sac_model.mat');
if isfile(modelPath),d=load(modelPath,'model');model=d.model;return;end
checkpoint=fullfile(folder,'training_checkpoint.mat');
if isfile(checkpoint)
    d=load(checkpoint,'C');C=d.C;
    assert(C.seed==seed && isequal(C.h,h) && C.epochs==epochs,'nimeq:Checkpoint','Checkpoint configuration changed. Use a new experiment name.');
    D=nimeq.move(C.D,cfg.execution);G=nimeq.move(C.G,cfg.execution);
    md=nimeq.move(C.md,cfg.execution);vd=nimeq.move(C.vd,cfg.execution);
    mg=nimeq.move(C.mg,cfg.execution);vg=nimeq.move(C.vg,cfg.execution);
    sn=nimeq.move(C.sn,cfg.execution);history=C.history;iteration=C.iteration;first=C.epoch+1;rng(C.rng);
else
    rng(seed,'twister');[D,G]=nimeq.init_sac(K,cfg,seed);
    md=[];vd=[];mg=[];vg=[];sn=struct;iteration=0;first=1;
    history=zeros(epochs,5);
    if cfg.sac.spectralNormalization,[D,sn]=nimeq.spectral_project(D,sn);end
end
y=double(y(:).');N=size(X,2);s=cfg.sac;
assert(size(X,1)==s.gridSize^2 && N==numel(y),'nimeq:Dimensions','SAC feature/label dimensions do not agree.');
assert(all(y>=1 & y<=K & y==fix(y)),'nimeq:Labels','SAC labels must be indices 1..K.');
assert(any(h.mask) && numel(h.mask)==size(X,1),'nimeq:Mask','Invalid or empty feature selection.');
for epoch=first:epochs
    order=randperm(N);losses=zeros(1,3);correct=0;seen=0;
    for start=1:s.batchSize:N
        ix=order(start:min(start+s.batchSize-1,N));B=numel(ix);iteration=iteration+1;
        values=X(:,ix).*single(h.mask(:));
        xb=dlarray(nimeq.move(reshape(single(values),s.gridSize,s.gridSize,1,B),cfg.execution),'SSCB');
        labels=zeros(K,B,'single');labels(sub2ind([K B],y(ix),1:B))=1;
        tb=dlarray(nimeq.move(labels,cfg.execution));
        noise=randn(1,1,s.noiseDimension,B,'single');
        z=cat(3,noise,reshape(labels,1,1,K,B));zb=dlarray(nimeq.move(z,cfg.execution),'SSCB');
        [ld,gd,lm,ncorrect]=dlfeval(@nimeq.discriminator_loss,D,G,xb,tb,zb,h,cfg,K);
        assert(isfinite(nimeq.host(ld)),'nimeq:NonfiniteLoss','Nonfinite discriminator loss.');
        gd=dlupdate(@(g)max(-s.gradientLimit,min(s.gradientLimit,g)),gd);
        [D,md,vd]=adamupdate(D,gd,md,vd,iteration,s.learningRate,s.beta1,s.beta2);
        if s.spectralNormalization,[D,sn]=nimeq.spectral_project(D,sn);end
        [lg,gg,state]=dlfeval(@nimeq.generator_loss,G,D,zb,tb,h,cfg,K);
        assert(isfinite(nimeq.host(lg)),'nimeq:NonfiniteLoss','Nonfinite generator loss.');
        gg=dlupdate(@(g)max(-s.gradientLimit,min(s.gradientLimit,g)),gg);
        G.State=state;[G,mg,vg]=adamupdate(G,gg,mg,vg,iteration,s.learningRate,s.beta1,s.beta2);
        losses=losses+B*double([nimeq.host(ld),nimeq.host(lg),nimeq.host(lm)]);
        correct=correct+ncorrect;seen=seen+B;
    end
    history(epoch,:)=[epoch,losses/seen,100*correct/seen];
    C=struct('D',D,'G',G,'md',md,'vd',vd,'mg',mg,'vg',vg,'sn',sn,'history',history, ...
        'epoch',epoch,'iteration',iteration,'rng',rng,'seed',seed,'h',h,'epochs',epochs);
    C=nimeq.move(C,'cpu');
    temporary=[checkpoint '.tmp.mat'];save(temporary,'C','-v7.3');movefile(temporary,checkpoint,'f');
    if epoch==1 || mod(epoch,10)==0 || epoch==epochs
        fprintf('  SACNet epoch %d/%d | margin %.5f | training accuracy %.2f%%\n',epoch,epochs,history(epoch,4),history(epoch,5));
    end
end
model.D=nimeq.move(D,'cpu');model.G=nimeq.move(G,'cpu');model.h=h;model.K=K;
model.seed=seed;model.history=history;model.sacConfig=s;
model.status='New experiment trained from source images; not original publication output';
save(modelPath,'model','-v7.3');
H=array2table(history,'VariableNames',{'epoch','discriminator_loss','generator_loss','capsule_margin_loss','training_accuracy_pct'});
writetable(H,fullfile(folder,'training_history.csv'));
end
