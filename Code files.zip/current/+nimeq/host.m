function x=host(x)
if isa(x,'dlarray'),x=extractdata(x);end
if isa(x,'gpuArray'),x=gather(x);end
end
