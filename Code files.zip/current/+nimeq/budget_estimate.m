function B=budget_estimate(cfg)
trials=0;cnnFits=0;
for name=cfg.tasks(:).'
    if any(cfg.models~="SACNet"),cnnFits=cnnFits+cfg.search.folds+1;else,cnnFits=cnnFits+1;end
    for model=cfg.models(:).'
        if model=="SACNet",continue;end
        n=cfg.search.otherTrials;
        if model=="NIMEQ-SACNet"&&name==string(cfg.search.table4Task),n=cfg.search.table4Trials;end
        trials=trials+n;
    end
end
B=struct('profile',cfg.profile,'tasks',numel(cfg.tasks),'models',numel(cfg.models), ...
    'optimizer_trials',trials,'candidate_evaluations_upper_bound',trials*cfg.search.population*cfg.search.iterations, ...
    'inner_SAC_fits_upper_bound',trials*cfg.search.population*cfg.search.iterations*cfg.search.folds, ...
    'epochs_per_inner_fit',cfg.search.fitnessEpochs,'CNN_fits',cnnFits,'CNN_epochs_per_fit',cfg.cnn.epochs, ...
    'final_SAC_fits',numel(cfg.tasks)*numel(cfg.models),'epochs_per_final_fit',cfg.sac.epochs, ...
    'runtime_measured',false,'note','Fit-count upper bounds before cache reuse; no runtime or memory measurement.');
end
