function T=predict_files(bundleFile,input,outputCSV)
% Input is an image directory or a cell/string vector of image paths.
d=load(bundleFile,'bundle');b=d.bundle;cfg=b.cfg;
cfg.execution='auto';cfg.legacyBaselines=false;cfg=nimeq.preflight(cfg);
cnnFile=fullfile(fileparts(bundleFile),b.cnnRelativePath);
d=load(cnnFile,'net');net=d.net;
if isscalar(string(input)) && isfolder(input)
    imds=imageDatastore(input,'IncludeSubfolders',true);files=string(imds.Files);
else
    files=string(input(:));
end
assert(~isempty(files),'nimeq:Inference','No input images.');
N=numel(files);X=zeros(N,256,'single');lesions=zeros(N,10,'single');hashes=strings(N,1);E=[];
if cfg.ewt.enabled,E=zeros(N,5*cfg.ewt.bands-1,'single');end
for j=1:N
    S=nimeq.segment_fundus(imread(files(j)),cfg);
    I=im2single(im2uint8(imresize(S.preprocessed,cfg.imageSize)));
    R=imresize(S.red,cfg.imageSize,'nearest');B=imresize(S.bright,cfg.imageSize,'nearest');
    X(j,:)=nimeq.host(activations(net,I,'features','OutputAs','rows','ExecutionEnvironment',cfg.execution));
    lesions(j,:)=[nimeq.lesion_features(R),nimeq.lesion_features(B)];
    if cfg.ewt.enabled,E(j,:)=nimeq.ewt_features(I,cfg);end
    hashes(j)=string(nimeq.hash_file(files(j)));
end
X=nimeq.feature_matrix(X,lesions,E,cfg);
Z=nimeq.apply_svd(X,b.svdModel).';
[pred,scores,lengths]=nimeq.predict_sac(b.model,Z,cfg);
label=reshape(b.task.classes(pred),[],1);
T=table(files,hashes,pred(:),label,'VariableNames',{'image_path','sha256','predicted_label_index','predicted_label'});
for k=1:b.task.K
    T.(sprintf('normalized_capsule_score_%d',k))=scores(:,k);
    T.(sprintf('raw_capsule_length_%d',k))=lengths(:,k);
end
parent=fileparts(outputCSV);if ~isempty(parent)&&~isfolder(parent),mkdir(parent);end
writetable(T,outputCSV);
nimeq.write_json([outputCSV '.class_order.json'],struct('task',b.task,'scores_are_calibrated_probabilities',false));
end
