function download_dr7(cfg)
root=cfg.data.dr7Root;
if isfolder(root)
    q=dir(fullfile(root,'**','*.xlsx'));
    if ~isempty(q),return;end
end
assert(cfg.data.downloadDR7,'nimeq:DR7Missing','Extract DR7 version 0.2 to %s or enable downloadDR7.',root);
if ~isfolder(root),mkdir(root);end
url=['https://zenodo.org/api/records/' cfg.data.dr7Record];
record=webread(url,weboptions('Timeout',120));
file=record.files(1);
for j=1:numel(record.files)
    if endsWith(string(record.files(j).key),'.zip'),file=record.files(j);break;end
end
archive=fullfile(root,char(file.key));
if ~isfile(archive)
    fprintf('Downloading the cited DR7 record to %s\n',archive);
    websave(archive,char(file.links.self),weboptions('Timeout',1800));
end
expected=erase(string(file.checksum),'md5:');
actual=string(nimeq.hash_file(archive,'MD5'));
assert(strcmpi(expected,actual),'nimeq:Checksum','DR7 archive checksum mismatch. Remove the incomplete archive and download again.');
fprintf('Extracting DR7 version %s\n',cfg.data.dr7Record);
unzip(archive,root);
nimeq.write_json(fullfile(root,'download_provenance.json'),struct('record',url,'file',file.key,'md5',actual));
end
