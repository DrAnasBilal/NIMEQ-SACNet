function M=cache_images(M,cfg,root)
% Deterministic per-image operations contain no learned population statistics.
folder=fullfile(root,'image_cache');if ~isfolder(folder),mkdir(folder);end
M.pre_path=strings(height(M),1);M.red_path=M.pre_path;M.bright_path=M.pre_path;
native=zeros(height(M),10,'single');
for j=1:height(M)
    stem=char(M.dataset(j)+"_"+extractBetween(M.sha256(j),1,16));
    M.pre_path(j)=string(fullfile(folder,[stem '_pre.png']));
    M.red_path(j)=string(fullfile(folder,[stem '_red.png']));
    M.bright_path(j)=string(fullfile(folder,[stem '_bright.png']));
    metaPath=fullfile(folder,[stem '_meta.mat']);
    if isfile(metaPath) && isfile(M.pre_path(j)) && isfile(M.red_path(j)) && isfile(M.bright_path(j))
        d=load(metaPath,'nativeFeatures');native(j,:)=d.nativeFeatures;
    else
        S=nimeq.segment_fundus(imread(M.image_path(j)),cfg);
        imwrite(im2uint8(imresize(S.preprocessed,cfg.imageSize)),M.pre_path(j));
        imwrite(imresize(S.red,cfg.imageSize,'nearest'),M.red_path(j));
        imwrite(imresize(S.bright,cfg.imageSize,'nearest'),M.bright_path(j));
        nativeFeatures=S.nativeFeatures;native(j,:)=nativeFeatures; %#ok<NASGU>
        save(metaPath,'nativeFeatures');
    end
    if mod(j,25)==0 || j==height(M),fprintf('Preprocessing %d/%d source images\n',j,height(M));end
end
T=array2table(native,'VariableNames',{'red_count','red_mean_area','red_max_area','red_mean_perimeter','red_mean_solidity', ...
    'bright_count','bright_mean_area','bright_max_area','bright_mean_perimeter','bright_mean_solidity'});
writetable([M(:,{'dataset','sample_id'}),T],fullfile(root,'native_segmentation_features.csv'));
end
