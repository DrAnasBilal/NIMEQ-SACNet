function [loss,gradient,state]=generator_loss(G,D,Z,T,h,cfg,K)
[fake,state]=forward(G,Z);
mask=reshape(single(h.mask),cfg.sac.gridSize,cfg.sac.gridSize,1,1);
fake=fake.*nimeq.move(mask,cfg.execution);
[lengths,logit]=nimeq.sac_forward(D,fake,h,cfg,K);
loss=-h.chi*mean(logit,'all')+nimeq.capsule_loss(lengths,T,cfg);
gradient=dlgradient(loss,G.Learnables);
end
