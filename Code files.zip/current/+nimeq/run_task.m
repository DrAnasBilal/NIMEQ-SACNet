function summary=run_task(S,task,cfg,folder)
if ~isfolder(folder),mkdir(folder);end
writetable(S,fullfile(folder,'source_splits.csv'));nimeq.write_json(fullfile(folder,'task_definition.json'),task);
trainM=S(S.partition=="train",:);testM=S(S.partition=="test",:);
assert(~isempty(trainM)&&~isempty(testM),'nimeq:TaskSplit','Task needs nonempty train and test sets.');
membership=table;
for partition=["train","test"]
    D=S(S.partition==partition,:);label=reshape(task.map(D.grade+1),[],1)+1;
    for k=1:task.K
        r=table(partition,task.classes(k),sum(label==k),numel(unique(D.group_id(label==k))), ...
            'VariableNames',{'partition','class_label','source_records','distinct_groups'});
        if isempty(membership),membership=r;else,membership=[membership;r];end %#ok<AGROW>
    end
end
writetable(membership,fullfile(folder,'class_membership_counts.csv'));
selected=cell(numel(cfg.models),1);folds=cell(cfg.search.folds,1);
if any(cfg.models~="SACNet")
    for f=1:cfg.search.folds
        fit=trainM(trainM.inner_fold~=f,:);validation=trainM(trainM.inner_fold==f,:);
        assert(~isempty(validation),'nimeq:CV','Empty validation fold.');
        folds{f}=nimeq.prepare_fold(fit,validation,task,cfg,fullfile(folder,'inner_features',sprintf('fold_%02d',f)),cfg.seed+f);
    end
end
for v=1:numel(cfg.models)
    name=cfg.models(v);
    if name=="SACNet"
        selected{v}=struct('mask',true(1,cfg.features.svdRank),'alpha',cfg.search.baselineAlpha,'chi',cfg.search.baselineChi);
        continue;
    end
    trials=cfg.search.otherTrials;
    if name=="NIMEQ-SACNet" && task.name==string(cfg.search.table4Task),trials=cfg.search.table4Trials;end
    best=[];records=table;
    for trial=1:trials
        objective=@(h)nimeq.cv_fitness(h,folds,task,cfg,fullfile(folder,'candidate_fitness'));
        trialFolder=fullfile(folder,'optimization',char(name),sprintf('trial_%02d',trial));
        result=nimeq.optimize(char(name),objective,cfg,trialFolder,cfg.seed+10000+trial);
        if isempty(best)||result.fitness<best.fitness,best=result;end
        r=table(trial,result.seed,result.iteration,result.fitness,result.detail.cvError,sum(result.h.mask),result.h.alpha,result.h.chi, ...
            result.theta(1),result.theta(2),result.theta(3), ...
            'VariableNames',{'trial','seed','optimal_iteration','best_fitness','cv_error','selected_features','alpha','chi','theta_alpha','theta_beta','theta_delta'});
        if isempty(records),records=r;else,records=[records;r];end %#ok<AGROW>
        nimeq.plot_search(result,cfg,trialFolder);
        if name=="NIMEQ-SACNet",nimeq.export_qubits(result,trialFolder,trial);end
    end
    optFolder=fullfile(folder,'optimization',char(name));
    writetable(records,fullfile(optFolder,'all_trial_best_fitness.csv'));
    statistics=table(height(records),mean(records.best_fitness),std(records.best_fitness,0),min(records.best_fitness),max(records.best_fitness), ...
        'VariableNames',{'n_trials','arithmetic_mean_best_fitness','sample_std_best_fitness','min_best_fitness','max_best_fitness'});
    writetable(statistics,fullfile(optFolder,'fitness_statistics.csv'));
    if name=="NIMEQ-SACNet" && task.name==string(cfg.search.table4Task)
        writetable(records,fullfile(folder,'Table4_NEW_trials.csv'));
        writetable(statistics,fullfile(folder,'Table4_NEW_mean.csv'));
        save(fullfile(folder,'Table4_NEW_best_state.mat'),'best','records','statistics','-v7.3');
    end
    selected{v}=best.h;
    nimeq.write_json(fullfile(optFolder,'chosen_by_inner_CV.json'),struct('seed',best.seed,'fitness',best.fitness,'parameters',best.h));
end
% Selection is complete before the held-out images are passed to the final fit.
F=nimeq.prepare_fold(trainM,testM,task,cfg,fullfile(folder,'final_features'),cfg.seed+5000);
nimeq.plot_features(F,cfg,fullfile(folder,'final_features'));
R=struct([]);summary=table;classRows=table;
for v=1:numel(cfg.models)
    name=cfg.models(v);modelFolder=fullfile(folder,char(name));
    model=nimeq.train_sac(F.Xtr,F.ytr,task.K,selected{v},cfg,modelFolder,cfg.seed+20000,cfg.sac.epochs);
    [pred,scores,lengths]=nimeq.predict_sac(model,F.Xval,cfg);
    nimeq.export_predictions(testM,task,pred,scores,lengths,name,cfg.experimentName,0,'heldout_test',modelFolder);
    [perClass,overall,C]=nimeq.export_metrics(F.yval,pred,task,modelFolder);
    r=struct('model',char(name),'perClass',perClass,'overall',overall,'C',C, ...
        'truth',F.yval(:),'scores',scores,'history',model.history);
    if isempty(R),R=r;else,R(end+1)=r;end %#ok<AGROW>
    s=struct2table(overall);s.task=task.name;s.dataset=task.dataset;s.model=name;s.profile=string(cfg.profile);
    if isempty(summary),summary=s;else,summary=[summary;s];end %#ok<AGROW>
    p=perClass;p.task=repmat(task.name,height(p),1);p.model=repmat(name,height(p),1);
    if isempty(classRows),classRows=p;else,classRows=[classRows;p];end %#ok<AGROW>
    bundle=struct('task',task,'cfg',cfg,'model',model,'svdModel',F.svdModel, ...
        'cnnRelativePath',fullfile('..','final_features','cnn_feature_model.mat'), ...
        'outputMeaning','New model, not the original publication model');
    save(fullfile(modelFolder,'inference_bundle.mat'),'bundle','-v7.3');
    nimeq.export_network_outputs(model,F.Xval(:,1),cfg,modelFolder);
end
writetable(classRows,fullfile(folder,sprintf('Table%d_NEW_class_metrics.csv',task.table)));
writetable(summary,fullfile(folder,'NEW_overall_metrics.csv'));
save(fullfile(folder,'task_results.mat'),'R','summary','task','-v7.3');
nimeq.plot_task(R,task,cfg,folder);
nimeq.export_ensemble(R,testM,task,cfg,folder);
if cfg.legacyBaselines,nimeq.run_legacy(F,task,cfg,fullfile(folder,'legacy_classifiers'));end
end
