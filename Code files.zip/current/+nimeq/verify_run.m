function report=verify_run(runRoot,rehashSources,deepCV,throwOnFailure)
%VERIFY_RUN Independently rederive every reported final metric from case labels.
if nargin<2,rehashSources=false;end
if nargin<3,deepCV=false;end
if nargin<4,throwOnFailure=true;end
d=load(fullfile(runRoot,'configuration.mat'),'cfg');cfg=d.cfg;
S=nimeq.read_result_table(fullfile(runRoot,'source_splits.csv'));
checks=cell(0,4);needFigures=true;
if isfield(cfg,'verification')&&isfield(cfg.verification,'requireFigures'),needFigures=cfg.verification.requireFigures;end
for dataset=unique(S.dataset).'
    D=S(S.dataset==dataset,:);
    add('outer_split',dataset,isempty(intersect(D.group_id(D.partition=="train"),D.group_id(D.partition=="test"))), ...
        'Training and held-out groups must be disjoint.');
end
for name=cfg.tasks(:).'
    task=nimeq.task_info(name);folder=fullfile(runRoot,char(name));D=S(S.dataset==task.dataset,:);
    training=D(D.partition=="train",:);testing=D(D.partition=="test",:);
    try
        check_ancestry(fullfile(folder,'final_features','training_images','augmentation_ancestry.csv'),training,task,'final_augmentation');
    catch err,add('final_augmentation',name,false,err.message);end
    if any(cfg.models~="SACNet")
        for f=1:cfg.search.folds
            foldFolder=fullfile(folder,'inner_features',sprintf('fold_%02d',f));
            train=training(training.inner_fold~=f,:);val=training(training.inner_fold==f,:);
            try
                check_ancestry(fullfile(foldFolder,'training_images','augmentation_ancestry.csv'),train,task,sprintf('CV%d_augmentation',f));
                membership=nimeq.read_result_table(fullfile(foldFolder,'evaluation_source_membership.csv'));
                add('CV_validation_membership',name,isequal(sort(membership.sample_id),sort(val.sample_id)),sprintf('Fold %d original validation sources.',f));
                add('CV_group_isolation',name,isempty(intersect(train.group_id,val.group_id)),sprintf('Fold %d training/validation disjoint.',f));
            catch err,add('CV_membership',name,false,err.message);end
        end
    end
    for modelName=cfg.models(:).'
        out=fullfile(folder,char(modelName));scope=name+"/"+modelName;
        try
            P=nimeq.read_result_table(fullfile(out,'case_predictions.csv'));
            check_predictions(P,testing,task,scope,'heldout_test');
            add('model_metadata',scope,all(P.model==modelName & P.run==string(cfg.experimentName) & P.fold==0),'Recorded model, run and fold agree.');
            C=accumarray([P.true_label_index,P.predicted_label_index],1,[task.K task.K]);
[metrics,overall]=nimeq.metrics(C,task.classes);
            counts=nimeq.read_result_table(fullfile(out,'confusion_counts.csv'));
            add('integer_confusion_counts',scope,isequal(C,table2array(counts(:,2:end))) && isequal(string(counts.true_class),task.classes(:)), ...
                'Saved counts and true-class order agree with case predictions.');
            saved=nimeq.read_result_table(fullfile(out,'class_metrics.csv'));
            add('class_order',scope,isequal(string(saved.class_label),metrics.class_label),'All task classes retained in the specified order.');
            for variable=metrics.Properties.VariableNames(2:end)
                add("metric_"+string(variable{1}),scope,same_numbers(saved.(variable{1}),metrics.(variable{1})), ...
                    'Recomputed from integer case counts; undefined values remain undefined.');
            end
            savedOverall=nimeq.read_result_table(fullfile(out,'overall_metrics.csv'));
            for field=fieldnames(overall).'
                value=overall.(field{1});
                if isnumeric(value)
                    add("overall_"+string(field{1}),scope,same_numbers(savedOverall.(field{1}),value),'Overall metric recomputed from case counts.');
                end
            end
            if needFigures
                for figureName=["ROC","Training_history","NEW_feature_attention","NEW_generator_feature_grids"]
                    add('native_graphical_output',scope,isfile(fullfile(out,char(figureName+".fig")))&&isfile(fullfile(out,char(figureName+".png"))),figureName);
                end
            end
        catch err,add('final_result_read',scope,false,err.message);end
    end
    if needFigures
        for figureName=["Figure13_accuracy_heatmap","Figure14_metric_comparison","Figure15_metric_radar","Figure16_confusion_matrices"]
            add('task_graphical_output',name,isfile(fullfile(folder,char(figureName+".fig")))&&isfile(fullfile(folder,char(figureName+".png"))),figureName);
        end
    end
    if deepCV
        files=dir(fullfile(folder,'candidate_fitness','*','fitness.mat'));
        for j=1:numel(files)
            try
                d=load(fullfile(files(j).folder,files(j).name),'fitness','detail','h');wrong=0;n=0;
                for f=1:cfg.search.folds
                    P=nimeq.read_result_table(fullfile(files(j).folder,sprintf('fold_%02d',f),'case_predictions.csv'));
                    check_predictions(P,training(training.inner_fold==f,:),task,name+"/candidate_"+string(j),'cv_validation');
                    wrong=wrong+sum(P.true_label_index~=P.predicted_label_index);n=n+height(P);
                end
                expected=cfg.search.errorWeight*wrong/n+cfg.search.featureWeight*mean(d.h.mask);
                add('CV_fitness',name,same_numbers(d.fitness,expected)&&d.detail.wrong==wrong&&d.detail.n==n&&n==height(training), ...
                    sprintf('Candidate %d fitness and pooled validation counts.',j));
            catch err,add('CV_fitness',name,false,err.message);end
        end
    end
end
if rehashSources
    for j=1:height(S)
        try
            actual=string(nimeq.hash_file(S.image_path(j)));
            add('source_hash',S.dataset(j)+"/"+S.sample_id(j),actual==S.sha256(j),'Current source bytes equal recorded input.');
        catch err,add('source_hash',S.sample_id(j),false,err.message);end
    end
end
T=cell2table(checks,'VariableNames',{'check','scope','passed','detail'});
report=struct('passed',all(T.passed),'checks',height(T),'failed_checks',sum(~T.passed), ...
    'source_bytes_rehashed',logical(rehashSources),'deep_cv_checked',logical(deepCV), ...
    'native_figures_required',needFigures,'matlab',version,'release',version('-release'), ...
    'meaning','Numerical consistency and source membership checks on this new run; not proof of historical publication performance.');
parent=fullfile(runRoot,'verification');if ~isfolder(parent),mkdir(parent);end
folder=tempname(parent);mkdir(folder);
writetable(T,fullfile(folder,'verification_checks.csv'));nimeq.write_json(fullfile(folder,'verification_summary.json'),report);
report.reportFolder=folder;
fprintf('Result verification: %d checks, %d failures. %s\n',report.checks,report.failed_checks,folder);
if throwOnFailure,assert(report.passed,'nimeq:Verification','Result verification failed. Inspect %s before using the results.',folder);end

    function add(name,scope,passed,detail)
        checks(end+1,:)={string(name),string(scope),logical(passed),string(detail)};
    end

    function check_ancestry(path,allowed,task,scope)
        A=nimeq.read_result_table(path);[ok,index]=ismember(A.parent_sample_id,allowed.sample_id);
        assert(all(ok),'nimeq:Ancestry','Augmentation parent is outside this training partition.');
        expected=reshape(task.map(allowed.grade(index)+1),[],1)+1;
        add('augmentation_ancestry',task.name+"/"+string(scope),all(A.group_id==allowed.group_id(index))&&all(A.label_index==expected), ...
            'Every descendant retains its permitted source group and task label.');
    end

    function check_predictions(P,expected,task,scope,partition)
        actualKey=P.dataset+"/"+P.sample_id;expectedKey=expected.dataset+"/"+expected.sample_id;
        [ok,index]=ismember(actualKey,expectedKey);
        valid=all(ok)&&height(P)==height(expected)&&numel(unique(actualKey))==height(P);
        add('prediction_membership',scope,valid,'Each expected original evaluation source occurs exactly once.');
        assert(valid,'nimeq:PredictionMembership','Case membership differs from its evaluation partition.');
        y=reshape(task.map(expected.grade(index)+1),[],1)+1;
        add('ground_truth_join',scope,all(P.grade==expected.grade(index))&&all(P.true_label_index==y)&&all(P.sha256==expected.sha256(index))&&all(P.group_id==expected.group_id(index)), ...
            'Reported truth, native grade, hash and group match the saved source split.');
        add('partition_metadata',scope,all(P.partition==string(partition))&&all(P.task==task.name),'Prediction partition and task are explicit.');
        z=P.predicted_label_index;valid=all(isfinite(z)&z==fix(z)&z>=1&z<=task.K);
        add('prediction_labels',scope,valid,'Predicted indices are valid task classes.');
        assert(valid,'nimeq:PredictionLabels','Invalid predicted class indices.');
        add('label_names',scope,all(P.true_label==reshape(task.classes(y),[],1))&&all(P.predicted_label==reshape(task.classes(z),[],1)), ...
            'Human-readable labels agree with numeric indices.');
        scores=zeros(height(P),task.K);
        for k=1:task.K,scores(:,k)=P.(sprintf('normalized_capsule_score_%d',k));end
        [~,winner]=max(scores,[],2);
        add('capsule_scores',scope,all(isfinite(scores(:)))&&all(scores(:)>=0)&&all(abs(sum(scores,2)-1)<1e-5)&&all(winner==z), ...
            'Finite nonnegative normalized scores and argmax predictions agree.');
    end
end

function same=same_numbers(a,b)
if isnumeric(a),a=double(a);else,a=str2double(string(a));end
if isnumeric(b),b=double(b);else,b=str2double(string(b));end
same=isequal(size(a),size(b))&&all((isnan(a)&isnan(b)) | (isfinite(a)&isfinite(b)&abs(a-b)<=1e-8),'all');
end
