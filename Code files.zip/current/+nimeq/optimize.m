function result=optimize(method,objective,cfg,folder,seed)
% GWO, BGWO PUA2, and explicit normalized or literal quantum reconstruction.
if ~isfolder(folder),mkdir(folder);end
completed=fullfile(folder,'optimization_result.mat');
if isfile(completed),d=load(completed,'result');result=d.result;return;end
P=cfg.search.population;D=cfg.features.svdRank+2*cfg.search.hyperBits;I=cfg.search.iterations;
rs=RandStream('mt19937ar','Seed',seed);checkpoint=fullfile(folder,'search_checkpoint.mat');
if isfile(checkpoint)
    d=load(checkpoint,'state');state=d.state;rs.State=state.randomState;
    X=state.X;QA=state.QA;QB=state.QB;theta=state.theta;threshold=state.threshold;
    best=state.best;trace=state.trace;first=state.nextIteration;
else
    threshold=rand(rs,P,D);X=double(threshold<.5);
    if strcmp(method,'GWO-SACNet'),X=rand(rs,P,D);end
    if strcmpi(cfg.search.quantumMode,'literal'),q=.5;else,q=1/sqrt(2);end
    QA=ones(P,D,3)*q;QB=QA;theta=zeros(P,3);best=[];trace=zeros(0,10);first=1;
end
for it=first:I
    fits=zeros(P,1);details=cell(P,1);
    for w=1:P
        h=nimeq.decode_candidate(X(w,:),cfg);timer=tic;
        fprintf('%s iteration %d/%d wolf %d/%d | %d features, alpha %.3f, chi %.3f\n',method,it,I,w,P,sum(h.mask),h.alpha,h.chi);
        [fits(w),details{w}]=objective(h);
        assert(isfinite(fits(w)),'nimeq:Fitness','Objective returned a nonfinite fitness.');
        trace(end+1,:)=[it,w,fits(w),details{w}.cvError,sum(h.mask),h.alpha,h.chi,toc(timer),double(details{w}.cacheHit),seed]; %#ok<AGROW>
        if isempty(best) || fits(w)<best.fitness
            best=struct('fitness',fits(w),'h',h,'chromosome',X(w,:),'iteration',it,'detail',details{w}, ...
                'qubitA',QA(w,:,:),'qubitB',QB(w,:,:),'theta',theta(w,:),'measurement',threshold(w,:));
        end
    end
    [~,rank]=sort(fits);leaders=X(rank(1:3),:);a=2*(1-(it-1)/max(1,I-1));newX=zeros(P,D);
    for w=1:P
        moves=zeros(3,D);
        if strcmp(method,'NIMEQ-SACNet')
            measured=false(3,D);
            for l=1:3
                angle=rand(rs)*pi*rand(rs)*sum(leaders(l,:)-X(w,:))*2*pi;
                theta(w,l)=angle;
                aa=cos(angle)*QA(w,:,l)-sin(angle)*QB(w,:,l);
                bb=sin(angle)*QA(w,:,l)+cos(angle)*QB(w,:,l);
                if strcmpi(cfg.search.quantumMode,'normalized')
                    normq=sqrt(aa.^2+bb.^2);aa=aa./normq;bb=bb./normq;
                    measured(l,:)=rand(rs,1,D)<bb.^2;
                else
                    % Printed Eq 33/36 degeneracy is preserved in literal mode.
                    value=leaders(l,:).*bb.^2;measured(l,:)=value>=bb.^2;
                end
                QA(w,:,l)=aa;QB(w,:,l)=bb;
            end
            majority=sum(measured,1)>=2;
            threshold(w,:)=rand(rs,1,D);
            newX(w,:)=double(1./(1+exp(-double(majority)))>=threshold(w,:));
        else
            for l=1:3
                A=2*a*rand(rs,1,D)-a;C=2*rand(rs,1,D);dist=abs(C.*leaders(l,:)-X(w,:));
                if strcmp(method,'GWO-SACNet')
                    moves(l,:)=leaders(l,:)-A.*dist;
                elseif strcmp(method,'BGWO-SACNet')
                    step=1./(1+exp(-10*(A.*dist-.5)))>=rand(rs,1,D);
                    moves(l,:)=double((leaders(l,:)+step)>=1);
                else,error('nimeq:Optimizer','Unknown optimizer %s',method);
                end
            end
            if strcmp(method,'GWO-SACNet')
                newX(w,:)=mean(moves,1);
                if strcmpi(cfg.search.gwoUpdate,'literal'),newX(w,:)=(it+1)*newX(w,:);end
                newX(w,:)=min(1,max(0,newX(w,:)));
            else
                newX(w,:)=double(1./(1+exp(-10*(mean(moves,1)-.5)))>=rand(rs,1,D));
            end
        end
    end
    % Elitism retains the best measured solution and its associated state.
    X=newX;X(1,:)=best.chromosome;QA(1,:,:)=best.qubitA;QB(1,:,:)=best.qubitB;
    theta(1,:)=best.theta;threshold(1,:)=best.measurement;
    state=struct('X',X,'QA',QA,'QB',QB,'theta',theta,'threshold',threshold, ...
        'best',best,'trace',trace,'nextIteration',it+1,'randomState',rs.State);
    temporary=[checkpoint '.tmp.mat'];save(temporary,'state','-v7.3');movefile(temporary,checkpoint,'f');
    fprintf('%s iteration %d/%d | best CV fitness %.6f | %d selected\n',method,it,I,best.fitness,sum(best.h.mask));
    write_trace(trace,folder);
end
result=best;result.method=method;result.seed=seed;result.trace=trace;
result.quantumMode=cfg.search.quantumMode;result.gwoUpdate=cfg.search.gwoUpdate;
save(completed,'result','-v7.3');nimeq.write_json(fullfile(folder,'selected_parameters.json'),result.h);
end

function write_trace(trace,folder)
T=array2table(trace,'VariableNames',{'iteration','wolf','fitness','cv_error','selected_features','alpha','chi','seconds','cache_hit','seed'});
writetable(T,fullfile(folder,'search_trace.csv'));
end
