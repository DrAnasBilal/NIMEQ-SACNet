function [y,scores,lengths]=predict_sac(model,X,cfg)
D=nimeq.move(model.D,cfg.execution);N=size(X,2);K=model.K;s=cfg.sac;
lengths=zeros(N,K,'single');
for start=1:s.batchSize:N
    ix=start:min(start+s.batchSize-1,N);B=numel(ix);
    values=X(:,ix).*single(model.h.mask(:));
    xb=dlarray(nimeq.move(reshape(single(values),s.gridSize,s.gridSize,1,B),cfg.execution),'SSCB');
    L=nimeq.sac_forward(D,xb,model.h,cfg,K);
    lengths(ix,:)=nimeq.host(L).';
end
[~,y]=max(lengths,[],2);
scores=lengths./max(sum(lengths,2),1e-8);
end
