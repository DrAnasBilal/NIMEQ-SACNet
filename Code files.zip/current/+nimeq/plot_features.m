function plot_features(F,cfg,folder)
d=load(F.cnnModelPath,'net');
fig=figure('Visible',cfg.figures.visible,'Color','w','Position',[50 50 1000 1100]);plot(layerGraph(d.net));
title('Implemented CNN architecture');nimeq.save_figure(fig,fullfile(folder,'Figure9_implemented_CNN'),cfg);
s=F.svdModel.singularValues;variance=s.^2/max(sum(s.^2),eps);
fig=figure('Visible',cfg.figures.visible,'Color','w');tiledlayout(1,2);
nexttile;semilogy(1:numel(s),s,'-');xlabel('Component');ylabel('Training singular value');grid on;
nexttile;plot(cumsum(variance),'-');xline(F.svdModel.rank,'--');xlabel('Retained components');ylabel('Cumulative training variance');ylim([0 1]);grid on;
nimeq.save_figure(fig,fullfile(folder,'NEW_training_SVD'),cfg);
end
