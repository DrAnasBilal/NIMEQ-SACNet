function [perClass,overall,C]=export_metrics(truth,pred,task,folder)
truth=double(truth(:));pred=double(pred(:));K=task.K;
assert(numel(truth)==numel(pred) && ~isempty(truth),'nimeq:Metrics','Need matched nonempty true and predicted labels.');
assert(all(truth>=1 & truth<=K & truth==fix(truth)) && all(pred>=1 & pred<=K & pred==fix(pred)),'nimeq:Labels','Labels must belong to the complete class order.');
C=accumarray([truth,pred],1,[K K]);
[perClass,overall]=nimeq.metrics(C,task.classes);
names=cellstr("pred_"+string(1:K));counts=array2table(C,'VariableNames',names);
counts=addvars(counts,task.classes(:),'Before',1,'NewVariableNames','true_class');
if ~isfolder(folder),mkdir(folder);end
writetable(counts,fullfile(folder,'confusion_counts.csv'));
writetable(perClass,fullfile(folder,'class_metrics.csv'));
writetable(struct2table(overall),fullfile(folder,'overall_metrics.csv'));
save(fullfile(folder,'confusion_counts.mat'),'C','task','truth','pred');
end
