function [perClass, overall] = metrics(C, classLabels)
%NIMEQ_METRICS Recalculate metrics from authentic INTEGER confusion counts.
% Rows are true labels and columns are predicted labels. All _pct fields
% are percentages. This is new audit code, not original experiment software.

if ~isnumeric(C) || ~ismatrix(C) || size(C,1) ~= size(C,2) || ...
        size(C,1) < 2 || any(~isfinite(C(:))) || any(C(:) < 0) || ...
        any(C(:) ~= fix(C(:)))
    error('nimeq:InvalidCounts', 'C must be a finite square nonnegative integer matrix with at least two classes.');
end
C = double(C);
N = sum(C(:));
if N <= 0 || N > flintmax
    error('nimeq:InvalidCounts', 'Total count must be positive and exactly representable.');
end
classLabels = string(classLabels(:));
K = size(C,1);
if numel(classLabels) ~= K || any(ismissing(classLabels)) || ...
        any(strlength(strtrim(classLabels)) == 0) || numel(unique(classLabels)) ~= K
    error('nimeq:InvalidClasses', 'Supply one distinct nonempty label for each row and column of C.');
end

support = sum(C,2);
predicted = sum(C,1).';
TP = diag(C);
FN = support - TP;
FP = predicted - TP;
TN = N - TP - FN - FP;
sensitivity = safe_ratio(TP, TP+FN);
specificity = safe_ratio(TN, TN+FP);
precision = safe_ratio(TP, TP+FP);
% Count formula gives F1=0 when TP=0 and FP+FN>0, even if P is undefined.
f1 = safe_ratio(2*TP, 2*TP+FP+FN);
accuracy = (TP+TN)/N;
balancedError = 1 - (sensitivity+specificity)/2;
mccDen = sqrt((TP+FP).*(TP+FN).*(TN+FP).*(TN+FN));
mcc = safe_ratio(TP.*TN-FP.*FN, mccDen);

perClass = table(classLabels, support, TP, FN, FP, TN, ...
    100*sensitivity, 100*specificity, 100*precision, 100*f1, ...
    100*accuracy, 100*mcc, 100*balancedError, 100*(1-accuracy), ...
    'VariableNames', {'class_label','support','TP','FN','FP','TN', ...
    'sensitivity_pct','specificity_pct','precision_pct','f1_pct', ...
    'one_vs_rest_accuracy_pct','mcc_pct','balanced_error_pct', ...
    'ordinary_error_pct'});

overall = struct;
overall.n = N;
overall.overall_accuracy_pct = 100*trace(C)/N;
overall.ordinary_error_pct = 100-overall.overall_accuracy_pct;
overall.micro_f1_pct = overall.overall_accuracy_pct;
% Undefined components propagate to the macro mean rather than disappearing.
overall.macro_precision_pct = 100*mean(precision);
overall.macro_recall_pct = 100*mean(sensitivity);
overall.macro_f1_pct = 100*mean(f1);
overall.macro_specificity_pct = 100*mean(specificity);
overall.defined_precision_classes = sum(isfinite(precision));
overall.defined_recall_classes = sum(isfinite(sensitivity));
overall.defined_f1_classes = sum(isfinite(f1));
active = support > 0;
overall.support_weighted_f1_pct = 100*sum(support(active).*f1(active))/N;
den = sqrt((N^2-sum(predicted.^2))*(N^2-sum(support.^2)));
overall.multiclass_mcc = safe_ratio(trace(C)*N-sum(support.*predicted), den);
overall.macro_definition = 'Unweighted class mean; undefined components propagate as NaN.';
overall.weighted_definition = 'True-support weights; only zero-support classes excluded.';
overall.rows = 'True labels';
overall.columns = 'Predicted labels';
end

function z = safe_ratio(a,b)
z = nan(size(a));
ok = b ~= 0;
z(ok) = a(ok)./b(ok);
end
