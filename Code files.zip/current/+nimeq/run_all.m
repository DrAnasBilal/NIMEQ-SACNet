function runRoot=run_all(cfg)
%RUN_ALL Run real image experiments. Resume only an identical configuration.
cfg=nimeq.preflight(cfg);
runRoot=fullfile(cfg.outputRoot,cfg.experimentName);
if ~isfolder(runRoot),mkdir(runRoot);end
M=nimeq.prepare_manifest(cfg);
code=nimeq.code_inventory(cfg.projectRoot);
qualityRoot=fullfile(cfg.projectRoot,'data','quality_reports');quality=nimeq.output_inventory(qualityRoot);
signature=nimeq.hash_text(jsonencode(struct('cfg',cfg,'data',M,'code',code,'quality',quality)));
identityPath=fullfile(runRoot,'run_identity.json');
if isfile(identityPath)
    previous=jsondecode(fileread(identityPath));
    assert(strcmp(previous.signature,signature),'nimeq:ChangedRun', ...
        'Code, data or configuration changed. Choose a new cfg.experimentName to preserve the old run.');
else
    nimeq.write_json(identityPath,struct('signature',signature,'created_utc',utc_now(), ...
        'meaning','New reconstruction experiment, not recovered original publication records'));
end
nimeq.write_json(fullfile(runRoot,'configuration.json'),cfg);
save(fullfile(runRoot,'configuration.mat'),'cfg'); % Preserves Inf exactly (JSON uses null).
qualityOut=fullfile(runRoot,'input_quality');if ~isfolder(qualityOut),mkdir(qualityOut);end
qualityFiles=dir(fullfile(qualityRoot,'*'));qualityFiles=qualityFiles(~[qualityFiles.isdir]);
for j=1:numel(qualityFiles),copyfile(fullfile(qualityFiles(j).folder,qualityFiles(j).name),qualityOut,'f');end
writetable(M,fullfile(runRoot,'source_manifest.csv'));
writetable(code,fullfile(runRoot,'authored_code_sha256.csv'));
writetable(nimeq.paper_coverage(),fullfile(runRoot,'paper_method_coverage.csv'));
nimeq.write_json(fullfile(runRoot,'computation_budget.json'),nimeq.budget_estimate(cfg));
software=struct('matlab',version,'release',version('-release'),'computer',computer, ...
    'toolboxes',ver,'execution',cfg.execution,'started_utc',utc_now());
nimeq.write_json(fullfile(runRoot,'software.json'),software);
diary(fullfile(runRoot,'console.log'));cleanup=onCleanup(@()diary('off')); %#ok<NASGU>
try
    nimeq.write_json(fullfile(runRoot,'status.json'),struct('status','running','time_utc',utc_now()));
    M=nimeq.cache_images(M,cfg,fullfile(runRoot,'image_cache'));
    writetable(M,fullfile(runRoot,'processed_manifest.csv'));
    S=M([],:);S.partition=strings(0,1);S.inner_fold=zeros(0,1);
    for dataset=unique(M.dataset).'
        q=nimeq.make_splits(M(M.dataset==dataset,:),cfg);S=[S;q]; %#ok<AGROW>
    end
    writetable(S,fullfile(runRoot,'source_splits.csv'));
    nimeq.export_examples(S(S.partition=="train",:),cfg,fullfile(runRoot,'examples'));
    nimeq.export_method_graph(cfg,fullfile(runRoot,'examples'));
    summary=table;
    for name=cfg.tasks(:).'
        task=nimeq.task_info(name);D=S(S.dataset==task.dataset,:);
        result=nimeq.run_task(D,task,cfg,fullfile(runRoot,char(name)));
        if isempty(summary),summary=result;else,summary=[summary;result];end %#ok<AGROW>
        writetable(summary,fullfile(runRoot,'Table11_NEW_experiment_summary.csv'));
    end
    nimeq.compare_published(runRoot,cfg);
    nimeq.verify_run(runRoot,cfg.verification.rehashSources,cfg.verification.deepCV,true);
    nimeq.write_json(fullfile(runRoot,'status.json'),struct('status','completed','time_utc',utc_now(), ...
        'warning','All outputs are new measurements. They do not establish the original publication results.'));
    outputs=nimeq.output_inventory(runRoot);
    writetable(outputs,fullfile(runRoot,'output_sha256.csv'));
    fprintf('\nCompleted. Results, individual predictions and native figures: %s\n',runRoot);
catch err
    nimeq.write_json(fullfile(runRoot,'status.json'),struct('status','failed','time_utc',utc_now(), ...
        'identifier',err.identifier,'message',err.message,'stack',err.stack));
    rethrow(err);
end
end

function s=utc_now()
s=char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss''Z'''));
end
