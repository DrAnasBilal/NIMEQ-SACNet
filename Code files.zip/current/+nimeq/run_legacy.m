function run_legacy(F,task,cfg,folder)
% Optional held-out SVM/KNN/tree/voting comparisons from the supplied approach.
if ~isfolder(folder),mkdir(folder);end
branches={'red','bright','fused'};columns={1:5,6:10,1:10};summary=table;thresholdSummary=table;
for b=1:3
    X=double(F.lesionTrain(:,columns{b}));Q=double(F.lesionVal(:,columns{b}));y=F.ytr(:);truth=F.yval(:);
    svm=fitcecoc(X,y,'Learners',templateSVM('KernelFunction','gaussian','Standardize',true));
    knn=fitcknn(X,y,'NumNeighbors',3,'Standardize',true);tree=fitctree(X,y);
    V=[predict(svm,Q),predict(knn,Q),predict(tree,Q)];V(:,4)=mode(V,2);names=["SVM_RBF","KNN","Tree","Voting"];
    raw=F.valRecords(:,{'dataset','sample_id','grade','group_id'});raw.true_label_index=truth;
    for j=1:4
        raw.(char(names(j)))=V(:,j);
        out=fullfile(folder,[branches{b} '_' char(names(j))]);
        [~,o]=nimeq.export_metrics(truth,V(:,j),task,out);
        s=table(string(branches{b}),names(j),o.overall_accuracy_pct,o.macro_f1_pct,'VariableNames',{'features','classifier','overall_accuracy_pct','macro_f1_pct'});
        if isempty(summary),summary=s;else,summary=[summary;s];end %#ok<AGROW>
        for threshold=1:task.K-1
            a=double(truth>=threshold+1)+1;c=double(V(:,j)>=threshold+1)+1;
            [pm,~]=nimeq.metrics(accumarray([a c],1,[2 2]),["Below threshold","At or above threshold"]);
            z=pm(2,:);z.features=string(branches{b});z.classifier=names(j);z.severity_threshold=threshold;
            if isempty(thresholdSummary),thresholdSummary=z;else,thresholdSummary=[thresholdSummary;z];end %#ok<AGROW>
        end
    end
    writetable(raw,fullfile(folder,[branches{b} '_heldout_predictions.csv']));
    save(fullfile(folder,[branches{b} '_classifiers.mat']),'svm','knn','tree','task','-v7.3');
end
writetable(summary,fullfile(folder,'legacy_heldout_summary.csv'));
writetable(thresholdSummary,fullfile(folder,'legacy_threshold_metrics.csv'));
fig=figure('Visible',cfg.figures.visible,'Color','w');hold on;
for name=["SVM_RBF","KNN","Tree","Voting"]
    rows=thresholdSummary.features=="fused" & thresholdSummary.classifier==name;
    plot(thresholdSummary.severity_threshold(rows),thresholdSummary.f1_pct(rows),'-o','DisplayName',char(name));
end
xlabel('Native task severity threshold');ylabel('Held-out F1 percent');ylim([0 100]);grid on;legend('Location','best');
nimeq.save_figure(fig,fullfile(folder,'NEW_legacy_F1_curves'),cfg);
end
