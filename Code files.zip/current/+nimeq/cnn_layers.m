function layers=cnn_layers(cfg,K)
% Figure 9: filters 16 32 64, dense 1024 512 256, BN and max pooling.
% 224 input with valid 3x3 convolutions yields 26x26x64 before flattening.
layers=[imageInputLayer([cfg.imageSize 3],'Normalization','none','Name','input')
    convolution2dLayer(3,16,'Padding',0,'Name','conv1')
    batchNormalizationLayer('Name','bn1');reluLayer('Name','relu1');maxPooling2dLayer(2,'Stride',2,'Name','pool1')
    convolution2dLayer(3,32,'Padding',0,'Name','conv2')
    batchNormalizationLayer('Name','bn2');reluLayer('Name','relu2');maxPooling2dLayer(2,'Stride',2,'Name','pool2')
    convolution2dLayer(3,64,'Padding',0,'Name','conv3')
    batchNormalizationLayer('Name','bn3');reluLayer('Name','relu3');maxPooling2dLayer(2,'Stride',2,'Name','pool3')
    fullyConnectedLayer(1024,'Name','dense1024');batchNormalizationLayer('Name','bn1024');reluLayer('Name','relu1024');dropoutLayer(cfg.cnn.dropout,'Name','drop1024')
    fullyConnectedLayer(512,'Name','dense512');batchNormalizationLayer('Name','bn512');reluLayer('Name','relu512');dropoutLayer(cfg.cnn.dropout,'Name','drop512')
    fullyConnectedLayer(256,'Name','features');reluLayer('Name','feature_relu')
    fullyConnectedLayer(K,'Name','class_head');softmaxLayer('Name','probabilities');classificationLayer('Name','crossentropy')];
end
