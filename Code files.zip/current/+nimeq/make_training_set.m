function A=make_training_set(M,task,cfg,folder,seed)
% Only source images already assigned to this training fold may be augmented.
if ~isfolder(folder),mkdir(folder);end
rs=RandStream('mt19937ar','Seed',seed);bank=nimeq.augmentation_bank();
y=reshape(task.map(M.grade+1),[],1)+1;
counts=accumarray(y,1,[task.K 1]);target=round(max(counts)*cfg.augmentation.targetMultiplier);
paths=strings(0,1);parents=strings(0,1);groups=strings(0,1);labels=[];ops=strings(0,1);features=zeros(0,10,'single');
for c=1:task.K
    src=find(y==c);
    if isempty(src),continue;end
    nnew=0;
    if cfg.augmentation.balance,nnew=max(0,target-numel(src));end
    if isfinite(cfg.augmentation.maxPerOriginal),nnew=min(nnew,cfg.augmentation.maxPerOriginal*numel(src));end
    choices=[src;src(randi(rs,numel(src),nnew,1))];
    for k=1:numel(choices)
        j=choices(k);I=imread(M.pre_path(j));R=imread(M.red_path(j))>0;B=imread(M.bright_path(j))>0;
        if k<=numel(src)
            operation="identity";path=M.pre_path(j);
        else
            b=randi(rs,height(bank));
            [I,R,B,operation]=nimeq.augment_image(I,R,B,bank.kind(b),bank.level(b));
            path=string(fullfile(folder,sprintf('aug_%07d.png',numel(paths)+1)));
            imwrite(im2uint8(I),path);
        end
        paths(end+1,1)=path;parents(end+1,1)=M.sample_id(j);groups(end+1,1)=M.group_id(j); %#ok<AGROW>
        labels(end+1,1)=c;ops(end+1,1)=operation; %#ok<AGROW>
        features(end+1,:)=[nimeq.lesion_features(R),nimeq.lesion_features(B)]; %#ok<AGROW>
    end
end
A=table(paths,parents,groups,labels,ops,'VariableNames',{'image_path','parent_sample_id','group_id','label_index','operation'});
A.lesion_features=features;
writetable(removevars(A,'lesion_features'),fullfile(folder,'augmentation_ancestry.csv'));
end
