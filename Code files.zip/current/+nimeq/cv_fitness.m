function [fitness,detail]=cv_fitness(h,folds,task,cfg,root)
% Every objective is based on actual validation predictions, never test data.
key=nimeq.hash_text(jsonencode(h));folder=fullfile(root,key);
file=fullfile(folder,'fitness.mat');
if isfile(file)
    d=load(file,'fitness','detail');fitness=d.fitness;detail=d.detail;detail.cacheHit=true;return;
end
if ~isfolder(folder),mkdir(folder);end
wrong=0;total=0;rows=zeros(numel(folds),3);
for j=1:numel(folds)
    F=folds{j};fitFolder=fullfile(folder,sprintf('fold_%02d',j));
    model=nimeq.train_sac(F.Xtr,F.ytr,task.K,h,cfg,fitFolder,cfg.seed+1000+j,cfg.search.fitnessEpochs);
    [pred,score,lengths]=nimeq.predict_sac(model,F.Xval,cfg);
    errors=sum(pred(:)~=F.yval(:));n=numel(pred);wrong=wrong+errors;total=total+n;
    rows(j,:)=[j,n,errors];
    nimeq.export_predictions(F.valRecords,task,pred,score,lengths,'CV_candidate',key,j,'cv_validation',fitFolder);
end
cvError=wrong/total;
fitness=cfg.search.errorWeight*cvError+cfg.search.featureWeight*mean(h.mask);
detail=struct('cvError',cvError,'wrong',wrong,'n',total,'selectedFeatures',sum(h.mask), ...
    'featureFraction',mean(h.mask),'alpha',h.alpha,'chi',h.chi,'cacheHit',false, ...
    'aggregation','Error pooled across disjoint inner validation folds; no test predictions used');
save(file,'fitness','detail','h');
writetable(array2table(rows,'VariableNames',{'fold','n','wrong'}),fullfile(folder,'fold_error_counts.csv'));
nimeq.write_json(fullfile(folder,'fitness.json'),detail);
end
