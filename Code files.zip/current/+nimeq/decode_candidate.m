function h=decode_candidate(x,cfg)
n=cfg.features.svdRank;b=cfg.search.hyperBits;
assert(numel(x)==n+2*b,'nimeq:Chromosome','Chromosome length does not match feature and hyperparameter bits.');
x=double(x(:).');bits=x>=.5;
h.mask=bits(1:n);
if ~any(h.mask),[~,j]=max(x(1:n));h.mask(j)=true;end
weights=2.^(0:b-1);a=sum(bits(n+(1:b)).*weights)/(2^b-1);
c=sum(bits(n+b+(1:b)).*weights)/(2^b-1);
h.alpha=cfg.search.alphaRange(1)+a*diff(cfg.search.alphaRange);
h.chi=cfg.search.chiRange(1)+c*diff(cfg.search.chiRange);
end
