function [Z,F]=fit_svd(X,cfg)
% Training observations only. Rows are observations and columns are features.
assert(ismatrix(X) && all(isfinite(X(:))),'nimeq:Features','Feature matrix must be finite.');
F.mean=mean(double(X),1);F.std=std(double(X),0,1);F.std(F.std<1e-8)=1;
Q=(double(X)-F.mean)./F.std;
[~,S,V]=svd(Q,'econ');
F.rank=min([cfg.features.svdRank,size(V,2),size(Q,1)-1]);
assert(F.rank>=1,'nimeq:SVD','Need at least two training observations.');
F.V=V(:,1:F.rank);F.singularValues=diag(S);F.outputDimension=cfg.features.svdRank;
scores=Q*F.V;F.scoreStd=std(scores,0,1);F.scoreStd(F.scoreStd<1e-8)=1;
F.scoreScale=cfg.features.scoreScale;
Z=nimeq.apply_svd(X,F);
end
