function S=segment_fundus(I,cfg)
% Adapted from the supplied DR_feats_fcn and starter scripts.
% Native-resolution segmentation precedes resizing. No figures during fitting.
if size(I,3)==1,I=repmat(I,1,1,3);end
I=im2uint8(I(:,:,1:3));
ycc=rgb2ycbcr(I);
ycc(:,:,1)=medfilt2(imadjust(adapthisteq(ycc(:,:,1))),cfg.seg.medianSize);
Ipre=im2double(ycbcr2rgb(ycc));
fundus=rescale(im2double(rgb2gray(I)))>cfg.seg.backgroundThreshold;
Ipre=Ipre.*fundus;
redParts=false(size(Ipre));brightParts=false(size(Ipre));
for c=1:3
    % Adaptive imbinarize is applied separately to each 2-D color channel.
    redParts(:,:,c)=imbinarize(Ipre(:,:,c),'adaptive','ForegroundPolarity','dark','Sensitivity',cfg.seg.redSensitivity);
    brightParts(:,:,c)=imbinarize(Ipre(:,:,c),'adaptive','ForegroundPolarity',cfg.seg.brightPolarity,'Sensitivity',cfg.seg.brightSensitivity);
end
rawRed=~(sum(redParts,3)>=2);
red=imclearborder(imclose(rawRed,strel('disk',cfg.seg.redClose(1),0)));
red=bwareafilt(imclose(red,strel('disk',cfg.seg.redClose(2),0)),[cfg.seg.minArea Inf]);
L=bwlabel(red);p=regionprops(L,'Extent','MinorAxisLength','MajorAxisLength');
keep=false(numel(p),1);
for j=1:numel(p)
    keep(j)=p(j).Extent>cfg.seg.minExtent && p(j).MajorAxisLength>0 && ...
        p(j).MinorAxisLength/p(j).MajorAxisLength>cfg.seg.minAspect;
end
red=ismember(L,find(keep));
rawBright=sum(brightParts,3)>=2;
bright=rawBright & rgb2gray(Ipre)>cfg.seg.brightThreshold;
bright=bwareafilt(imclearborder(imclose(bright,strel('disk',cfg.seg.brightClose,0))),[cfg.seg.minArea Inf]);
S.original=I;S.preprocessed=Ipre;S.red=red;S.bright=bright;
S.rawRed=rawRed;S.rawBright=rawBright;
S.nativeFeatures=[nimeq.lesion_features(red),nimeq.lesion_features(bright)];
end
