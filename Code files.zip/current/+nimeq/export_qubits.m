function export_qubits(result,folder,trial)
% All coordinates of the best recorded NIMEQ state, not invented scalar qubits.
roles=["alpha","beta","delta"];D=numel(result.chromosome);values=zeros(3*D,8);leader=strings(3*D,1);
for l=1:3
    for j=1:D
        r=(l-1)*D+j;a=result.qubitA(1,j,l);b=result.qubitB(1,j,l);
        values(r,:)=[trial,j,a,b,a*a+b*b,b*b,result.measurement(j),result.chromosome(j)];leader(r)=roles(l);
    end
end
T=array2table(values,'VariableNames',{'trial','coordinate','amplitude_zero','amplitude_one','state_norm_squared', ...
    'amplitude_one_squared','final_sigmoid_threshold','chromosome_value'});
T.leader_rotation_role=leader;T.quantum_mode=repmat(string(result.quantumMode),height(T),1);
writetable(T,fullfile(folder,'best_qubit_coordinates.csv'));
end
