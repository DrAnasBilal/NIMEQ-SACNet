function T = read_csv_text(path)
% Read input CSVs with explicit first-row column names.
opts = detectImportOptions(path, ...
    'FileType', 'text', ...
    'Delimiter', ',', ...
    'VariableNamesLine', 1, ...
    'TextType', 'string', ...
    'VariableNamingRule', 'preserve');

opts.DataLines = [2 Inf];
opts.VariableUnitsLine = 0;
opts.VariableDescriptionsLine = 0;
opts.RowNamesColumn = 0;

% Preserve IDs, leading zeros and hashes as text.
opts = setvartype(opts, opts.VariableNames, 'string');
T = readtable(path, opts);

for j = 1:width(T)
    name = T.Properties.VariableNames{j};
    values = string(T.(name));
    values(ismissing(values)) = "";
    T.(name) = values;
end
end