function [X,names]=feature_matrix(cnn,lesions,ewt,cfg)
% One shared feature contract for training, held-out evaluation and inference.
assert(size(cnn,2)==256&&size(lesions,2)==10&&size(cnn,1)==size(lesions,1),'nimeq:FeatureSchema','CNN and lesion feature dimensions do not match.');
X=single(nimeq.host(cnn));names="cnn_"+compose('%03d',1:256);
if cfg.features.includeLesionDescriptors
    X=[X,single(lesions)];
    lesionNames=["count","mean_area","max_area","mean_perimeter","mean_solidity"];
    names=[names,"red_"+lesionNames,"bright_"+lesionNames];
end
if isfield(cfg,'ewt')&&cfg.ewt.enabled
    N=cfg.ewt.bands;
    assert(size(ewt,1)==size(cnn,1)&&size(ewt,2)==5*N-1,'nimeq:EWTFeatures','EWT feature dimensions do not match.');
    X=[X,single(ewt)];
    for b=1:N
        names=[names,"ewt_band"+string(b)+"_"+["energy_fraction","mean_abs","std","entropy"]]; %#ok<AGROW>
    end
    names=[names,"ewt_boundary_"+string(1:N-1)];
end
assert(all(isfinite(X(:))),'nimeq:Features','Raw features must be finite.');
end
