function Z=apply_svd(X,F)
Q=(double(X)-F.mean)./F.std;
scores=(Q*F.V)./F.scoreStd;
Z=zeros(size(X,1),F.outputDimension,'single');
Z(:,1:F.rank)=single(tanh(scores/F.scoreScale));
end
