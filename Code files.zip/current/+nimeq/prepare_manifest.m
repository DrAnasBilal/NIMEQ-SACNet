function M=prepare_manifest(cfg)
% Source-level membership is fixed before augmentation, fitting or tuning.
needID=any(startsWith(cfg.tasks,'IDRiD'));needDR=any(startsWith(cfg.tasks,'DR7'));
if strlength(string(cfg.data.manifestCSV))>0
    M=nimeq.read_csv_text(cfg.data.manifestCSV);
    required={'dataset','sample_id','image_path','grade'};
    assert(all(ismember(required,M.Properties.VariableNames)),'nimeq:Manifest','Explicit manifest needs dataset,sample_id,image_path,grade.');
    M.grade=str2double(M.grade);
    if ~ismember('source_split',M.Properties.VariableNames),M.source_split=repmat("unspecified",height(M),1);end
    if ~ismember('patient_id',M.Properties.VariableNames),M.patient_id=strings(height(M),1);end
    parent=fileparts(cfg.data.manifestCSV);
    for j=1:height(M)
        if ~isfile(M.image_path(j)),M.image_path(j)=string(fullfile(parent,M.image_path(j)));end
    end
else
    M=table('Size',[0 6],'VariableTypes',{'string','string','string','double','string','string'}, ...
        'VariableNames',{'dataset','sample_id','image_path','grade','source_split','patient_id'});
    if needID,M=[M;read_idrid(cfg.data.idridRoot)];end %#ok<AGROW>
    if needDR,nimeq.download_dr7(cfg);M=[M;read_dr7(cfg)];end %#ok<AGROW>
end
M=M((M.dataset=="IDRiD" & needID) | (M.dataset=="DR7" & needDR),:);
assert(height(M)>0,'nimeq:NoImages','No requested source images were found.');
assert(all(~ismissing(M.sample_id) & strlength(strtrim(M.sample_id))>0),'nimeq:SampleIDs','Every source needs a nonempty sample_id.');
assert(numel(unique(M.dataset+"/"+M.sample_id))==height(M),'nimeq:DuplicateID','Source sample IDs must be unique within a dataset.');
assert(all(isfinite(M.grade) & M.grade==fix(M.grade) & M.grade>=0),'nimeq:Grades','Grades must be explicit nonnegative integers.');
assert(all(M.grade(M.dataset=="IDRiD")<=4) && all(M.grade(M.dataset=="DR7")<=6),'nimeq:Grades','Expected IDRiD grades 0..4 and DR7 grades 0..6.');
if strlength(string(cfg.data.patientCSV))>0
    P=nimeq.read_csv_text(cfg.data.patientCSV);
    assert(all(ismember({'dataset','sample_id','patient_id'},P.Properties.VariableNames)),'nimeq:Patients','Patient CSV columns are dataset,sample_id,patient_id.');
    keys=P.dataset+"/"+P.sample_id;
    assert(numel(unique(keys))==numel(keys),'nimeq:Patients','Patient CSV repeats image IDs.');
    [ok,loc]=ismember(M.dataset+"/"+M.sample_id,keys);
    M.patient_id(ok)=P.patient_id(loc(ok));
end
M.sha256=strings(height(M),1);
for j=1:height(M)
    assert(isfile(M.image_path(j)),'nimeq:MissingImage','Missing %s',M.image_path(j));
    file=java.io.File(char(M.image_path(j)));M.image_path(j)=string(char(file.getCanonicalPath()));
    M.sha256(j)=string(nimeq.hash_file(M.image_path(j)));
    if mod(j,50)==0 || j==height(M),fprintf('Hashing source files %d/%d\n',j,height(M));end
end
% Only byte-identical images with conflicting grades are label conflicts.
bad=false(height(M),1);
[hashGroup,~]=findgroups(M.dataset+"/"+M.sha256);
for g=1:max(hashGroup)
    rows=hashGroup==g;
    if numel(unique(M.grade(rows)))>1,bad(rows)=true;end
end
reportRoot=fullfile(cfg.projectRoot,'data','quality_reports');
if ~isfolder(reportRoot),mkdir(reportRoot);end
writetable(M(bad,:),fullfile(reportRoot,'conflicting_identical_image_labels.csv'));
if any(bad)
    if strcmpi(cfg.data.conflictingDuplicatePolicy,'error')
        error('nimeq:ConflictingLabels','Identical image bytes have conflicting grades. Inspect data/quality_reports.');
    end
    assert(strcmpi(cfg.data.conflictingDuplicatePolicy,'exclude'),'nimeq:Policy','Use exclude or error for conflicting duplicates.');
    warning('nimeq:ConflictingLabels','Quarantining %d records with conflicting labels for identical image bytes.',sum(bad));
    M=M(~bad,:);
end
% Connected components join both known patients and exact duplicate images.
assert(height(M)>0,'nimeq:NoAcceptedImages','No images remain after label-conflict quarantine.');
n=height(M);edges1=[];edges2=[];
for field={'sha256','patient_id'}
    value=M.(field{1});valid=strlength(strtrim(value))>0;
    [~,~,groups]=unique(M.dataset+"/"+value);
    for g=unique(groups(valid)).'
        idx=find(groups==g & valid);
        if numel(idx)>1,edges1=[edges1;repmat(idx(1),numel(idx)-1,1)];edges2=[edges2;idx(2:end)];end %#ok<AGROW>
    end
end
G=graph(edges1,edges2,[],n);component=conncomp(G).';
M.group_id="group_"+compose('%06d',component);
M=sortrows(M,{'dataset','sample_id'});
writetable(M,fullfile(reportRoot,'accepted_manifest.csv'));
nimeq.write_json(fullfile(reportRoot,'membership_summary.json'),struct( ...
    'accepted_images',height(M),'excluded_conflicting_records',sum(bad), ...
    'known_patient_records',sum(strlength(M.patient_id)>0), ...
    'limitation','Empty patient IDs permit exact-duplicate grouping only, not a claim of patient independence.'));
end

function M=read_idrid(root)
assert(isfolder(root),'nimeq:IDRiDMissing',['Download the official IDRiD Disease Grading images and both label CSVs from ' ...
 'https://ieee-dataport.org/open-access/indian-diabetic-retinopathy-image-dataset-idrid and extract to %s. Authentication may be required.'],root);
csvs=dir(fullfile(root,'**','*.csv'));images=image_files(root);
rows=cell(0,6);
for split=["training","testing"]
    selected=find(contains(lower(string({csvs.name})),split));
    selected=selected(contains(lower(string({csvs(selected).name})),'label'));
    assert(numel(selected)==1,'nimeq:IDRiDLabels','Need one %s grading label CSV under %s.',split,root);
    path=fullfile(csvs(selected).folder,csvs(selected).name);
    T=nimeq.read_csv_text(path);names=lower(string(T.Properties.VariableNames));
    ci=find(contains(names,'image'),1);cg=find(contains(names,'retinopathy'),1);
    assert(~isempty(ci)&&~isempty(cg),'nimeq:IDRiDColumns','Expected Image name and Retinopathy grade columns.');
    for j=1:height(T)
        stem=lower(regexprep(strtrim(T{j,ci}),'\.(jpg|jpeg|png)$',''));
        hit=find(images.stem==stem);
        if numel(hit)>1
            hit=hit(contains(lower(images.path(hit)),split));
        end
        assert(numel(hit)==1,'nimeq:ImageJoin','Cannot uniquely join IDRiD %s image %s. Use an explicit manifestCSV if the directory tree has been renamed.',split,stem);
        id=split+"/"+stem;
        rows(end+1,:)={"IDRiD",id,images.path(hit),str2double(T{j,cg}),split,""}; %#ok<AGROW>
    end
end
M=cell2table(rows,'VariableNames',{'dataset','sample_id','image_path','grade','source_split','patient_id'});
for name={'dataset','sample_id','image_path','source_split','patient_id'},M.(name{1})=string(M.(name{1}));end
end

function M=read_dr7(cfg)
root=cfg.data.dr7Root;books=dir(fullfile(root,'**','*.xlsx'));
pick=find(contains(lower(string({books.name})),'annotation'));
assert(numel(pick)==1,'nimeq:DR7Labels','Need the DR7 annotation workbook from the cited archive.');
T=readtable(fullfile(books(pick).folder,books(pick).name),'TextType','string','VariableNamingRule','preserve');
names=lower(string(T.Properties.VariableNames));ci=find(names=="image",1);cg=find(names=="status",1);
assert(~isempty(ci)&&~isempty(cg),'nimeq:DR7Columns','Expected Image and Status columns in the annotation workbook.');
images=image_files(root);rows=cell(0,6);
for j=1:height(T)
    stem=lower(regexprep(strtrim(string(T{j,ci})),'\.(jpg|jpeg|png)$',''));
    grade=str2double(string(T{j,cg}))-cfg.data.dr7LabelBase;
    if ismissing(stem) || strlength(stem)==0,continue;end
    hit=find(images.stem==stem);
    assert(numel(hit)==1,'nimeq:ImageJoin','Cannot uniquely join DR7 image %s.',stem);
    rows(end+1,:)={"DR7",stem,images.path(hit),grade,"unspecified",""}; %#ok<AGROW>
end
M=cell2table(rows,'VariableNames',{'dataset','sample_id','image_path','grade','source_split','patient_id'});
for name={'dataset','sample_id','image_path','source_split','patient_id'},M.(name{1})=string(M.(name{1}));end
end

function T=image_files(root)
d=dir(fullfile(root,'**','*'));d=d(~[d.isdir]);path=strings(0,1);stem=strings(0,1);
for j=1:numel(d)
    [~,s,e]=fileparts(d(j).name);
    if ismember(lower(e),{'.jpg','.jpeg','.png','.tif','.tiff'})
        path(end+1,1)=string(fullfile(d(j).folder,d(j).name));stem(end+1,1)=lower(string(s)); %#ok<AGROW>
    end
end
T=table(path,stem);
end
