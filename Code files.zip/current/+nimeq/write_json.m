function write_json(path,value)
parent=fileparts(path);if ~isempty(parent)&&~isfolder(parent),mkdir(parent);end
fid=fopen(path,'w','n','UTF-8');assert(fid>=0,'nimeq:Write','Cannot open %s',path);
guard=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'%s\n',jsonencode(value,'PrettyPrint',true));
end
