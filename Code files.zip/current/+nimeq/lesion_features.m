function f=lesion_features(mask)
% Five descriptors used by supplied DR_feats_fcn, with empty-region handling.
p=regionprops(logical(mask),'Area','Perimeter','Solidity');
if isempty(p),f=zeros(1,5,'single');return;end
a=[p.Area];f=single([numel(p),mean(a),max(a),mean([p.Perimeter]),mean([p.Solidity])]);
end
