function x=move(x,target)
% Move model/checkpoint arrays without requiring Parallel Toolbox on CPU.
if isa(x,'dlnetwork')
    x=dlupdate(@(v)nimeq.move(v,target),x);
    state=x.State;
    for j=1:height(state),state.Value{j}=nimeq.move(state.Value{j},target);end
    x.State=state;
elseif isa(x,'dlarray')
    fmt=dims(x);v=nimeq.host(x);
    if strcmpi(target,'gpu'),v=gpuArray(v);end
    if isempty(fmt),x=dlarray(v);else,x=dlarray(v,fmt);end
elseif isa(x,'gpuArray')
    if strcmpi(target,'cpu'),x=gather(x);end
elseif isnumeric(x)
    if strcmpi(target,'gpu') && isfloat(x),x=gpuArray(x);end
elseif isstruct(x)
    for j=1:numel(x)
        for f=fieldnames(x).',x(j).(f{1})=nimeq.move(x(j).(f{1}),target);end
    end
elseif iscell(x)
    for j=1:numel(x),x{j}=nimeq.move(x{j},target);end
elseif istable(x)
    for f=x.Properties.VariableNames,x.(f{1})=nimeq.move(x.(f{1}),target);end
end
end
