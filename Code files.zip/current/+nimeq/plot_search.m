function plot_search(result,cfg,folder)
T=result.trace;iterations=unique(T(:,1));curve=zeros(numel(iterations),1);
for j=1:numel(iterations),curve(j)=min(T(T(:,1)<=iterations(j),3));end
writetable(table(iterations,curve,'VariableNames',{'iteration','best_fitness_so_far'}),fullfile(folder,'convergence.csv'));
fig=figure('Visible',cfg.figures.visible,'Color','w');plot(iterations,curve,'-o');
xlabel('Iteration');ylabel('Best inner CV fitness');grid on;title(result.method,'Interpreter','none');
nimeq.save_figure(fig,fullfile(folder,'NEW_optimizer_convergence'),cfg);
end
