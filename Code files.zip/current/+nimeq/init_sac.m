function [D,G]=init_sac(K,cfg,seed)
rng(seed,'twister');s=cfg.sac;C=s.channels;H=s.gridSize;P=s.primaryCapsules;
normal=@(shape,scale)dlarray(single(randn(shape)*scale));
D.convW=normal([3 3 1 C],sqrt(2/9));D.convB=dlarray(zeros(C,1,'single'));
A=max(1,floor(C/8));
D.Q=normal([A C],sqrt(2/(A+C)));D.K=normal([A C],sqrt(2/(A+C)));
D.V=normal([C C],sqrt(1/C));
D.primaryW=normal([P*s.primaryDimension C*H*H],sqrt(2/(C*H*H)));
D.primaryB=dlarray(zeros(P*s.primaryDimension,1,'single'));
D.voteW=normal([K*s.classDimension s.primaryDimension P],sqrt(1/s.primaryDimension));
D.advW=normal([1 K*s.classDimension],sqrt(1/(K*s.classDimension)));
D.advB=dlarray(single(0));
assert(H==8,'nimeq:GeneratorGrid','This implementation uses an 8x8 feature grid.');
layers=[imageInputLayer([1 1 s.noiseDimension+K],'Normalization','none','Name','noise_and_class')
    transposedConv2dLayer(4,64,'Stride',1,'Cropping',0,'Name','g_tconv1')
    batchNormalizationLayer('Name','g_bn1');reluLayer('Name','g_relu1')
    transposedConv2dLayer(4,1,'Stride',2,'Cropping','same','Name','g_tconv2')
    tanhLayer('Name','generated_feature_grid')];
G=dlnetwork(layers);
D=nimeq.move(D,cfg.execution);G=nimeq.move(G,cfg.execution);
end
