function T=export_predictions(M,task,pred,score,lengths,model,run,fold,partition,folder)
if ~isfolder(folder),mkdir(folder);end
N=height(M);truth=reshape(task.map(M.grade+1),[],1)+1;
assert(numel(pred)==N && size(score,1)==N,'nimeq:Predictions','Prediction membership does not match source records.');
T=M(:,{'dataset','sample_id','image_path','grade','group_id','patient_id','sha256'});
T.task=repmat(task.name,N,1);T.model=repmat(string(model),N,1);T.run=repmat(string(run),N,1);
T.fold=repmat(fold,N,1);T.partition=repmat(string(partition),N,1);
T.true_label_index=truth;T.predicted_label_index=pred(:);
T.true_label=reshape(task.classes(truth),[],1);T.predicted_label=reshape(task.classes(pred),[],1);
for k=1:task.K,T.(sprintf('normalized_capsule_score_%d',k))=score(:,k);T.(sprintf('raw_capsule_length_%d',k))=lengths(:,k);end
writetable(T,fullfile(folder,'case_predictions.csv'));
nimeq.write_json(fullfile(folder,'class_order.json'),struct('classes',task.classes,'index_base',1, ...
    'score_definition','Class capsule lengths divided by their sum; these scores are not calibrated probabilities.'));
end
