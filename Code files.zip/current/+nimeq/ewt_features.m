function [features,info,bands,filters]=ewt_features(I,cfg)
%EWT_FEATURES Empirical radial Meyer filter bank and fixed-length descriptors.
% This declared reconstruction is not a recovered original paper procedure.
% Concept: Gilles/Tran/Osher, DOI 10.1137/130923774, Sec.5. We use Cartesian
% radial averaging rather than the reference pseudo-polar boundary detector.
e=cfg.ewt;N=e.bands;
I=im2double(I);if size(I,3)==3,I=rgb2gray(I);end
assert(ismatrix(I)&&all(isfinite(I(:)))&&min(size(I))>=8,'nimeq:EWTInput','EWT needs a finite 2-D grayscale or RGB image of at least 8x8.');
[height,width]=size(I);maxRadius=sqrt(2)*pi;
fx=(-floor(width/2):ceil(width/2)-1)*(2*pi/width);
fy=(-floor(height/2):ceil(height/2)-1)*(2*pi/height);
[xx,yy]=meshgrid(fx,fy);radius=sqrt(xx.^2+yy.^2);spectrum=fftshift(fft2(I));
bin=min(e.radialBins,max(1,floor(radius/maxRadius*e.radialBins)+1));
population=accumarray(bin(:),1,[e.radialBins 1]);
profile=accumarray(bin(:),abs(spectrum(:)),[e.radialBins 1])./max(population,1);
frequency=((0:e.radialBins-1).'+.5)/e.radialBins*maxRadius;
% Low frequencies carry mean luminance; include zero as a mode explicitly.
logged=log1p(profile);half=floor(e.smoothingBins/2);q=(-half:half).';
kernel=exp(-.5*(q/max(1,e.smoothingBins/4)).^2);kernel=kernel/sum(kernel);
padded=[repmat(logged(1),half,1);logged;repmat(logged(end),half,1)];
smooth=conv(padded,kernel,'valid');
candidate=find(smooth(2:end-1)>smooth(1:end-2) & smooth(2:end-1)>=smooth(3:end))+1;
candidate=candidate(candidate>e.peakSeparationBins);
[~,order]=sort(smooth(candidate),'descend');chosen=zeros(0,1);
for index=reshape(candidate(order),1,[])
    if isempty(chosen)||all(abs(index-chosen)>=e.peakSeparationBins)
        chosen(end+1,1)=index; %#ok<AGROW>
    end
    if numel(chosen)==N-1,break;end
end
detected=numel(chosen);peaks=sort([0;frequency(chosen)]);
boundaries=(peaks(1:end-1)+peaks(2:end))/2;
% A fixed descriptor length is necessary for the classifier. If fewer modes
% exist, subdivide the largest remaining radial interval, with explicit flag.
while numel(boundaries)<N-1
    edges=[0;boundaries;maxRadius];[~,j]=max(diff(edges));
    boundaries=sort([boundaries;(edges(j)+edges(j+1))/2]);
end
edges=[0;boundaries;maxRadius];gap=diff(edges);
transition=min(e.transitionFraction*boundaries,.45*min(gap(1:end-1),gap(2:end)));
filters=zeros(height,width,N);bands=filters;reconstruction=zeros(height,width);
for b=1:N
    mask=ones(height,width);
    if b>1
        x=(radius-(boundaries(b-1)-transition(b-1)))/(2*transition(b-1));
        mask=mask.*sin(pi/2*meyer_step(x));
    end
    if b<N
        x=(radius-(boundaries(b)+transition(b)))/(2*transition(b));
        % Re-express lower-to-upper transition on [boundary-tau,boundary+tau].
        x=x+1;mask=mask.*cos(pi/2*meyer_step(x));
    end
    filters(:,:,b)=mask;
    bands(:,:,b)=real(ifft2(ifftshift(spectrum.*mask)));
    reconstruction=reconstruction+real(ifft2(ifftshift(spectrum.*mask.^2)));
end
energy=reshape(sum(sum(bands.^2,1),2),1,[]);total=sum(energy);features=zeros(1,4*N+N-1,'single');
for b=1:N
    c=bands(:,:,b);mass=c(:).^2;normalizer=sum(mass);
    if normalizer>eps
        p=mass/normalizer;positive=p>0;entropy=-sum(p(positive).*log(p(positive)))/log(numel(c));
    else,entropy=0;end
    features((b-1)*4+(1:4))=single([energy(b)/max(total,eps),mean(abs(c(:))),std(c(:),0),entropy]);
end
features(4*N+(1:N-1))=single(boundaries/maxRadius);
info=struct('boundaries_radians',boundaries.','normalized_boundaries',boundaries.'/maxRadius, ...
    'transition_half_width',transition.','detected_detail_peaks',detected, ...
    'used_interval_subdivision',detected<N-1,'radial_frequency',frequency, ...
    'radial_magnitude',profile,'smoothed_log_magnitude',smooth,'band_energy',energy, ...
    'tight_frame_max_error',max(abs(sum(filters.^2,3)-1),[],'all'), ...
    'reconstruction_max_error',max(abs(reconstruction-I),[],'all'), ...
    'energy_difference',sum(energy)-sum(I(:).^2), ...
    'method','Declared 2-D radial Meyer EWT reconstruction; original paper parameters unavailable');
assert(info.tight_frame_max_error<1e-10&&info.reconstruction_max_error<1e-10*(1+max(abs(I(:)))), ...
    'nimeq:EWTReconstruction','The empirical filter bank failed tight-frame or inverse checks.');
end

function y=meyer_step(x)
x=min(1,max(0,x));y=x.^4.*(35-84*x+70*x.^2-20*x.^3);
y=min(1,max(0,y));
end
