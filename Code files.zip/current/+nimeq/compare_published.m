function compare_published(runRoot,cfg)
% Reference numbers enter only this post-training report, never model fitting.
reference=fullfile(cfg.projectRoot,'published_reference','tables6_10_as_printed.csv');
if ~isfile(reference),return;end
nimeq.audit_published(cfg,runRoot);
P=nimeq.read_csv_text(reference);rows=table;
fields={'accuracy','sensitivity','specificity','precision','f1','mcc','error_rate'};
measured={'one_vs_rest_accuracy_pct','sensitivity_pct','specificity_pct','precision_pct','f1_pct','mcc_pct','balanced_error_pct'};
for name=cfg.tasks(:).'
    task=nimeq.task_info(name);
    path=fullfile(runRoot,char(name),sprintf('Table%d_NEW_class_metrics.csv',task.table));
    if ~isfile(path),continue;end
    Q=readtable(path,'TextType','string');
    for j=1:height(Q)
        k=find(P.task==name & P.model==Q.model(j) & P.class_label==Q.class_label(j));
        if numel(k)~=1,continue;end
        for f=1:numel(fields)
            raw=P.(fields{f})(k);printed=str2double(raw);
            % Table 5 error formula is a fraction, unlike the percentage metrics.
            scaled=printed;if strcmp(fields{f},'error_rate'),scaled=100*printed;end
            value=Q.(measured{f})(j);
            r=table(name,Q.model(j),Q.class_label(j),string(fields{f}),raw,scaled,value,value-scaled, ...
                'VariableNames',{'task','model','class_label','metric','printed_text','printed_value_pct','new_value_pct','new_minus_printed_pct'});
            if isempty(rows),rows=r;else,rows=[rows;r];end %#ok<AGROW>
        end
    end
end
if ~isempty(rows),writetable(rows,fullfile(runRoot,'NEW_vs_published_values.csv'));end
nimeq.write_json(fullfile(runRoot,'comparison_notes.json'),struct( ...
    'new_measurements','New experiments cannot reconstruct missing historical predictions or correct comparator source descriptions.', ...
    'error_rate','Printed error rates are scaled by 100 for a percentage comparison with Table 5 balanced error.', ...
    'invalid_printed_values','Non-numeric printed strings are retained verbatim and their numeric differences remain NaN.', ...
    'accuracy','Per-class comparisons use one versus rest accuracy; overall accuracy is reported separately.'));
end
