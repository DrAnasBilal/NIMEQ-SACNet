function y=squash(x,dimension)
n2=sum(x.^2,dimension);
y=(n2./(1+n2)).*x./sqrt(n2+1e-8);
end
