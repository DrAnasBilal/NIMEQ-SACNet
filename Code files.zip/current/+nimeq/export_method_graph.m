function export_method_graph(cfg,folder)
if ~isfolder(folder),mkdir(folder);end
source=["Source images","Enhance / segment","Grouped source split", ...
    "Training augmentation","CNN features","Training-fitted SVD", ...
    "Inner CV search","Final SACNet","Grouped source split","Held-out inference"];
target=["Enhance / segment","Grouped source split","Training augmentation", ...
    "CNN features","Training-fitted SVD","Inner CV search", ...
    "Final SACNet","Held-out inference","Held-out inference","Held-out counts"];
if cfg.features.includeLesionDescriptors
    source=[source,"Training augmentation","Lesion descriptors"];target=[target,"Lesion descriptors","Training-fitted SVD"];
end
if cfg.ewt.enabled
    source=[source,"Training augmentation","EWT features"];target=[target,"EWT features","Training-fitted SVD"];
end
G=digraph(source,target);
writetable(table(source(:),target(:),'VariableNames',{'from_stage','to_stage'}),fullfile(folder,'NEW_method_graph_edges.csv'));
fig=figure('Visible',cfg.figures.visible,'Color','w','Position',[50 50 1500 700]);
plot(G,'Layout','layered','NodeFontSize',10);
title('Implemented data flow: choices and original-method gaps are documented');
nimeq.save_figure(fig,fullfile(folder,'NEW_implemented_method'),cfg);
end
