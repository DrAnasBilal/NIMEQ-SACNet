function F=prepare_fold(trainM,valM,task,cfg,folder,seed)
% CNN, augmentation, feature normalization and SVD are fitted within the fold.
assert(isempty(intersect(trainM.group_id,valM.group_id)),'nimeq:Leakage','Feature-fit groups overlap validation/test groups.');
if ~isfolder(folder),mkdir(folder);end
featurePath=fullfile(folder,'fold_features.mat');
if isfile(featurePath),d=load(featurePath,'F');F=d.F;return;end
fprintf('Fitting CNN/SVD for %s (%d training, %d evaluation source images)\n',folder,height(trainM),height(valM));
A=nimeq.make_training_set(trainM,task,cfg,fullfile(folder,'training_images'),seed);
assert(numel(unique(A.label_index))==task.K,'nimeq:MissingTrainingClass', ...
    'This training fold lacks a task class. Inspect the grouped split and data exclusions; do not invent samples.');
imds=imageDatastore(cellstr(A.image_path),'ReadFcn',@(f)im2single(imread(f)));
labelNames=reshape(task.classes(A.label_index),[],1);
imds.Labels=categorical(labelNames,task.classes,task.classes);
netPath=fullfile(folder,'cnn_feature_model.mat');
if isfile(netPath)
    d=load(netPath,'net','info');net=d.net;info=d.info;
else
    rng(seed,'twister');
    opts=trainingOptions('adam','MaxEpochs',cfg.cnn.epochs,'MiniBatchSize',cfg.cnn.batchSize, ...
        'InitialLearnRate',cfg.cnn.learningRate,'Shuffle','every-epoch', ...
        'ExecutionEnvironment',cfg.execution,'Plots','none','Verbose',cfg.cnn.verbose);
    [net,info]=trainNetwork(imds,nimeq.cnn_layers(cfg,task.K),opts);
    save(netPath,'net','info','-v7.3');
end
featureds=imageDatastore(cellstr(A.image_path),'ReadFcn',@(f)im2single(imread(f)));
Xtr=activations(net,featureds,'features','OutputAs','rows','MiniBatchSize',cfg.cnn.batchSize,'ExecutionEnvironment',cfg.execution);
valds=imageDatastore(cellstr(valM.pre_path),'ReadFcn',@(f)im2single(imread(f)));
Xval=activations(net,valds,'features','OutputAs','rows','MiniBatchSize',cfg.cnn.batchSize,'ExecutionEnvironment',cfg.execution);
Xtr=nimeq.host(Xtr);Xval=nimeq.host(Xval);
Lval=zeros(height(valM),10,'single');
for j=1:height(valM)
    Lval(j,:)=[nimeq.lesion_features(imread(valM.red_path(j))>0),nimeq.lesion_features(imread(valM.bright_path(j))>0)];
end
Etr=[];Eval=[];
if cfg.ewt.enabled
    Etr=nimeq.ewt_batch(A.image_path,cfg,folder,'training');
    Eval=nimeq.ewt_batch(valM.pre_path,cfg,folder,'evaluation');
end
[Xtr,names]=nimeq.feature_matrix(Xtr,A.lesion_features,Etr,cfg);
Xval=nimeq.feature_matrix(Xval,Lval,Eval,cfg);
[Ztr,svdModel]=nimeq.fit_svd(Xtr,cfg);Zval=nimeq.apply_svd(Xval,svdModel);
F.Xtr=Ztr.';F.Xval=Zval.';F.ytr=A.label_index(:).';F.yval=reshape(task.map(valM.grade+1),1,[])+1;
F.trainAncestry=removevars(A,'lesion_features');F.valRecords=valM;
F.lesionTrain=A.lesion_features;F.lesionVal=Lval;
F.cnnModelPath=netPath;F.svdModel=svdModel;F.seed=seed;
F.rawTrainingFeatures=Xtr;F.rawEvaluationFeatures=Xval;F.featureNames=names;
F.ewtTrain=Etr;F.ewtVal=Eval;
save(featurePath,'F','-v7.3');
writetable(table((1:numel(names)).',names(:),'VariableNames',{'column_index','feature_name'}),fullfile(folder,'feature_schema.csv'));
if cfg.export.rawFeatureCSV
    trainFeatures=array2table(Xtr,'VariableNames',cellstr(names));
    evaluationFeatures=array2table(Xval,'VariableNames',cellstr(names));
    writetable([removevars(A,'lesion_features'),trainFeatures],fullfile(folder,'raw_training_features.csv'));
    writetable([valM(:,{'dataset','sample_id','grade','group_id'}),evaluationFeatures],fullfile(folder,'raw_evaluation_features.csv'));
end
writetable(valM(:,{'dataset','sample_id','grade','group_id'}),fullfile(folder,'evaluation_source_membership.csv'));
writetable(table((1:numel(svdModel.singularValues)).',svdModel.singularValues,'VariableNames',{'component','singular_value'}),fullfile(folder,'svd_values.csv'));
nimeq.write_json(fullfile(folder,'fit_metadata.json'),struct('training_source_images',height(trainM), ...
    'augmented_training_observations',height(A),'evaluation_source_images',height(valM), ...
    'seed',seed,'fitted_svd_rank',svdModel.rank,'cnn_epochs',cfg.cnn.epochs,'ewt_enabled',cfg.ewt.enabled, ...
    'supervised_cnn_saw_evaluation_labels',false,'fit_statistics_use_training_only',true));
if isfield(info,'TrainingLoss')
    history=table((1:numel(info.TrainingLoss)).',info.TrainingLoss(:),info.TrainingAccuracy(:), ...
        'VariableNames',{'iteration','training_loss','training_accuracy_pct'});
    writetable(history,fullfile(folder,'cnn_training_history.csv'));
end
end
