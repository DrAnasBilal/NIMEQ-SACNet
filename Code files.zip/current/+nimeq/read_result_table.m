function T=read_result_table(path)
% Preserve IDs, paths and hashes while reading comma-separated CSV files.

opts=detectImportOptions(path,'FileType','text','Delimiter',',', ...
    'VariableNamesLine',1,'TextType','string', ...
    'VariableNamingRule','preserve');

opts.DataLines=[2 Inf];
opts.VariableUnitsLine=0;
opts.VariableDescriptionsLine=0;
opts.RowNamesColumn=0;

textColumns={'dataset','sample_id','image_path','patient_id', ...
    'group_id','sha256','task','model','run','partition', ...
    'true_label','predicted_label','parent_sample_id', ...
    'operation','class_label','true_class','profile', ...
    'source_split','pre_path','red_path','bright_path'};

selected=intersect(opts.VariableNames,textColumns,'stable');

if ~isempty(selected)
    opts=setvartype(opts,selected,'string');
end

T=readtable(path,opts);
end