function export_examples(M,cfg,folder)
if ~isfolder(folder),mkdir(folder);end
S=nimeq.segment_fundus(imread(M.image_path(1)),cfg);
I=imresize(S.preprocessed,cfg.imageSize);R=imresize(S.red,cfg.imageSize,'nearest');B=imresize(S.bright,cfg.imageSize,'nearest');
bank=nimeq.augmentation_bank();fig=figure('Visible',cfg.figures.visible,'Color','w','Position',[100 100 1500 1100]);tiledlayout(6,6,'TileSpacing','compact');
nexttile;imshow(I);title('Preprocessed');
for j=1:height(bank)
    nexttile;[J,~,~,label]=nimeq.augment_image(I,R,B,bank.kind(j),bank.level(j));imshow(J);title(label,'Interpreter','none','FontSize',8);
end
nimeq.save_figure(fig,fullfile(folder,'Figure7_augmentation'),cfg);
fig=figure('Visible',cfg.figures.visible,'Color','w','Position',[100 100 1200 750]);tiledlayout(2,3);
nexttile;imshow(S.original);title('Source fundus image');nexttile;imshow(S.preprocessed);title('YCbCr preprocessing');
nexttile;imshow(S.red);title('Red lesions');nexttile;imshow(S.rawBright);title('Bright candidates');
nexttile;imshow(S.bright);title('Bright lesions');nexttile;imshow(labeloverlay(S.original,S.red|S.bright));title('Segmentation overlay');
nimeq.save_figure(fig,fullfile(folder,'Figure8_segmentation'),cfg);
imwrite(im2uint8(S.preprocessed),fullfile(folder,'example_preprocessed.png'));
imwrite(S.red,fullfile(folder,'example_red_mask.png'));imwrite(S.bright,fullfile(folder,'example_bright_mask.png'));
save(fullfile(folder,'example_segmentation.mat'),'S','-v7.3');
nimeq.write_json(fullfile(folder,'example_source.json'),table2struct(M(1,{'dataset','sample_id','image_path','sha256'})));
nimeq.export_ewt_example(I,cfg,folder);
for dataset=unique(M.dataset).'
    D=M(M.dataset==dataset,:);grades=unique(D.grade).';
    fig=figure('Visible',cfg.figures.visible,'Color','w','Position',[100 100 1300 450]);tiledlayout(1,numel(grades));
    for j=1:numel(grades),ix=find(D.grade==grades(j),1);nexttile;imshow(imread(D.image_path(ix)));title(sprintf('Grade %d',grades(j)));end
    nimeq.save_figure(fig,fullfile(folder,char("Figure12_"+dataset+"_training_samples")),cfg);
end
end
