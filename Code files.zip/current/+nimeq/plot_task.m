function plot_task(R,task,cfg,folder)
names=string({R.model});K=task.K;V=numel(R);acc=zeros(V,K);
for v=1:V,acc(v,:)=R(v).perClass.one_vs_rest_accuracy_pct.';end
fig=figure('Visible',cfg.figures.visible,'Color','w');imagesc(acc,[0 100]);colorbar;colormap(parula);
set(gca,'XTick',1:K,'XTickLabel',cellstr(task.classes),'YTick',1:V,'YTickLabel',cellstr(names),'TickLabelInterpreter','none');xtickangle(25);
for v=1:V,for k=1:K,text(k,v,sprintf('%.2f',acc(v,k)),'HorizontalAlignment','center','Color','k');end,end
title(char(task.name+": new one versus rest class accuracies"),'Interpreter','none');
nimeq.save_figure(fig,fullfile(folder,'Figure13_accuracy_heatmap'),cfg);

fields={'one_vs_rest_accuracy_pct','sensitivity_pct','specificity_pct','f1_pct'};
fig=figure('Visible',cfg.figures.visible,'Color','w','Position',[100 100 1150 750]);tiledlayout(2,2);
for j=1:4
    nexttile;hold on;
    for v=1:V,plot(1:K,R(v).perClass.(fields{j}),'-o','LineWidth',1.2);end
    set(gca,'XTick',1:K,'XTickLabel',cellstr(task.classes));xtickangle(25);ylim([0 100]);grid on;
    title(strrep(fields{j},'_',' '));
end
legend(cellstr(names),'Interpreter','none','Location','best');
nimeq.save_figure(fig,fullfile(folder,'Figure14_metric_comparison'),cfg);

fig=figure('Visible',cfg.figures.visible,'Color','w');ax=polaraxes(fig);hold(ax,'on');angles=linspace(0,2*pi,5);
for v=1:V
    o=R(v).overall;values=[o.overall_accuracy_pct,o.macro_recall_pct,o.macro_specificity_pct,o.macro_f1_pct];
    polarplot(ax,angles,values([1:4 1]),'-o','LineWidth',1.2);
end
thetaticks(ax,[0 90 180 270]);thetaticklabels(ax,{'Overall accuracy','Macro recall','Macro specificity','Macro F1'});rlim(ax,[0 100]);
legend(cellstr(names),'Interpreter','none','Location','southoutside');
title(ax,'New metrics from held-out predictions');nimeq.save_figure(fig,fullfile(folder,'Figure15_metric_radar'),cfg);

fig=figure('Visible',cfg.figures.visible,'Color','w','Position',[100 100 1250 850]);tiledlayout(2,V);
for v=1:V
    C=R(v).C;
    nexttile(v);imagesc(C);axis image;colorbar;set(gca,'XTick',1:K,'YTick',1:K);title(char(names(v)), 'Interpreter','none');xlabel('Predicted index');ylabel('True index');
    for i=1:K,for j=1:K,text(j,i,sprintf('%d',C(i,j)),'HorizontalAlignment','center','Color','r');end,end
    den=sum(C,2);P=C./max(den,1);P(den==0,:)=NaN;
    nexttile(V+v);imagesc(P,[0 1]);axis image;colorbar;set(gca,'XTick',1:K,'YTick',1:K);title('Row normalized counts');
    for i=1:K,for j=1:K,if den(i)>0,text(j,i,sprintf('%.2f',P(i,j)),'HorizontalAlignment','center','Color','r');end,end,end
end
nimeq.save_figure(fig,fullfile(folder,'Figure16_confusion_matrices'),cfg);

for v=1:V
    modelFolder=fullfile(folder,char(names(v)));if ~isfolder(modelFolder),mkdir(modelFolder);end
    fig=figure('Visible',cfg.figures.visible,'Color','w');hold on;areas=nan(K,1);
    for k=1:K
        [x,y,t,areas(k)]=nimeq.roc_curve(R(v).truth==k,R(v).scores(:,k));
        if ~isempty(x)
            plot(x,y,'LineWidth',1.2,'DisplayName',sprintf('%s AUC %.3f',task.classes(k),areas(k)));
            writetable(table(x,y,t,'VariableNames',{'false_positive_rate','true_positive_rate','threshold'}),fullfile(modelFolder,sprintf('roc_class_%d.csv',k)));
        end
    end
    plot([0 1],[0 1],'k--','HandleVisibility','off');xlabel('False positive rate');ylabel('True positive rate');grid on;
    title(char(names(v)+" held-out ROC"),'Interpreter','none');legend('Location','southeast','Interpreter','none');
    nimeq.save_figure(fig,fullfile(modelFolder,'ROC'),cfg);
    writetable(table(task.classes(:),areas,'VariableNames',{'class_label','auc'}),fullfile(modelFolder,'auc.csv'));
    H=R(v).history;
    fig=figure('Visible',cfg.figures.visible,'Color','w');tiledlayout(1,2);
    nexttile;plot(H(:,1),H(:,2:4),'LineWidth',1.1);legend({'Discriminator','Generator','Capsule margin'});xlabel('Epoch');ylabel('Training loss');grid on;
    nexttile;plot(H(:,1),H(:,5),'LineWidth',1.1);xlabel('Epoch');ylabel('Training accuracy percent');ylim([0 100]);grid on;
    nimeq.save_figure(fig,fullfile(modelFolder,'Training_history'),cfg);
end
end
