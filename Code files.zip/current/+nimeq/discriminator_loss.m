function [loss,gradient,margin,correct]=discriminator_loss(D,G,X,T,Z,h,cfg,K)
fake=forward(G,Z);
fake=dlarray(extractdata(fake),'SSCB'); % Stop gradients into G during D update.
mask=reshape(single(h.mask),cfg.sac.gridSize,cfg.sac.gridSize,1,1);
mask=nimeq.move(mask,cfg.execution);fake=fake.*mask;
[realLengths,realLogit]=nimeq.sac_forward(D,X,h,cfg,K);
[~,fakeLogit]=nimeq.sac_forward(D,fake,h,cfg,K);
margin=nimeq.capsule_loss(realLengths,T,cfg);
hinge=mean(max(0,1-realLogit),'all')+mean(max(0,1+fakeLogit),'all');
loss=margin+h.chi*hinge;
gradient=dlgradient(loss,D);
[~,pred]=max(nimeq.host(realLengths),[],1);[~,truth]=max(nimeq.host(T),[],1);
correct=sum(pred==truth);
end
