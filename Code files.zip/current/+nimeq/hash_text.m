function h=hash_text(text)
md=java.security.MessageDigest.getInstance('SHA-256');
md.update(typecast(unicode2native(char(text),'UTF-8'),'int8'));
h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
