function [D,state]=spectral_project(D,state)
% Spectral constraint estimated by persistent power iteration after each step.
% This explicit projection is a reconstruction choice; see METHOD_MAPPING.
for f={'convW','Q','K','V','primaryW','voteW','advW'}
    name=f{1};W=extractdata(D.(name));shape=size(W);
    if strcmp(name,'convW'),A=reshape(permute(W,[4 3 1 2]),shape(4),[]);else,A=reshape(W,shape(1),[]);end
    if isfield(state,name),u=state.(name);else,u=ones(size(A,1),1,'like',A);u=u/sqrt(numel(u));end
    if isa(A,'gpuArray') && ~isa(u,'gpuArray'),u=gpuArray(u);end
    if ~isa(A,'gpuArray') && isa(u,'gpuArray'),u=gather(u);end
    v=A.'*u;v=v/max(sqrt(sum(v.^2)),1e-8);
    u=A*v;u=u/max(sqrt(sum(u.^2)),1e-8);
    sigma=abs(u.'*A*v);
    D.(name)=dlarray(W/max(single(1),sigma));state.(name)=u;
end
end
