function loss=capsule_loss(lengths,T,cfg)
s=cfg.sac;
loss=mean(sum(T.*max(0,s.marginPositive-lengths).^2+ ...
    s.negativeMarginWeight*(1-T).*max(0,lengths-s.marginNegative).^2,1),'all');
end
