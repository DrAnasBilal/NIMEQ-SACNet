function S=make_splits(D,cfg)
% Grouped source split BEFORE augmentation. Same split is reused by all models.
rs=RandStream('mt19937ar','Seed',cfg.seed);
[groups,~,g]=unique(D.group_id,'stable');G=numel(groups);
grade=zeros(G,1);
for j=1:G,grade(j)=mode(D.grade(g==j));end
held=false(G,1);
if all(D.dataset=="IDRiD") && strcmpi(cfg.split.idridMode,'official')
    for j=1:G
        parts=unique(D.source_split(g==j));
        assert(numel(parts)==1 && ismember(parts,["training","testing"]),'nimeq:OfficialLeakage','A patient or identical-image group crosses the official IDRiD split, or its source split is missing. Resolve the data or explicitly choose resplit.');
        held(j)=parts=="testing";
    end
else
    for c=unique(grade).'
        idx=find(grade==c);idx=idx(randperm(rs,numel(idx)));
        ntest=min(numel(idx)-1,max(1,round(cfg.split.testFraction*numel(idx))));
        if ntest>0,held(idx(1:ntest))=true;end
    end
end
assert(any(held)&&any(~held),'nimeq:Split','The data do not support a nonempty grouped holdout.');
fold=zeros(G,1);load=zeros(cfg.search.folds,1);
for c=unique(grade(~held)).'
    idx=find(grade==c & ~held);idx=idx(randperm(rs,numel(idx)));
    for j=1:numel(idx)
        [~,f]=min(load);fold(idx(j))=f;load(f)=load(f)+1;
    end
end
assert(all(load>0),'nimeq:CV','Not enough training groups for the requested number of folds.');
S=D;S.partition=repmat("train",height(D),1);S.partition(held(g))="test";S.inner_fold=fold(g);
assert(isempty(intersect(S.group_id(S.partition=="train"),S.group_id(S.partition=="test"))),'nimeq:Leakage','Training and test groups overlap.');
end
