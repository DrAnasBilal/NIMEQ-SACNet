function [I,R,B,operation]=augment_image(I,R,B,kind,level)
% Paired geometric transforms preserve the ancestry and alignment of masks.
% Photometric transformations leave the corresponding masks unchanged.
I=im2single(I);R=logical(R);B=logical(B);
switch char(kind)
    case 'blur',I=imgaussfilt(I,level);
    case 'sharpen',I=imsharpen(I,'Amount',level);
    case 'emboss'
        kernel=level*[-2 -1 0;-1 1 1;0 1 2];
        for c=1:3,I(:,:,c)=imfilter(I(:,:,c),kernel,'replicate')+.5;end
    case 'edge'
        e=edge(rgb2gray(I),'Canny',min(.99,max(.01,level*.4)));
        I=repmat(single(e),1,1,3);
    case 'rotate'
        I=imrotate(I,level,'bilinear','crop');R=imrotate(R,level,'nearest','crop');B=imrotate(B,level,'nearest','crop');
    case 'fliplr',I=fliplr(I);R=fliplr(R);B=fliplr(B);
    case 'flipud',I=flipud(I);R=flipud(R);B=flipud(B);
    case {'shearx','sheary','skewx','skewy'}
        A=eye(3);
        if ismember(char(kind),{'shearx','skewx'}),A(2,1)=tand(level);else,A(1,2)=tand(level);end
        t=affine2d(A);view=imref2d(size(R));
        I=imwarp(I,t,'OutputView',view);R=imwarp(R,t,'nearest','OutputView',view);B=imwarp(B,t,'nearest','OutputView',view);
    case 'scale'
        t=affine2d([level 0 0;0 level 0;0 0 1]);view=imref2d(size(R));
        I=imwarp(I,t,'OutputView',view);R=imwarp(R,t,'nearest','OutputView',view);B=imwarp(B,t,'nearest','OutputView',view);
    case 'identity'
    otherwise,error('nimeq:Augmentation','Unknown augmentation %s',kind);
end
I=min(1,max(0,I));operation=string(kind)+"_"+string(level);
end
