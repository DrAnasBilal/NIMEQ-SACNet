function export_ensemble(R,M,task,cfg,folder)
% Additional reconstruction of the unspecified voting step; not Tables 6-10.
if numel(R)<2,return;end
votes=zeros(height(M),numel(R));scores=zeros(height(M),task.K);
for j=1:numel(R)
    [~,votes(:,j)]=max(R(j).scores,[],2);scores=scores+R(j).scores/numel(R);
end
pred=zeros(height(M),1);
for j=1:height(M)
    counts=accumarray(votes(j,:).',1,[task.K 1]);tied=find(counts==max(counts));
    [~,best]=max(scores(j,tied));pred(j)=tied(best);
end
out=fullfile(folder,'additional_majority_vote');
nimeq.export_predictions(M,task,pred,scores,nan(size(scores)),'Variant_majority_vote',cfg.experimentName,0,'heldout_test',out);
truth=reshape(task.map(M.grade+1),[],1)+1;nimeq.export_metrics(truth,pred,task,out);
writematrix(votes,fullfile(out,'individual_variant_votes.csv'));
nimeq.write_json(fullfile(out,'voting_rule.json'),struct('models',string({R.model}), ...
    'rule','One vote per trained variant; ties use mean normalized capsule score, then class order.', ...
    'provenance','The paper does not define the voting members or tie rule; this is an additional experiment.'));
end
