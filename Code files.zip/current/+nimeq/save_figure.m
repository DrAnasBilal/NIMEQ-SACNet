function save_figure(fig,path,cfg)
parent=fileparts(path);if ~isfolder(parent),mkdir(parent);end
savefig(fig,[path '.fig']);
exportgraphics(fig,[path '.png'],'Resolution',cfg.figures.dpi);
close(fig);
end
