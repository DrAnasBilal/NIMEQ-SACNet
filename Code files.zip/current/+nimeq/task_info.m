function t=task_info(name)
t.name=string(name);
switch char(name)
 case 'IDRiD_binary',t.dataset="IDRiD";t.map=[0 1 1 1 1];t.classes=["Normal","Abnormal"];t.table=6;
 case 'IDRiD_5class',t.dataset="IDRiD";t.map=0:4;t.classes=["Normal","Mild","Moderate","Severe","PDR"];t.table=7;
 case 'DR7_binary',t.dataset="DR7";t.map=[0 1 1 1 1 1 1];t.classes=["Normal","Abnormal"];t.table=8;
 case 'DR7_5class',t.dataset="DR7";t.map=[0 1 2 3 3 4 4];t.classes=["Normal","Mild","Moderate","Severe","PDR"];t.table=9;
 case 'DR7_7class',t.dataset="DR7";t.map=0:6;t.classes=["Normal","Mild NPDR","Moderate NPDR","Severe NPDR","Very Severe NPDR","PDR","Advanced PDR"];t.table=10;
 otherwise,error('nimeq:Task','Unknown task %s',name);
end
t.K=numel(t.classes);
end
