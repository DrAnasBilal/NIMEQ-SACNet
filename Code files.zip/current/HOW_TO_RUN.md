# How to run the project on your computer

## 1. Extract and open

Extract the complete ZIP to a writable folder with a short path. For example, use `C:\Research\NIMEQ_SACNet_Experiment_Code` on Windows, or a `NIMEQ_SACNet_Experiment_Code` folder in your research directory on macOS/Linux.

Open MATLAB. Navigate its Current Folder panel to the extracted folder containing `nimeq_config.m`, `RUN_SELF_TEST.m` and `+nimeq`. Do not run inside the ZIP. Keep the leading plus sign on `+nimeq`: it defines the MATLAB namespace.

Example Windows commands; replace the path with your actual folder:

```matlab
cd('C:\Research\NIMEQ_SACNet_Experiment_Code')
addpath(pwd)
```

Only add this root folder. Avoid `addpath(genpath(pwd))`, which would activate the unchanged legacy scripts in `reference_inputs`.

## 2. Check software

Use MATLAB **R2023b or newer** with **Deep Learning Toolbox** and **Image Processing Toolbox**. Optional SVM/KNN/tree comparisons require **Statistics and Machine Learning Toolbox**. GPU execution requires a supported GPU and **Parallel Computing Toolbox**. CPU execution is supported but the large CNN can be slow. Python and Wavelet Toolbox are not dependencies of the MATLAB experiment code.

Run:

```matlab
RUN_ENVIRONMENT_CHECK
RUN_SELF_TEST
```

Software information and test results are saved under `local_validation/`. All tests must pass before continuing. Tests use small synthetic unit fixtures and a short SACNet training cycle to check implementation behavior; they do not establish DR performance. MATLAB tests have not been executed in the development environment because MATLAB is unavailable there.

If a test fails, preserve `local_validation/matlab_self_test_console.log`, `matlab_self_test_results.csv` and the full error. Correct it before a research run. The environment check alone is not a substitute for gradient/training tests.

## 3. Run the small real-data check

With internet access:

```matlab
RUN_QUICK
```

This downloads the paper's cited [DR7 version 0.2](https://zenodo.org/records/4647952), verifies its archive checksum and extracts into `data/DR7`. It runs the complete pipeline for DR7 binary with all four variants at a small budget. The download is about 375 MB. Source hashing, preprocessing, CNN fitting, SACNet epochs and search candidates print progress.

Outputs go to `results/quick_v2_seed41`. A successful run ends with a verification summary and completion message. Its `status.json` must say `completed`. Quick-profile results are installation checks, not full-budget research results.

If downloading fails, manually obtain/extract the ZIP and annotation workbook from that exact record into `data/DR7`, then set `cfg.data.downloadDR7=false` in the runner. A checksum mismatch means an incomplete or different archive; obtain the correct archive before proceeding.

## 4. Install IDRiD for all five tasks

Obtain the official [IDRiD dataset from IEEE DataPort](https://ieee-dataport.org/open-access/indian-diabetic-retinopathy-image-dataset-idrid). Authentication may be required. Download **Disease Grading** images and both grading-label CSVs. Extract under `data/IDRiD`, preserving training/testing directories. The segmentation-only download is insufficient for all classification tasks.

Keep one training-label CSV and one testing-label CSV under that tree. The importer reads image-name and retinopathy-grade columns and joins filenames. [docs/DATA_SETUP.md](docs/DATA_SETUP.md) explains renamed folders, explicit manifests and patient IDs.

Run:

```matlab
CHECK_DATA
```

Inspect `data_check/`, `data/quality_reports/` and class distributions. Identical bytes with contradictory grades are quarantined and reported, so accepted counts can differ from nominal archive counts. Ambiguous joins stop with an error. Resolve source/annotation problems; do not invent labels or move held-out images into training.

## 5. Generate all task/model results

The reduced-budget profile covers all five tasks, all four models and ten Table 4 trials:

```matlab
RUN_WORKSTATION
```

Results go to `results/workstation_v2_seed41`. It can require up to 1,440 inner SACNet fits of three epochs each, 20 CNN fits and 20 final SACNet fits before cache reuse. This is substantial computation; runtime has not been measured. Disclose its actual lower fold/epoch/search budget.

For the full configuration instead:

```matlab
RUN_ALL
```

Results go to `results/full_v2_seed41`. This uses 10 CV folds, eight wolves, 100 search iterations, 100 epochs per fitness fit and 100 final SACNet epochs. Its upper bound is 192,000 inner SACNet fits, 55 CNN fits and 20 final fits before cache reuse. This may exceed a personal computer's practical compute/storage budget. The paper does not establish the missing original architecture or precise inner-training schedule, and this larger run cannot guarantee published performance.

If Statistics and Machine Learning Toolbox is unavailable, set `cfg.legacyBaselines=false` in the runner and choose a new experiment name. All four main network variants still run; optional SVM/KNN/tree outputs are then omitted and must be reported as omitted.

## 6. Verify results

Every main runner recalculates final metrics from individual predictions and checks source membership before marking completion. To repeat:

```matlab
VERIFY_RESULTS
```

The script defaults to `workstation_v2_seed41`. Edit `runRoot` for a quick/full/custom run. Set `rehashSourceImages=true` to reread original image bytes, or `deepCV=true` to rederive every cached candidate's CV fitness. Deep verification can take a long time. Each check saves a new directory under `<run>/verification/`. These checks establish consistency of this new experiment, not authenticity of old publication numbers.

## 7. Find tables, figures and numerical data

Within each task folder:

- `Table6_NEW_class_metrics.csv` through `Table10_NEW_class_metrics.csv`: corresponding measured class-level tables.
- `<model>/case_predictions.csv`: source IDs/hashes, true/predicted labels and scores.
- `<model>/confusion_counts.csv`, `class_metrics.csv`, `overall_metrics.csv`: integer counts and derived measurements.
- `<model>/training_history.csv`, `optimization/.../search_trace.csv`: actual training/search records.
- `.fig` files: editable native MATLAB graphics; `.png` files: previews.
- `final_features/fold_features.mat` and `raw_*_features.csv`: feature matrices, schemas and SVD data.

Table 4 trials and mean are in `IDRiD_binary/` for workstation/full, and `DR7_binary/` for quick. The run root holds a new-experiment summary, configuration/software, coverage ledger, data splits and post-experiment differences from printed values. [docs/OUTPUTS.md](docs/OUTPUTS.md) gives the full map.

## 8. Resume or change settings

Resume by rerunning the same runner with the same name, data, paths, code and settings. SACNet resumes after its last complete epoch; search resumes after its last complete iteration and reuses saved candidate measurements. An interrupted CNN fit restarts that fold's CNN. Keep earlier checkpoints and experiments.

Changing code, preprocessing, EWT, folds, epochs, execution mode, source membership or paths changes the run signature. Choose a **new** `cfg.experimentName`. A completed run can be reopened and verified without retraining.

For out-of-memory errors, use a new run name and lower `cfg.cnn.batchSize` and `cfg.sac.batchSize` in the runner. Switching to `cfg.execution='cpu'` also requires a new name. Save/disclose settings. Smaller batches do not remove the memory required by the large dense layer.

## 9. Predict on new images

Edit `PREDICT_NEW.m` to select a saved `inference_bundle.mat`, new image folder and output CSV. The default example selects workstation IDRiD five-class NIMEQ. Run:

```matlab
PREDICT_NEW
```

Keep the whole task folder: the bundle references its final CNN by relative path. Scores are normalized capsule lengths, not calibrated clinical probabilities. Binary labels mean no DR versus any DR, not an established clinical VTDR threshold.

## 10. Describe the outputs accurately

These files are **new experiments with documented reconstruction choices**. State the actual profile/date, report all variants, retain inputs and identify authentic historical records separately. New runs cannot establish the cause of old discrepancies or why references were added. [docs/EVIDENCE_SCOPE.md](docs/EVIDENCE_SCOPE.md) maps journal concerns to available outputs and remaining evidence needs.
