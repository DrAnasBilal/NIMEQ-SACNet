% Arithmetic on the printed paper only. No dataset or training is required.
projectRoot=fileparts(mfilename('fullpath'));addpath(projectRoot);
cfg=nimeq_config('full');folder=fullfile(projectRoot,'reference_arithmetic_check');
if ~isfolder(folder),mkdir(folder);end
nimeq.audit_published(cfg,folder);
disp(['Printed-table arithmetic checks: ' folder]);
