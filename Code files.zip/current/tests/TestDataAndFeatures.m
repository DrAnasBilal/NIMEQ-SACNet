classdef TestDataAndFeatures < matlab.unittest.TestCase
    methods (Test)
        function emptySegmentationAndDescriptors(t)
            cfg=nimeq_config('quick');S=nimeq.segment_fundus(zeros(96,96,3,'uint8'),cfg);
            t.verifySize(S.red,[96 96]);t.verifySize(S.bright,[96 96]);
            t.verifySize(S.nativeFeatures,[1 10]);t.verifyTrue(all(isfinite(S.nativeFeatures)));
            t.verifyEqual(nimeq.lesion_features(false(20)),zeros(1,5,'single'));
            mask=false(20);mask(3:7,4:8)=true;f=nimeq.lesion_features(mask);
            t.verifyEqual(f(1:3),single([1 25 25]));t.verifyGreaterThan(f(4),0);t.verifyEqual(f(5),single(1));
        end
        function pairedGeometricTransforms(t)
            M=false(64);M(10:17,20:27)=true;I=repmat(single(M),1,1,3);
            [J,R,B]=nimeq.augment_image(I,M,M,'rotate',90);
            t.verifyEqual(R,B);t.verifyEqual(J(:,:,1)>.5,R);
            [J,R,B]=nimeq.augment_image(I,M,M,'shearx',10);
            t.verifyEqual(R,B);t.verifyClass(R,'logical');t.verifySize(J,[64 64 3]);
            bank=nimeq.augmentation_bank();
            for j=1:height(bank)
                [J,R,B]=nimeq.augment_image(I,M,M,bank.kind(j),bank.level(j));
                t.verifySize(J,[64 64 3]);t.verifySize(R,[64 64]);t.verifyEqual(R,B);
                t.verifyTrue(all(isfinite(J(:))));
            end
        end
        function groupingSurvivesHoldoutAndCV(t)
            cfg=nimeq_config('quick');cfg.search.folds=3;
            grade=repelem((0:6).',12);N=numel(grade);
            group_id="g"+string(ceil((1:N).'/2));dataset=repmat("DR7",N,1);source_split=repmat("unspecified",N,1);
            D=table(dataset,grade,group_id,source_split);S=nimeq.make_splits(D,cfg);
            t.verifyEmpty(intersect(S.group_id(S.partition=="train"),S.group_id(S.partition=="test")));
            for f=1:3
                fit=S.partition=="train" & S.inner_fold~=f;val=S.partition=="train" & S.inner_fold==f;
                t.verifyEmpty(intersect(S.group_id(fit),S.group_id(val)));t.verifyTrue(any(val));
            end
            T=nimeq.make_splits(D,cfg);t.verifyEqual(S,T);
        end
        function conflictingDuplicatesAreQuarantined(t)
            folder=tempname;mkdir(folder);cleanup=onCleanup(@()rmdir(folder,'s')); %#ok<NASGU>
            cfg=nimeq_config('quick');cfg.projectRoot=folder;
            a=fullfile(folder,'a.png');b=fullfile(folder,'b.png');c=fullfile(folder,'c.png');
            imwrite(zeros(24,24,3,'uint8'),a);copyfile(a,b);imwrite(ones(24,24,3,'uint8')*200,c);
            dataset=repmat("DR7",3,1);sample_id=["a";"b";"c"];image_path=string({a;b;c});grade=[0;1;2];
            T=table(dataset,sample_id,image_path,grade);cfg.data.manifestCSV=fullfile(folder,'manifest.csv');writetable(T,cfg.data.manifestCSV);
            M=nimeq.prepare_manifest(cfg);t.verifyEqual(height(M),1);t.verifyEqual(M.sample_id,"c");
            Q=readtable(fullfile(folder,'data','quality_reports','conflicting_identical_image_labels.csv'));
            t.verifyEqual(height(Q),2);
        end
        function svdUsesTrainingStatistics(t)
            cfg=nimeq_config('quick');rng(71);X=randn(20,90);[Z,F]=nimeq.fit_svd(X,cfg);
            before=F;Q=nimeq.apply_svd(1000*ones(4,90),F);
            t.verifyEqual(F,before);t.verifyEqual(F.mean,mean(X,1),'AbsTol',1e-12);
            t.verifySize(Z,[20 64]);t.verifySize(Q,[4 64]);t.verifyEqual(F.rank,19);
            t.verifyLessThanOrEqual(max(abs(Q(:))),single(1));t.verifyEqual(Q(:,20:end),zeros(4,45,'single'));
        end
        function classMapsAreExplicit(t)
            b=nimeq.task_info('DR7_binary');f=nimeq.task_info('DR7_5class');s=nimeq.task_info('DR7_7class');
            t.verifyEqual(b.map,[0 1 1 1 1 1 1]);t.verifyEqual(f.map,[0 1 2 3 3 4 4]);t.verifyEqual(s.map,0:6);
        end
    end
end
