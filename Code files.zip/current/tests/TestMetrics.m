classdef TestMetrics < matlab.unittest.TestCase
    methods (Test)
        function knownCounts(t)
            [p,o]=nimeq.metrics([40 10;5 45],["Normal","DR"]);
            t.verifyEqual(p.TP,[40;45]);t.verifyEqual(p.FN,[10;5]);
            t.verifyEqual(p.FP,[5;10]);t.verifyEqual(p.TN,[45;40]);
            t.verifyEqual(p.sensitivity_pct,[80;90],'AbsTol',1e-10);
            t.verifyEqual(p.specificity_pct,[90;80],'AbsTol',1e-10);
            t.verifyEqual(p.f1_pct,100*[80/95;90/105],'AbsTol',1e-10);
            t.verifyEqual(p.balanced_error_pct,[15;15],'AbsTol',1e-10);
            t.verifyEqual(o.overall_accuracy_pct,85,'AbsTol',1e-10);
        end
        function undefinedPrecisionIsVisible(t)
            [p,o]=nimeq.metrics([10 0;5 0],["A","B"]);
            t.verifyTrue(isnan(p.precision_pct(2)));t.verifyEqual(p.f1_pct(2),0);
            t.verifyTrue(isnan(o.macro_precision_pct));
            t.verifyEqual(o.macro_f1_pct,40,'AbsTol',1e-10);
            t.verifyError(@()nimeq.metrics([.5 0;0 1],["A","B"]),'nimeq:InvalidCounts');
            t.verifyError(@()nimeq.metrics(zeros(2),["A","B"]),'nimeq:InvalidCounts');
        end
        function identitiesAcrossTasks(t)
            rng(919);
            for K=[2 5 7]
                for run=1:100
                    C=randi([1 100],K);[p,o]=nimeq.metrics(C,"class_"+string(1:K));
                    expected=2*p.precision_pct.*p.sensitivity_pct./(p.precision_pct+p.sensitivity_pct);
                    t.verifyEqual(p.f1_pct,expected,'AbsTol',1e-10);
                    t.verifyGreaterThanOrEqual(p.one_vs_rest_accuracy_pct,min(p.sensitivity_pct,p.specificity_pct)-1e-10);
                    t.verifyLessThanOrEqual(p.one_vs_rest_accuracy_pct,max(p.sensitivity_pct,p.specificity_pct)+1e-10);
                    t.verifyEqual(o.micro_f1_pct,o.overall_accuracy_pct,'AbsTol',1e-10);
                    t.verifyEqual(o.overall_accuracy_pct,100*trace(C)/sum(C(:)),'AbsTol',1e-10);
                end
            end
        end
        function rocTiesAndMissingClasses(t)
            [x,y,~,auc]=nimeq.roc_curve([false;true],[.5;.5]);
            t.verifyEqual(x,[0;1]);t.verifyEqual(y,[0;1]);t.verifyEqual(auc,.5);
            [x,~,~,auc]=nimeq.roc_curve(true(3,1),[.1;.2;.3]);
            t.verifyEmpty(x);t.verifyTrue(isnan(auc));
            [~,~,~,auc]=nimeq.roc_curve([false;false;true;true],[.1;.2;.8;.9]);t.verifyEqual(auc,1);
        end
    end
end
