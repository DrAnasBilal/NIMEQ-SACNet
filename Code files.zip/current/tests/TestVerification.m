classdef TestVerification < matlab.unittest.TestCase
    methods (Test)
        function detectsAlteredMetric(t)
            % Entirely synthetic unit fixture; never used as experiment data.
            folder=tempname;mkdir(folder);cleanup=onCleanup(@()rmdir(folder,'s')); %#ok<NASGU>
            cfg=nimeq_config('quick');cfg.models="SACNet";cfg.verification.requireFigures=false;
            save(fullfile(folder,'configuration.mat'),'cfg');task=nimeq.task_info('DR7_binary');
            dataset=repmat("DR7",6,1);sample_id=["0001";"001";"002";"003";"004";"005"];
            image_path=repmat("synthetic_unit_fixture.png",6,1);grade=[0;1;0;2;0;2];
            group_id="unit_group_"+string((1:6).');patient_id=strings(6,1);
            sha256=repmat(string(repmat('0',1,64)),6,1);
            partition=[repmat("train",4,1);repmat("test",2,1)];inner_fold=[1;2;1;2;0;0];
            S=table(dataset,sample_id,image_path,grade,group_id,patient_id,sha256,partition,inner_fold);
            writetable(S,fullfile(folder,'source_splits.csv'));
            out=fullfile(folder,'DR7_binary','SACNet');mkdir(out);
            nimeq.export_predictions(S(5:6,:),task,[1;1],[.8 .2;.7 .3],[.8 .2;.7 .3], ...
                'SACNet',cfg.experimentName,0,'heldout_test',out);
            nimeq.export_metrics([1;2],[1;1],task,out);
            path=fullfile(folder,'DR7_binary','final_features','training_images');mkdir(path);
            A=table(S.sample_id(1:4),S.group_id(1:4),[1;2;1;2], ...
                'VariableNames',{'parent_sample_id','group_id','label_index'});
            writetable(A,fullfile(path,'augmentation_ancestry.csv'));
            a=nimeq.verify_run(folder,false,false,false);t.verifyTrue(a.passed);
            P=readtable(fullfile(out,'class_metrics.csv'));P.f1_pct(1)=99;
            writetable(P,fullfile(out,'class_metrics.csv'));
            b=nimeq.verify_run(folder,false,false,false);t.verifyFalse(b.passed);t.verifyGreaterThan(b.failed_checks,0);
        end
    end
end
