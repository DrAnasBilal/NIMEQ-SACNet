classdef TestEWT < matlab.unittest.TestCase
    methods (Test)
        function tightFrameAndReconstruction(t)
            cfg=nimeq_config('quick');rng(2026);
            for shape={[64 64],[63 79],[80 65]}
                I=rand(shape{1});[f,info,bands,filters]=nimeq.ewt_features(I,cfg);
                t.verifySize(f,[1 19]);t.verifyTrue(all(isfinite(f)));
                t.verifyEqual(size(bands,3),4);
                t.verifyLessThan(info.tight_frame_max_error,1e-12);
                t.verifyLessThan(info.reconstruction_max_error,1e-12);
                t.verifyEqual(sum(bands(:).^2),sum(I(:).^2),'RelTol',1e-12);
                restored=zeros(size(I));
                for b=1:4
                    restored=restored+real(ifft2(ifftshift(fftshift(fft2(bands(:,:,b))).*filters(:,:,b))));
                end
                t.verifyEqual(restored,I,'AbsTol',1e-12);
                t.verifyGreaterThan(min(diff(info.boundaries_radians)),0);
            end
        end
        function zeroAndConstantInputs(t)
            cfg=nimeq_config('quick');
            [f,a]=nimeq.ewt_features(zeros(32),cfg);
            t.verifyTrue(all(isfinite(f)));t.verifyTrue(a.used_interval_subdivision);
            t.verifyEqual(f(1:16),zeros(1,16,'single'));t.verifyEqual(a.reconstruction_max_error,0);
            [f,b]=nimeq.ewt_features(ones(32),cfg);
            t.verifyEqual(sum(f(1:4:16)),single(1),'AbsTol',single(1e-6));
            t.verifyLessThan(b.reconstruction_max_error,1e-12);
        end
        function featureContractMatchesInference(t)
            cfg=nimeq_config('quick');C=ones(3,256,'single');L=ones(3,10,'single');E=ones(3,19,'single');
            [X,names]=nimeq.feature_matrix(C,L,E,cfg);t.verifySize(X,[3 285]);t.verifyEqual(numel(names),285);
            cfg.ewt.enabled=false;X=nimeq.feature_matrix(C,L,[],cfg);t.verifySize(X,[3 266]);
            cfg.features.includeLesionDescriptors=false;X=nimeq.feature_matrix(C,L,[],cfg);t.verifySize(X,[3 256]);
        end
        function workstationIncludesEveryTask(t)
            cfg=nimeq_config('workstation');
            t.verifyEqual(numel(cfg.tasks),5);t.verifyEqual(numel(cfg.models),4);
            t.verifyEqual(cfg.search.table4Trials,10);t.verifyEqual(cfg.search.folds,3);
            t.verifyTrue(cfg.ewt.enabled);
            B=nimeq.budget_estimate(cfg);t.verifyEqual(B.inner_SAC_fits_upper_bound,1440);
            B=nimeq.budget_estimate(nimeq_config('full'));t.verifyEqual(B.inner_SAC_fits_upper_bound,192000);
        end
    end
end
