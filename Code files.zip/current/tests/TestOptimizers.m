classdef TestOptimizers < matlab.unittest.TestCase
    methods (Test)
        function chromosomeEndpointsAndEmptyRepair(t)
            cfg=nimeq_config('quick');D=64+2*cfg.search.hyperBits;
            a=nimeq.decode_candidate(zeros(1,D),cfg);b=nimeq.decode_candidate(ones(1,D),cfg);
            t.verifyEqual(sum(a.mask),1);t.verifyTrue(all(b.mask));
            t.verifyEqual(a.alpha,cfg.search.alphaRange(1));t.verifyEqual(b.alpha,cfg.search.alphaRange(2));
            t.verifyEqual(a.chi,cfg.search.chiRange(1));t.verifyEqual(b.chi,cfg.search.chiRange(2),'AbsTol',1e-12);
        end
        function seededSearchAndNormalizedQubits(t)
            cfg=nimeq_config('quick');folder=tempname;mkdir(folder);cleanup=onCleanup(@()rmdir(folder,'s')); %#ok<NASGU>
            objective=@TestOptimizers.objective;
            for name=["GWO-SACNet","BGWO-SACNet","NIMEQ-SACNet"]
                a=nimeq.optimize(char(name),objective,cfg,fullfile(folder,char(name),'a'),123);
                b=nimeq.optimize(char(name),objective,cfg,fullfile(folder,char(name),'b'),123);
                t.verifyEqual(a.h,b.h);t.verifyEqual(a.fitness,b.fitness);
                t.verifyTrue(any(a.h.mask));t.verifyTrue(isfinite(a.fitness));
                if name=="NIMEQ-SACNet"
                    d=load(fullfile(folder,char(name),'a','search_checkpoint.mat'),'state');
                    normq=d.state.QA.^2+d.state.QB.^2;
                    t.verifyEqual(normq,ones(size(normq)),'AbsTol',1e-12);
                end
                resumed=nimeq.optimize(char(name),objective,cfg,fullfile(folder,char(name),'a'),123);
                t.verifyEqual(resumed.h,a.h);
            end
        end
    end
    methods (Static)
        function [fitness,detail]=objective(h)
            % Cheap mathematical objective tests search mechanics, not DR performance.
            error=(h.alpha-.3)^2+(h.chi-.7)^2;
            fitness=error+.01*mean(h.mask);
            detail=struct('cvError',error,'cacheHit',false);
        end
    end
end
