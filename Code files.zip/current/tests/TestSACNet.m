classdef TestSACNet < matlab.unittest.TestCase
    methods (Test)
        function forwardShapesAndFiniteGradients(t)
            cfg=nimeq_config('quick');cfg.execution='cpu';h=struct('mask',true(1,64),'alpha',.7,'chi',.5);
            for K=[2 5 7]
                [D,G]=nimeq.init_sac(K,cfg,11);
                for B=[1 3]
                    X=dlarray(randn(8,8,1,B,'single'),'SSCB');T=zeros(K,B,'single');T(1,:)=1;
                    Z=dlarray(cat(3,randn(1,1,32,B,'single'),reshape(T,1,1,K,B)),'SSCB');
                    [L,A,W,C]=nimeq.sac_forward(D,X,h,cfg,K);
                    t.verifySize(nimeq.host(L),[K B]);t.verifyEqual(size(A,2),B);
                    t.verifyEqual(size(W,1),64);t.verifyEqual(size(W,2),64);t.verifyEqual(size(C,1),16);
                    t.verifyEqual(sum(nimeq.host(W),1),ones(1,64,B,'single'),'AbsTol',single(1e-5));
                    [loss,grad]=dlfeval(@nimeq.discriminator_loss,D,G,X,dlarray(T),Z,h,cfg,K);
                    t.verifyTrue(isfinite(nimeq.host(loss)));
                    for f=fieldnames(grad).',t.verifyTrue(all(isfinite(nimeq.host(grad.(f{1}))),'all'));end
                    [gloss,ggrad]=dlfeval(@nimeq.generator_loss,G,D,Z,dlarray(T),h,cfg,K);
                    t.verifyTrue(isfinite(nimeq.host(gloss)));
                    for j=1:height(ggrad),t.verifyTrue(all(isfinite(nimeq.host(ggrad.Value{j})),'all'));end
                    [updated,~,~]=adamupdate(D,grad,[],[],1,1e-3);
                    t.verifyNotEqual(nimeq.host(updated.convW),nimeq.host(D.convW));
                end
            end
        end
        function trainPredictAndResume(t)
            cfg=nimeq_config('quick');cfg.execution='cpu';cfg.sac.batchSize=3;
            folder=tempname;mkdir(folder);cleanup=onCleanup(@()rmdir(folder,'s')); %#ok<NASGU>
            rng(811);X=randn(64,6,'single');y=[1 2 1 2 1 2];h=struct('mask',true(1,64),'alpha',.5,'chi',.2);
            first=nimeq.train_sac(X,y,2,h,cfg,folder,31,2);
            [p,s,L]=nimeq.predict_sac(first,X,cfg);
            t.verifySize(p,[6 1]);t.verifySize(s,[6 2]);t.verifyTrue(all(isfinite(L(:))));
            t.verifyEqual(sum(s,2),ones(6,1,'single'),'AbsTol',single(1e-5));
            t.verifyEqual(first.history(:,1),[1;2]);
            % Keep checkpoint and remove only the completed model: resume must match.
            delete(fullfile(folder,'sac_model.mat'));
            resumed=nimeq.train_sac(X,y,2,h,cfg,folder,31,2);
            [q,~,R]=nimeq.predict_sac(resumed,X,cfg);
            t.verifyEqual(q,p);t.verifyEqual(R,L,'AbsTol',single(1e-6));
        end
    end
end
