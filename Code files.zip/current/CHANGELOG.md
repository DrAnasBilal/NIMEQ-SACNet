# Version 2 - 21 October 2026

- Added a declared 2-D radial Meyer EWT feature branch, raw decomposition, per-image diagnostics and matching inference features. Original EWT settings remain unknown; this is a new choice.
- Added a workstation profile covering all five tasks, four main variants and ten Table4 trials with a reduced budget. Full retains its larger settings; quick remains a real-data installation check.
- Added automatic verification of final metrics/counts, source membership, augmentation ancestry, class names/scores and native graphics. Optional source rehashing and deep CV checks are available.
- Added raw features before SVD, a column schema, model parameter shapes, optimal-iteration values and complete best-qubit-coordinate CSVs for each NIMEQ trial.
- Preserved numeric-looking sample IDs and leading zeros during result verification; handled undefined metric columns when reimporting CSVs.
- Recreated the image datastore explicitly for ordered CNN feature extraction and used a documented vector shape for convolution bias.
- Added local environment reports, saved MATLAB self-test logs, EWT/verification tests, budget estimates, a method-coverage ledger and optional fixed sensitivity variants.
- Added a complete run guide and concern-to-evidence scope document. New run names include v2 and do not silently reuse earlier experiments.

All supplied source files remain unchanged. Static parsing and independent NumPy mathematics/file checks were rerun. MATLAB execution, data import, gradients, training, figures and achieved performance remain unverified here because MATLAB is unavailable.
