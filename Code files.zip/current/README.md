# NIMEQ-SACNet MATLAB experiment project - version 2

This project implements a new experiment workflow for **NIMEQ-SACNet: A Novel Self-Attention Precision Medicine Model for Vision-Threatening Diabetic Retinopathy using Image Data**, DOI `10.1016/j.compbiomed.2024.108099`. It reuses the useful enhancement and segmentation logic in your supplied code, and adds the missing model training, optimization, evaluation and numerical/graphical exports.

**This is a documented reconstruction, not recovered original experiment software.** Missing paper details require explicit choices. Some printed values are mathematically incompatible, so exact or nearby published values cannot be promised. No completed training results are included. MATLAB is unavailable in the development environment: static and independent mathematical checks have passed, but MATLAB execution and scientific performance remain unverified.

## Run on your computer

Read [HOW_TO_RUN.md](HOW_TO_RUN.md) for the complete Windows/macOS/Linux instructions, dataset setup, run order, resume behavior and error handling.

From MATLAB's Current Folder set to this extracted project folder:

```matlab
RUN_ENVIRONMENT_CHECK
RUN_SELF_TEST
RUN_QUICK
```

After those checks pass, install both datasets as described in the guide:

```matlab
CHECK_DATA
RUN_WORKSTATION
VERIFY_RESULTS
```

`RUN_WORKSTATION` runs **all five tasks, all four variants and ten Table 4 trials** with a declared reduced budget. `RUN_ALL` instead uses the much larger full configuration. Both generate measured new results. The quick profile uses real DR7 binary data and small budgets to check installation.

## What is implemented

- YCbCr enhancement and native-resolution red/bright lesion segmentation adapted from your supplied function.
- Training-only augmentation, paired mask geometry and source ancestry.
- Red, bright and fused lesion descriptors; CNN feature extraction; an explicit EWT option; training-fitted SVD.
- A self-attention capsule discriminator and conditional feature generator with actual differentiable training.
- SACNet, GWO-SACNet, BGWO-SACNet and NIMEQ-SACNet; normalized and literal quantum-update options.
- Binary and five-class IDRiD tasks; binary, five-class and seven-class DR7 tasks.
- Optional SVM/KNN/tree/voting comparisons and an additional majority vote of the four network variants.
- Predictions, confusion counts, metrics, trial means, search/training histories, models, raw features, native MATLAB figures and checksums.
- Automatic verification of final metrics against case predictions and of training/evaluation membership.

Version 2 adds EWT descriptors to the feature fusion by default. **The article does not specify its original EWT procedure.** The new radial Meyer filter bank and its settings are declared choices; set `cfg.ewt.enabled=false` for the branch without EWT. Raw bands, boundaries and reconstruction checks are exported. [docs/EWT_CHOICE.md](docs/EWT_CHOICE.md) explains the exact choice and its limits. This implementation does not require Wavelet Toolbox.

Training/test sources are split before augmentation or learned fitting. Exact duplicate files and supplied patient IDs remain in a common group. Conflicting grades for identical bytes are quarantined and logged. Without verified patient identifiers, patient independence is not established. Each inner fold fits its own supervised CNN and SVD; optimizer fitness uses validation predictions. Test results never select a candidate, epoch or trial.

## Profiles and computation

| Profile | Tasks / variants | CNN epochs | CV folds | Wolves x iterations | SAC epochs per CV fit | Final SAC epochs | Table 4 trials | Upper bound on CV SAC fits |
|---|---|---:|---:|---|---:|---:|---:|---:|
| `quick` | DR7 binary / all four | 2 | 2 | 3 x 2 | 1 | 2 | 1 | 36 |
| `workstation` | All five / all four | 10 | 3 | 4 x 5 | 3 | 30 | 10 | 1,440 |
| `full` | All five / all four | 30 | 10 | 8 x 100 | 100 | 100 | 10 | 192,000 |

These are fit-count bounds before candidate cache reuse, not measured runtime estimates. Full additionally fits 55 CNNs and 20 final SACNets; workstation fits 20 CNNs and 20 final SACNets. The CNN has about 45 million parameters. Computation and checkpoint/model storage can be substantial, especially on CPU. The paper does not uniquely establish the original inner-training budget. Every run saves its resolved settings.

## Files to read

- [HOW_TO_RUN.md](HOW_TO_RUN.md): setup and commands for your computer.
- [docs/METHOD_MAPPING.md](docs/METHOD_MAPPING.md): paper-to-code mapping and assumptions.
- [docs/EWT_CHOICE.md](docs/EWT_CHOICE.md): newly specified EWT procedure.
- [docs/OUTPUTS.md](docs/OUTPUTS.md): numerical and graphical output paths.
- [docs/EVIDENCE_SCOPE.md](docs/EVIDENCE_SCOPE.md): journal concerns, new evidence and remaining original-record needs.
- [docs/SOURCE_CODE_REVIEW.md](docs/SOURCE_CODE_REVIEW.md): reused code, fixes and supplied files.
- [validation/VALIDATION.md](validation/VALIDATION.md): completed development checks versus tests to run locally.

All supplied files are preserved in `reference_inputs/` with SHA256 inventory. **Do not add that folder recursively to the MATLAB path.** Use `addpath(projectRoot)`, not `addpath(genpath(projectRoot))`. Preserved legacy scripts contain demonstration plots and errors and are not the new implementation.

Results go to `results/<experimentName>/`. New default names contain `v2` to preserve earlier experiments. Keep each entire run folder, including configuration, raw predictions, models, graphs and verification reports.

`PREDICT_NEW` applies a saved model to new images. `RUN_REFERENCE_CHECKS` checks printed arithmetic without data/training. `RUN_SENSITIVITY` optionally reports fixed EWT/quantum/polarity variants on DR7 binary at the workstation budget; it does not select by test accuracy.

Label resulting outputs as **new experiments**. They cannot establish why historical errors occurred, replace missing historical records, establish citation-addition history or guarantee the journal's decision.
