% Run all five tasks and all four model variants on real fundus images.
% New implementation of the described method; measured results are not preset.
projectRoot = fileparts(mfilename('fullpath'));
addpath(projectRoot);
cfg = nimeq_config('full');
% Place the official IDRiD disease-grading download here, preserving its tree.
cfg.data.idridRoot = fullfile(projectRoot,'data','IDRiD');
cfg.data.dr7Root = fullfile(projectRoot,'data','DR7');
cfg.data.downloadDR7 = true;
% To resume, keep this name and the same configuration and input files.
cfg.experimentName = 'full_v2_seed41';
nimeq.run_all(cfg);
