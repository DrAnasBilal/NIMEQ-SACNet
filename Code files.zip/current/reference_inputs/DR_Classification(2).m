%% Features extraction section
imds = imageDatastore('Training_set', 'IncludeSubfolders', true, ...
    'LabelSource', 'foldernames');

Fused_Feats = [];
Red_Feats = [];
Bright_Feats = [];

num_images = imds.numpartitions;
for i = 1:imds.numpartitions
    [Fused, red, bright] = DR_feats_fcn(imds.readimage(i));
    Fused_Feats = [Fused_Feats, Fused]; %#ok<*AGROW>
    Red_Feats = [Red_Feats, red];
    Bright_Feats = [Bright_Feats, bright];
    fprintf('Currently processing image no. %s of %s\n', num2str(i), num2str(num_images))
end
%% Classification section

t = templateSVM('kernelFunction','gaussian', 'Standardize', 1);
svm_fused = fitcecoc(Fused_Feats', imds.Labels, 'learner', t);
disp('Fused Feats classification accuracy')
(1 - resubLoss(svm_fused)) * 100

%
% svm_red = fitcecoc(Red_Feats', imds.Labels, 'learner', t);
disp('Red Feats only classification accuracy')
(1 - resubLoss(svm_red)) * 100

%
disp('Bright Feats only classification accuracy')
% svm_bright = fitcecoc(Bright_Feats', imds.Labels, 'learner', t);
(1 - resubLoss(svm_bright)) * 100