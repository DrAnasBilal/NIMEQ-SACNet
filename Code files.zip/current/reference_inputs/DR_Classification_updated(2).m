%this is for training
tic
imds = imageDatastore('Training_set', 'IncludeSubfolders', true, ...
    'LabelSource', 'foldernames');

Fused_Feats = [];
Red_Feats = [];
Bright_Feats = [];

num_images = imds.numpartitions;
for i = 1%:imds.numpartitions
    [Fused, red, bright] = DR_feats_fcn(imds.readimage(i));
    Fused_Feats = [Fused_Feats, Fused]; %#ok<*AGROW>
    fprintf('Currently processing image no. %s of %s\n', num2str(i), num2str(num_images))
end
toc
% This in case some error occured after this and after finishing
save UpdatedWork_Checkpoint.mat 
%%


% Matcher 1(KNN) 
knn_template = templateKNN('Standardize', 1, 'NumNeighbors', 3);
knn = fitcecoc(Fused_Feats', imds.Labels, 'learner', knn_template);

% Matcher 2 (SVM)
svm_template = templateSVM('kernelFunction','gaussian', 'Standardize', 1);
svm_fused = fitcecoc(Fused_Feats', imds.Labels, 'learner', svm_template);


% Matcher 3 (TREES)
trees_template = templateTree(); % 'DiscrimType','pseudoLinear'
trees = fitcecoc(Fused_Feats', imds.Labels, 'learner', trees_template);
% Matcher Fusing
% The basic idea of the fusing to obtain their output and treat it as vote,
% then check the class that has the maximum number of votes and declare it
% as the final voting result. 

% The command PREDICT is used to obtain the output of the matcher
% (classifier), notice the using of the selected_val_feature to obtain the
% results from validation set. 
knn_vote = predict(knn, Fused_Feats');
svm_vote = predict(svm_fused, Fused_Feats');
trees_vote = predict(trees, Fused_Feats');

calculate_results;
%% Matchers fusing
% Finally, to obtain the final result MODE command is used which simple
% statistical measure of the majority. the (2) means we are working along
% the rows, not columns.
final_vote = mode([trees_vote, knn_vote, svm_vote], 2);

% this to calculate the accracy
vote_accuracy = sum(final_vote == imds.Labels) / imds.numpartitions;

% display
disp(vote_accuracy)
%%
% Change labels ftom Tr_0 to numbers (integers) instead of folder names
Predictions = final_vote;

Tar = zeros(1, length(imds.Labels));
Fianl_Vote = zeros(1, length(Predictions));

for i = 1:length(Tar)
    sTar = sprintf('%s', imds.Labels(i));
    Tar(i) = str2double(sTar(end));
    
    sSVM_Out = sprintf('%s', Predictions(i));
    Fianl_Vote(i) = str2double(sSVM_Out(end));
end

% For the calculation of senssitivity and specifity the only allowed
% classes are (0, 1) so that all severiies will be considered as 1 and the
% normal classes will be zeros
%%
Accuracies = [];
for cc = 1:3
    True_Tar = Tar >= cc;
    True_Out = Fianl_Vote >= cc;
    
    TP = sum(True_Tar == 1 & True_Out == 1);
    FP = sum(True_Tar == 1 & True_Out == 0);
    TN = sum(True_Tar == 0 & True_Out == 0);
    FN = sum(True_Tar == 0 & True_Out == 1);
    
    Sensitivity = TP / (TP + FP);
    Specificity = TN / (TN + FN);
    Accuracy = (TP + TN) / (TP + TN + FP + FN);
    
    precision = TP./(TP+FP);
    recall = TP./(TP+FN);
    F1 = (2 * (precision * recall))/(precision + recall);

    Accuracies = [Accuracies, Accuracy];
end

figure, plot(Accuracies * 100, 'ko-',...
    'LineWidth',2,...
    'MarkerSize',10,...
    'MarkerEdgeColor','b',...
    'MarkerFaceColor',[0.5,0.5,0.5])

% xticks = 0:4;
% xticklabels({'0', '1', '2', '3', '4'})
% figure, plot(Accuracies * 100, 'ro-', 'markerthickness', 10)
xlim([0, 4]), ylim([80 100])
grid on
% The confusion matrix allows you to see the exact outputs and where they
% are being classed, for each severity separately. 
figure, plotconfusion(imds.Labels, Predictions)
%%
save UpdatedWork.mat
