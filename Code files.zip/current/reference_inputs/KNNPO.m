% Define threshold values
thresholds = 1:4;

% Plot the Accuracy curves
figure;
hold on;

% Plot KNN
plot(thresholds, knn_acc, '-ro', 'LineWidth', 1, 'DisplayName', 'KNN Accuracy');
plot(thresholds, knn_sens, ':rs', 'LineWidth', 1, 'DisplayName', 'KNN Sensitivity');
plot(thresholds, knn_spec, '--rx', 'LineWidth', 1, 'DisplayName', 'KNN Specificity');

% Plot Binary Trees
plot(thresholds, dt_acc, '-go', 'LineWidth', 1, 'DisplayName', 'Binary Trees Accuracy');
plot(thresholds, dt_sens, ':gs', 'LineWidth', 1, 'DisplayName', 'Binary Trees Sensitivity');
plot(thresholds, dt_spec, '--gx', 'LineWidth', 1, 'DisplayName', 'Binary Trees Specificity');

% Plot SVM-Polynomial
plot(thresholds, svm_poly_acc, '-bo', 'LineWidth', 1, 'DisplayName', 'SVM-Polynomial Accuracy');
plot(thresholds, svm_poly_sens, ':bs', 'LineWidth', 1, 'DisplayName', 'SVM-Polynomial Sensitivity');
plot(thresholds, svm_poly_spec, '--bx', 'LineWidth', 1, 'DisplayName', 'SVM-Polynomial Specificity');

% Plot SVM-Linear
plot(thresholds, svm_linear_acc, '-mo', 'LineWidth', 1, 'DisplayName', 'SVM-Linear Accuracy');
plot(thresholds, svm_linear_sens, ':ms', 'LineWidth', 1, 'DisplayName', 'SVM-Linear Sensitivity');
plot(thresholds, svm_linear_spec, '--mx', 'LineWidth', 1, 'DisplayName', 'SVM-Linear Specificity');

% Plot Improved ISVM-RBF
plot(thresholds, isvm_rbf_acc, '-co', 'LineWidth', 1, 'DisplayName', 'Improved ISVM-RBF Accuracy');
plot(thresholds, isvm_rbf_sens, ':cs', 'LineWidth', 1, 'DisplayName', 'Improved ISVM-RBF Sensitivity');
plot(thresholds, isvm_rbf_spec, '--cx', 'LineWidth', 1, 'DisplayName', 'Improved ISVM-RBF Specificity');

ylim([0 1]);
xlabel('Severity Threshold');
ylabel('Metric Value');
legend('Location', 'NorthWest');
title('Comparison of Classifier Performance');
set(gcf, 'Position', [100, 100, 800, 600]); % Enlarges the plot
