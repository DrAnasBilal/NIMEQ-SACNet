load UpdatedWork.mat
t = templateSVM('kernelFunction','gaussian', 'Standardize', 1);


disp('Bright Feats only classification error')
svm_bright = fitcecoc(Bright_Feats', imds.Labels, 'learner', t);
(1 - resubLoss(svm_bright)) * 100

Predictions = predict(svm_bright, Bright_Feats');

Tar = zeros(1, length( imds.Labels));
SVM_Out = zeros(1, length(Predictions));

for i = 1:length(Tar)
    sTar = sprintf('%s', imds.Labels(i));
    Tar(i) = str2double(sTar(end));
    
    sSVM_Out = sprintf('%s', Predictions(i));
    SVM_Out(i) = str2double(sSVM_Out(end));
end


True_Tar = Tar >= 1;
True_Out = SVM_Out >= 1;

TP = sum(True_Tar == 1 & True_Out == 1);
FP = sum(True_Tar == 1 & True_Out == 0);
TN = sum(True_Tar == 0 & True_Out == 0);
FN = sum(True_Tar == 0 & True_Out == 1);

Sensitivity = TP / (TP + FP)
Specificity = TN / (TN + FN)
Accuracy = (TP + TN) / (TP + TN + FP + FN)

% The confusion matrix allows you to see the exact outputs and where they
% are being classed, for each severity separately. 
figure
plotconfusion(imds.Labels, Predictions)
title('Confusion matrix for bright lesions')