function [Accuracy, Sensitivity, Specificity, F1, precision, recall] = calculate_performance_metrics(True_Tar, True_Out)

TP = sum(True_Tar == 1 & True_Out == 1);
FP = sum(True_Tar == 1 & True_Out == 0);
TN = sum(True_Tar == 0 & True_Out == 0);
FN = sum(True_Tar == 0 & True_Out == 1);

Sensitivity = TP / (TP + FP);
Specificity = TN / (TN + FN);
Accuracy = (TP + TN) / (TP + TN + FP + FN);

precision = TP./(TP+FP);
recall = TP./(TP+FN);
F1 = (2 * (precision * recall))/(precision + recall);
