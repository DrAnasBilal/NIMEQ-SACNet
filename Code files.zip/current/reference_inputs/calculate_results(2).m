% clear, clc
load UpdatedWork.mat


%%
svm_Accuracies = []; svm_Sensitivities = [];  svm_Specificities = [];
svm_F1s = []; svm_precisions = []; svm_recalls = [];

knn_Accuracies = []; knn_Sensitivities = [];  knn_Specificities = [];
knn_F1s = []; knn_precisions = []; knn_recalls = [];

trees_Accuracies = []; trees_Sensitivities = [];  trees_Specificities = [];
trees_F1s = []; trees_precisions = []; trees_recalls = [];

fused_Accuracies = []; fused_Sensitivities = [];  fused_Specificities = [];
fused_F1s = []; fused_precisions = []; fused_recalls = [];

for cc = 1:4
    
    svm_out = zeros(1, length(Tar));
    knn_out = zeros(1, length(Tar));
    trees_out = zeros(1, length(Tar));
    
    for i = 1:length(Tar)
        sSVM_Out = sprintf('%s', svm_vote(i));
        svm_out(i) = str2double(sSVM_Out(end));
        
        sKNN_Out = sprintf('%s', knn_vote(i));
        knn_out(i) = str2double(sKNN_Out(end));
        
        sTrees_Out = sprintf('%s', trees_vote(i));
        trees_out(i) = str2double(sTrees_Out(end));
    end
    
    True_Tar = Tar >= cc;

    
    svm_out = svm_out >= cc;
    knn_out = knn_out >= cc;
    trees_out = trees_out >= cc;
    fused_out = Fianl_Vote >= cc;
    
    [svm_Accuracy, svm_Sensitivity, svm_Specificity, svm_F1, svm_precision,...
        svm_recall] = calculate_performance_metrics(True_Tar, svm_out);
    
    [knn_Accuracy, knn_Sensitivity, knn_Specificity, knn_F1, knn_precision,...
        knn_recall] = calculate_performance_metrics(True_Tar, knn_out);
    
    [trees_Accuracy, trees_Sensitivity, trees_Specificity, trees_F1, trees_precision, ...
        trees_recall] = calculate_performance_metrics(True_Tar, trees_out);
    
    
    [fused_Accuracy, fused_Sensitivity, fused_Specificity, fused_F1, fused_precision, ...
        fused_recall] = calculate_performance_metrics(True_Tar, fused_out);
    
    svm_Accuracies = [svm_Accuracies, svm_Accuracy];
    svm_Sensitivities = [svm_Sensitivities, svm_Sensitivity];
    svm_Specificities = [svm_Specificities, svm_Specificity];
    svm_F1s = [svm_F1s, svm_F1];
    svm_precisions = [svm_precisions, svm_precision];
    svm_recalls = [svm_recalls, svm_recall];
    
    knn_Accuracies = [knn_Accuracies, knn_Accuracy];
    knn_Sensitivities = [knn_Sensitivities, knn_Sensitivity];
    knn_Specificities = [knn_Specificities, knn_Specificity];
    knn_F1s = [knn_F1s, knn_F1];
    knn_precisions = [knn_precisions, knn_precision];
    knn_recalls = [knn_recalls, knn_recall];
    
    
    trees_Accuracies = [trees_Accuracies, trees_Accuracy];
    trees_Sensitivities = [trees_Sensitivities, trees_Sensitivity];
    trees_Specificities = [trees_Specificities, trees_Specificity];
    trees_F1s = [trees_F1s, trees_F1];
    trees_precisions = [trees_precisions, trees_precision];
    trees_recalls = [trees_recalls, trees_recall];
    
    fused_Accuracies = [fused_Accuracies, fused_Accuracy];
    fused_Sensitivities = [fused_Sensitivities, fused_Sensitivity];
    fused_Specificities = [fused_Specificities, fused_Specificity];
    fused_F1s = [fused_F1s, fused_F1];
    fused_precisions = [fused_precisions, fused_precision];
    fused_recalls = [fused_recalls, fused_recall];
end
%%
All_Accuracies = [svm_Accuracies, knn_Accuracies, trees_Accuracies,fused_Accuracies]';
All_Sensitivities = [svm_Sensitivities, knn_Sensitivities, trees_Sensitivities, fused_Sensitivities]';
All_Specificities = [svm_Specificities, knn_Specificities, trees_Specificities, fused_Specificities]';
All_F1s = [svm_F1s, knn_F1s, trees_F1s, fused_F1s]';
All_precisions = [svm_precisions, knn_precisions, trees_precisions, fused_precisions]';
All_recalls = [svm_recalls, knn_recalls, trees_recalls, fused_recalls]';

close all
figure, plot(1:4, [svm_Accuracies;knn_Accuracies;trees_Accuracies])
hold on, plot(1:4, fused_Accuracies, 'rx--');
ylim([0 1]), legend({'SVM', 'KNN', 'Trees', 'Mixture'}, 'location', 'southeast')

title('Accuracy')

figure, plot(1:4, [svm_Sensitivities; knn_Sensitivities; trees_Sensitivities; fused_Sensitivities])
hold on, plot(1:4, fused_Sensitivities, 'rx--');
ylim([0 1]), legend({'SVM', 'KNN', 'Trees', 'Mixture'}, 'location', 'southeast')
title('Sensitivity')

figure, plot(1:4, [svm_Specificities; knn_Specificities; trees_Specificities])
hold on, plot(1:4, fused_Specificities, 'rx--');
ylim([0 1]), legend({'SVM', 'KNN', 'Trees', 'Mixture'}, 'location', 'southeast')
title('Specificity')

figure, plot(1:4, [svm_F1s; knn_F1s; trees_F1s])
hold on, plot(1:4, fused_F1s, 'rx--');
ylim([0 1]), legend({'SVM', 'KNN', 'Trees', 'Mixture'}, 'location', 'southeast')
title('F1')

T = table2cell(table(All_Accuracies, All_Sensitivities, All_Specificities, All_F1s, All_precisions, All_recalls));