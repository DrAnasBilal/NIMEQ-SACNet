close all
fundus_image = imread('E:\Research Drvie\Research Projects\DR IEEE ACCESS\Final code\drishtiGS_015.png');

% Convert the image to grayscale
gray_image = rgb2gray(fundus_image);

% Apply median filtering to remove noise
filtered_image = medfilt2(gray_image, [3, 3]);

% Detect the optic disc using CHT
[centers, radii, metric] = imfindcircles(filtered_image, [50, 150], 'Sensitivity', 0.92, 'EdgeThreshold', 0.1);

% Select the circle with the largest radius as the optic disc
[~, index] = max(radii);
optic_disc_center = centers(index, :);
optic_disc_radius = radii(index);

% Create a binary mask for the optic disc
[x, y] = meshgrid(1:size(fundus_image, 2), 1:size(fundus_image, 1));
optic_disc_mask = (x - optic_disc_center(1)).^2 + (y - optic_disc_center(2)).^2 <= optic_disc_radius.^2;

% Detect the optic cup using CHT
optic_cup_radius_range = round(optic_disc_radius * [0.15, 0.4]);
[centers, radii, metric] = imfindcircles(filtered_image, optic_cup_radius_range, 'ObjectPolarity', 'dark', 'Sensitivity', 0.9);

% Select the circle with the smallest radius as the optic cup
[~, index] = min(radii);
optic_cup_center = centers(index, :);
optic_cup_radius = radii(index);

% Create a binary mask for the optic cup
optic_cup_mask = (x - optic_cup_center(1)).^2 + (y - optic_cup_center(2)).^2 <= optic_cup_radius.^2;

% Apply the masks to the original image with different colors
red_channel = double(fundus_image(:,:,1));
green_channel = double(fundus_image(:,:,2));
blue_channel = double(fundus_image(:,:,3));
red_channel(optic_disc_mask) = 255;
green_channel(optic_disc_mask) = 0;
blue_channel(optic_disc_mask) = 0;
green_channel(optic_cup_mask) = 255;
red_channel(optic_cup_mask) = 0;
blue_channel(optic_cup_mask) = 0;
segmented_image = cat(3, uint8(red_channel), uint8(green_channel), uint8(blue_channel));

% Display the results
figure;
subplot(1,2,1);
imshow(fundus_image);
title('Original Image');
subplot(1,2,2);
imshow(segmented_image);
title('Optic Disc and Cup Segmentation');