imOriginal = imread('IDRiD_018.jpg');
%imshow(imOriginal) 
tform = randomAffine2d('Scale',[1.2,1.5]);
outputView = affineOutputView(size(imOriginal),tform);
imAugmented = imwarp(imOriginal,tform,'OutputView',outputView);
imshow(imAugmented)