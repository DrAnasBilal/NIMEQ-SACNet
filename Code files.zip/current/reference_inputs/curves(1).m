% Define accuracy values for each classifier with different severity threshold values
svm_rbf_acc = [0.9653 0.9710 0.9491 0.9111];
svm_poly_acc = [0.9392 0.9382 0.8878 0.8735];
svm_linear_acc = [0.9340 0.9302 0.8644 0.7777];
knn_acc = [0.8375 0.8792 0.8237 0.9102];
dt_acc = [0.9365 0.9010 0.9130 0.8892];

% Define threshold values
thresholds = 1:4;

% Define the full range of accuracy values
accuracy_range = 0:0.5:1;

% Plot the accuracy curves
figure;
plot(thresholds, svm_rbf_acc, '-r', 'LineWidth', 1, 'DisplayName', 'ISVM-RBF');
hold on;
plot(thresholds, svm_poly_acc, '--g', 'LineWidth', 1, 'DisplayName', 'SVM-P');
plot(thresholds, svm_linear_acc, ':b', 'LineWidth', 1, 'DisplayName', 'SVM-L');
plot(thresholds, knn_acc, '-.m', 'LineWidth', 1, 'DisplayName', 'KNN');
plot(thresholds, dt_acc, '-c', 'LineWidth', 1, 'DisplayName', 'DT');
ylim([0 1]);
xlabel('Severity Threshold');
ylabel('Accuracy (%)');
xticks(thresholds);
legend('Location', 'SouthEast');