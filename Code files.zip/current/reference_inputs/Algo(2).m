# Preprocessing step. 
convert image from RGB to YCbCR
take the Y component 
apply median filter
apply contranst stretchiing and intensity normalization
recover the YCbCr
Convert the YCbCr back to RGB

# Detection of red lesions (hemorrhage)
perform adaptive segmentation with sensitivity value of 0.15 and dark forground polarity


% Perform anomaly rejection
get the segmented properties, extenets and aspect ratios
filter the segmented image based on extent and aspect ratio

% Red lesions features extraction
get all region properties
get the number of regions # 1st feature
get mean area of all regions # 2nd feature
get mean perimeter of all regions # 3rd feature
get mean solidity of all regions # 4nd feature

stack all the features together 
# Detection of bright lesions 
perform adaptive segmentation with sensitivity value of 0.85 and bright forground polarity

# Segmentation enshancement
perform area filtering and morphological closing

# Bright lesions features
 
get all region properties
get the number of regions # 1st feature
get mean area of all regions # 2nd feature
get mean perimeter of all regions # 3rd feature
get mean solidity of all regions # 4nd feature

# Fusion
append the red lesions features and the bright lesions features lexicographically


# Training algotithm


# construct training and targets

for i = 1 to number of training images  
    get the ith image from data base
    perform preprocessing and features extraction
    stack the result features to the training images array
    assign target class based on severity from the dataset

# Train classifiers
train the support vector machine classifier
train the K-nearest neighbor classifier
train the binary trees classifier


# Testing algorithm
get the desired test image
perform image preprocessing and features extraction
predict the features on the SVM classifier
predict the features on the binary trees classifier
predict the features on the KNN classifier

get the mode of three predictions result