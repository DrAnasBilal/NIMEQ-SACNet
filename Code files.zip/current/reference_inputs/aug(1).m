imOriginal = imread('p.png');
tform = randomAffine2d('Rotation',[-45 45]); 
outputView = affineOutputView(size(imOriginal),tform);
imAugmented = imwarp(imOriginal,tform,'OutputView',outputView);  
imshow(imAugmented)