%Step 1
%feature alculation
% Reading the image
close all
I = imread('H:\Research Drive\Research Projects\DR IEEE ACCESS\Final code arbi\IDRiD_376.jpg');

% Preprocessing step
Iycr = rgb2ycbcr(I);
Iy = Iycr(:, :, 1);
Iypre = medfilt2(imadjust(adapthisteq(Iy)), [7 7]);
Irec1 = Iycr; Irec1(:, :, 1) = Iypre;
Ipre = im2double(ycbcr2rgb(Irec1)) .* double(rescale(rgb2gray(I)) > 0.2);

%%
% Detection of red lesions
close all
figure, imshowpair(I, Ipre, 'montage'), impixelinfo
%
I_red = imbinarize(Ipre, 'adaptive', 'ForegroundPolarity','dark','Sensitivity',0.15);
I_red = ~(sum(I_red, 3) >= 2);

% I_red2 = imclose(I_red, strel('disk', 4));
I_red2 = imclearborder(imclose(I_red, strel('disk', 4)));
I_red3 = bwareafilt(imclose(I_red2, strel('disk', 10)), [200, inf]);
figure, imshowpair(I_red2, I_red3, 'montage')
%

I_red_props = regionprops(I_red3, 'All');
Centroids = cat(1, I_red_props.Centroid);
Extents = [I_red_props.Extent];
Aspect = [I_red_props.MinorAxisLength] ./ [I_red_props.MajorAxisLength];

I_red5 = zeros(size(I_red3));
for i = 1:length(I_red_props)
    if Extents(i) > 0.15 && Aspect(i) > 0.15
        I_red5 = or(I_red5, ismember(bwlabel(I_red3), i));
    end
end

% Color red lesions in red
I_color_red = I;
I_color_red(repmat(I_red5, [1, 1, 3])) = 0;
I_color_red(:, :, 1) = I_color_red(:, :, 1) + uint8(I_red5) * 255; % Red channel

figure, imshowpair(I_red3, I_red5, 'montage')
figure, imshowpair(I_red5, I)
figure, imshowpair(I_color_red, I, 'montage')
for i = 1:length(I_red_props)
   text(Centroids(i, 1), Centroids(i, 2), num2str(Extents(i)))
end

% Red lesions features
%%
red2_props = regionprops(I_red5, 'All');
num_red = length(red2_props);
meanArea = mean([red2_props.Area]);
meanPerimeter = mean([red2_props.Perimeter]);
meanSolidity = mean([red2_props.Solidity]);

red_Feats = [num_red, meanArea, meanPerimeter, meanSolidity];

%% Detection of bright lesions 
I_bright = imbinarize(Ipre, 'adaptive', 'ForegroundPolarity','dark','Sensitivity',0.85);
I_bright = sum(I_bright, 3) >= 2;
figure, imshow(double(I_bright), []), impixelinfo
%%
I_bright2 = and(I_bright, (rescale(rgb2gray(Ipre) > 0.85)));
I_bright2 = bwareafilt(imclearborder(imclose(I_bright2, strel('disk', 20))), [200, inf]);
figure, imshowpair(I_bright, I_bright2, 'montage')
figure, imshowpair(I, I_bright2), impixelinfo
figure, imshow(rescale(rgb2gray(Ipre))), impixelinfo
%%
%
bright_props = regionprops(I_bright2, 'All');
num_red = length(bright_props);
meanArea = mean([bright_props.Area]);
meanPerimeter = mean([bright_props.Perimeter]);
meanSolidity = mean([bright_props.Solidity]);

bright_Feats = [num_red, meanArea, meanPerimeter, meanSolidity];

% Color bright lesions in a bright color
I_color_bright = I;
I_color_bright(repmat(I_bright2, [1, 1, 3])) = 0;
I_color_bright(:, :, 1) = I_color_bright(:, :, 1) + uint8(I_bright2) * 255; % Bright color

figure, imshowpair(I_color_bright, I, 'montage')

%% Fusion
%Fused_Feats = [red_Feats, bright_Feats]';

% Change green and purple colors
green_mask = I(:, :, 2) > 150 & I(:, :, 1) < 100 & I(:, :, 3) < 100;
purple_mask = I(:, :, 1) > 150 & I(:, :, 2) < 100 & I(:, :, 3) > 150;

I_color = I;
I_color(repmat(green_mask, [1, 1, 3])) = 0;
I_color(:, :, 2) = I_color(:, :, 2) + uint8(green_mask) * 255; % Green channel

I_color(repmat(purple_mask, [1, 1, 3])) = 0;
I_color(:, :, 3) = I_color(:, :, 3) + uint8(purple_mask) * 255; % Purple channel

figure, imshow(I_color)
