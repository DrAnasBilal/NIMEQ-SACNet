function RUN_SELF_TEST
% Unit and gradient smoke tests. No scientific performance is measured.
projectRoot=fileparts(mfilename('fullpath'));
addpath(projectRoot);
folder=fullfile(projectRoot,'local_validation');if ~isfolder(folder),mkdir(folder);end
diary(fullfile(folder,'matlab_self_test_console.log'));guard=onCleanup(@()diary('off')); %#ok<NASGU>
results=runtests(fullfile(projectRoot,'tests'));
disp(results);
T=table(string({results.Name}).',[results.Passed].',[results.Failed].',[results.Incomplete].',[results.Duration].', ...
    'VariableNames',{'test_name','passed','failed','incomplete','duration_seconds'});
writetable(T,fullfile(folder,'matlab_self_test_results.csv'));
save(fullfile(folder,'matlab_self_test_results.mat'),'results');
nimeq.write_json(fullfile(folder,'matlab_self_test_environment.json'),struct('matlab',version,'release',version('-release'),'toolboxes',ver));
assert(all([results.Passed]),'nimeq:TestsFailed','At least one MATLAB test failed.');
end
