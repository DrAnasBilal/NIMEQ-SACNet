% Apply one newly trained model to your own images without retraining.
projectRoot=fileparts(mfilename('fullpath'));addpath(projectRoot);
bundleFile=fullfile(projectRoot,'results','workstation_v2_seed41','IDRiD_5class','NIMEQ-SACNet','inference_bundle.mat');
imageFolder=fullfile(projectRoot,'new_images');
outputCSV=fullfile(projectRoot,'new_image_predictions.csv');
nimeq.predict_files(bundleFile,imageFolder,outputCSV);
