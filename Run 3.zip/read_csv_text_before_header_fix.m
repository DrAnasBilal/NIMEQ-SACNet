function T=read_csv_text(path)
o=detectImportOptions(path,'TextType','string','VariableNamingRule','preserve');
o=setvartype(o,o.VariableNames,'string');T=readtable(path,o);
for j=1:width(T)
    x=string(T{:,j});x(ismissing(x))="";T.(T.Properties.VariableNames{j})=x;
end
end
